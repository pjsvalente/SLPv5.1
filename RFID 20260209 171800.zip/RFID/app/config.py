"""
SmartLamppost - Configuração da Aplicação
"""

import os
import secrets

# Caminhos base
PASTA_BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


class Config:
    """Configuração base da aplicação."""

    # Base de dados
    BASE_DADOS = os.path.join(PASTA_BASE, 'smartlamppost.db')

    # Segurança
    SECRET_KEY = os.environ.get('SECRET_KEY', secrets.token_hex(32))
    EXPIRACAO_TOKEN_HORAS = 24

    # Backups
    PASTA_BACKUPS = os.path.join(PASTA_BASE, 'backups')
    MAX_BACKUPS = 30

    # Uploads
    PASTA_UPLOADS = os.path.join(PASTA_BASE, 'uploads')
    PASTA_INTERVENCOES = os.path.join(PASTA_UPLOADS, 'interventions')
    PASTA_ASSETS = os.path.join(PASTA_BASE, 'assets')
    MAX_FILE_SIZE = 3 * 1024 * 1024  # 3MB
    ALLOWED_EXTENSIONS = {'pdf', 'jpg', 'jpeg', 'png'}

    # CORS
    CORS_ORIGINS = os.environ.get('CORS_ORIGINS', '*')

    # Debug
    DEBUG = os.environ.get('FLASK_DEBUG', 'False').lower() == 'true'


class DevelopmentConfig(Config):
    """Configuração de desenvolvimento."""
    DEBUG = True


class ProductionConfig(Config):
    """Configuração de produção."""
    DEBUG = False


# Selecionar configuração baseada no ambiente
config_by_name = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'default': DevelopmentConfig
}


def get_config():
    """Obtém a configuração baseada na variável de ambiente."""
    env = os.environ.get('FLASK_ENV', 'default')
    return config_by_name.get(env, DevelopmentConfig)
