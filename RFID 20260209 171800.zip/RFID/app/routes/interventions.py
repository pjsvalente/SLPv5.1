"""
SmartLamppost - Rotas de Gestão de Intervenções
"""

import os
import json
from datetime import datetime
from flask import request, jsonify, g, send_file

from app.routes import interventions_bp
from app.database import obter_bd
from app.utils import requer_autenticacao, requer_admin, allowed_file
from app.config import get_config

config = get_config()


@interventions_bp.route('', methods=['GET'])
@requer_autenticacao
def listar_intervencoes():
    """Lista todas as intervenções com filtros opcionais."""
    bd = obter_bd()

    # Parâmetros de filtro
    status = request.args.get('status')
    tipo = request.args.get('type')
    asset_id = request.args.get('asset_id')
    serial_number = request.args.get('serial_number')
    pagina = int(request.args.get('page', 1))
    por_pagina = int(request.args.get('per_page', 20))

    # Query base
    query = '''
        SELECT i.*, a.serial_number, u.username as created_by_name,
               (SELECT GROUP_CONCAT(COALESCE(u2.username, et.name || ' (' || et.company || ')'), ', ')
                FROM intervention_technicians it
                LEFT JOIN users u2 ON it.user_id = u2.id
                LEFT JOIN external_technicians et ON it.external_technician_id = et.id
                WHERE it.intervention_id = i.id) as technicians,
               (SELECT COUNT(*) FROM intervention_files WHERE intervention_id = i.id) as file_count,
               (SELECT COALESCE(SUM(cost_value), 0) FROM intervention_files WHERE intervention_id = i.id AND cost_value IS NOT NULL) as total_file_costs
        FROM interventions i
        JOIN assets a ON i.asset_id = a.id
        LEFT JOIN users u ON i.created_by = u.id
        WHERE 1=1
    '''
    params = []

    if status:
        query += ' AND i.status = ?'
        params.append(status)

    if tipo:
        query += ' AND i.intervention_type = ?'
        params.append(tipo)

    if asset_id:
        query += ' AND i.asset_id = ?'
        params.append(asset_id)

    if serial_number:
        query += ' AND a.serial_number = ?'
        params.append(serial_number)

    # Contagem total
    total_query = f'''
        SELECT COUNT(*) as total FROM interventions i
        JOIN assets a ON i.asset_id = a.id
        WHERE 1=1 {' AND i.status = ?' if status else ''} {' AND i.intervention_type = ?' if tipo else ''}
        {' AND i.asset_id = ?' if asset_id else ''} {' AND a.serial_number = ?' if serial_number else ''}
    '''
    count_params = [p for p in params]
    total = bd.execute(total_query, count_params).fetchone()['total']

    # Paginação e ordenação
    query += ' ORDER BY i.created_at DESC LIMIT ? OFFSET ?'
    params.extend([por_pagina, (pagina - 1) * por_pagina])

    intervencoes = bd.execute(query, params).fetchall()

    return jsonify({
        'interventions': [dict(i) for i in intervencoes],
        'total': total,
        'page': pagina,
        'per_page': por_pagina,
        'pages': (total + por_pagina - 1) // por_pagina
    })


@interventions_bp.route('/<int:id>', methods=['GET'])
@requer_autenticacao
def obter_intervencao(id):
    """Obtém detalhes completos de uma intervenção."""
    bd = obter_bd()

    intervencao = bd.execute('''
        SELECT i.*, a.serial_number, u.username as created_by_name,
               u2.username as updated_by_name
        FROM interventions i
        JOIN assets a ON i.asset_id = a.id
        LEFT JOIN users u ON i.created_by = u.id
        LEFT JOIN users u2 ON i.updated_by = u2.id
        WHERE i.id = ?
    ''', (id,)).fetchone()

    if not intervencao:
        return jsonify({'error': 'Intervenção não encontrada'}), 404

    resultado = dict(intervencao)

    # Técnicos participantes
    tecnicos = bd.execute('''
        SELECT it.*, u.username, et.name as external_name, et.company as external_company
        FROM intervention_technicians it
        LEFT JOIN users u ON it.user_id = u.id
        LEFT JOIN external_technicians et ON it.external_technician_id = et.id
        WHERE it.intervention_id = ?
    ''', (id,)).fetchall()
    resultado['technicians'] = [dict(t) for t in tecnicos]

    # Ficheiros
    ficheiros = bd.execute('''
        SELECT f.*, u.username as uploaded_by_name
        FROM intervention_files f
        LEFT JOIN users u ON f.uploaded_by = u.id
        WHERE f.intervention_id = ?
        ORDER BY f.file_category, f.uploaded_at
    ''', (id,)).fetchall()
    resultado['files'] = [dict(f) for f in ficheiros]

    # Log de edições
    edicoes = bd.execute('''
        SELECT e.*, u.username as edited_by_name,
               COALESCE(u.first_name || ' ' || u.last_name, u.username) as edited_by_display
        FROM intervention_edit_log e
        LEFT JOIN users u ON e.edited_by = u.id
        WHERE e.intervention_id = ?
        ORDER BY e.edited_at DESC
    ''', (id,)).fetchall()
    resultado['edit_history'] = [dict(e) for e in edicoes]

    # Registos de tempo
    tempo_logs = bd.execute('''
        SELECT t.*, u.username as logged_by_name,
               COALESCE(u.first_name || ' ' || u.last_name, u.username) as logged_by_display
        FROM intervention_time_logs t
        LEFT JOIN users u ON t.logged_by = u.id
        WHERE t.intervention_id = ?
        ORDER BY t.logged_at DESC
    ''', (id,)).fetchall()
    resultado['time_logs'] = [dict(t) for t in tempo_logs]
    resultado['total_time_spent'] = sum(t['time_spent'] for t in tempo_logs)

    # Formatar tempo total
    total_hours = int(resultado['total_time_spent'])
    total_minutes = int((resultado['total_time_spent'] - total_hours) * 60)
    resultado['total_time_formatted'] = f"{total_hours}:{total_minutes:02d}"

    resultado['update_count'] = len(resultado['edit_history'])

    return jsonify(resultado)


@interventions_bp.route('', methods=['POST'])
@requer_autenticacao
def criar_intervencao():
    """Cria uma nova intervenção."""
    dados = request.json

    if not dados.get('asset_id') and not dados.get('serial_number'):
        return jsonify({'error': 'Ativo (asset_id ou serial_number) obrigatório'}), 400

    if not dados.get('intervention_type'):
        return jsonify({'error': 'Tipo de intervenção obrigatório'}), 400

    tipos_validos = ['Manutenção Preventiva', 'Manutenção Corretiva', 'Inspeção', 'Substituição de Componente']
    if dados['intervention_type'] not in tipos_validos:
        return jsonify({'error': f'Tipo inválido. Tipos válidos: {", ".join(tipos_validos)}'}), 400

    duration_hours = dados.get('duration_hours', 0) or 0
    parts_used = dados.get('parts_used', '') or ''

    tipo = dados['intervention_type']
    if tipo == 'Inspeção' and not parts_used:
        parts_used = 'N/A - Inspeção'

    if not dados.get('problem_description'):
        return jsonify({'error': 'Descrição obrigatória'}), 400

    bd = obter_bd()

    # Obter asset_id
    asset_id = dados.get('asset_id')
    if not asset_id and dados.get('serial_number'):
        ativo = bd.execute('SELECT id FROM assets WHERE serial_number = ?', (dados['serial_number'],)).fetchone()
        if not ativo:
            return jsonify({'error': 'Ativo não encontrado'}), 404
        asset_id = ativo['id']

    # Obter estado actual do ativo
    estado_actual = bd.execute('''
        SELECT field_value FROM asset_data
        WHERE asset_id = ? AND field_name = 'condition_status'
    ''', (asset_id,)).fetchone()
    previous_status = estado_actual['field_value'] if estado_actual else 'Não definido'

    user_id = g.utilizador_atual['user_id']

    try:
        cursor = bd.execute('''
            INSERT INTO interventions (
                asset_id, intervention_type, problem_description, solution_description,
                parts_used, total_cost, duration_hours, status, previous_asset_status,
                notes, created_by
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            asset_id, dados['intervention_type'], dados.get('problem_description'),
            dados.get('solution_description', ''), parts_used,
            dados.get('total_cost', 0), duration_hours,
            'em_curso', previous_status, dados.get('notes'), user_id
        ))

        intervention_id = cursor.lastrowid

        # Adicionar técnico responsável
        bd.execute('''
            INSERT INTO intervention_technicians (intervention_id, user_id, role)
            VALUES (?, ?, 'responsavel')
        ''', (intervention_id, user_id))

        # Adicionar técnicos acompanhantes
        for tech_id in dados.get('internal_technicians', []):
            if tech_id != user_id:
                bd.execute('''
                    INSERT INTO intervention_technicians (intervention_id, user_id, role)
                    VALUES (?, ?, 'participante')
                ''', (intervention_id, tech_id))

        # Adicionar técnicos externos
        for ext_id in dados.get('external_technicians', []):
            bd.execute('''
                INSERT INTO intervention_technicians (intervention_id, external_technician_id, role)
                VALUES (?, ?, 'participante')
            ''', (intervention_id, ext_id))

        # Mudar estado para "Em Reparação" se não for Inspeção
        if tipo != 'Inspeção':
            bd.execute('''
                INSERT OR REPLACE INTO asset_data (asset_id, field_name, field_value)
                VALUES (?, 'condition_status', 'Em Reparação')
            ''', (asset_id,))

            bd.execute('''
                INSERT INTO status_change_log (asset_id, previous_status, new_status, description, changed_by, intervention_id)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (asset_id, previous_status, 'Em Reparação',
                  f'Estado alterado automaticamente ao iniciar intervenção #{intervention_id} ({tipo})',
                  user_id, intervention_id))

        # Incrementar contador
        contador_map = {
            'Manutenção Preventiva': 'int_preventiva',
            'Manutenção Corretiva': 'int_corretiva',
            'Inspeção': 'int_inspecao',
            'Substituição de Componente': 'int_substituicao'
        }
        tipo_contador = contador_map.get(tipo)
        if tipo_contador:
            bd.execute('''
                UPDATE sequence_counters
                SET current_value = current_value + 1, updated_at = CURRENT_TIMESTAMP
                WHERE counter_type = ?
            ''', (tipo_contador,))

        bd.commit()

        return jsonify({
            'id': intervention_id,
            'message': 'Intervenção criada com sucesso',
            'status_changed': tipo != 'Inspeção'
        }), 201

    except Exception as e:
        bd.rollback()
        return jsonify({'error': str(e)}), 500


@interventions_bp.route('/<int:id>/complete', methods=['POST'])
@requer_autenticacao
def concluir_intervencao(id):
    """Conclui ou actualiza estado de uma intervenção."""
    dados = request.json

    bd = obter_bd()
    intervencao = bd.execute('SELECT * FROM interventions WHERE id = ?', (id,)).fetchone()

    if not intervencao:
        return jsonify({'error': 'Intervenção não encontrada'}), 404

    if intervencao['status'] == 'concluida':
        return jsonify({'error': 'Intervenção já está concluída'}), 400

    novo_estado = dados.get('final_status')
    descricao_estado = dados.get('status_description', '')
    solution_description = dados.get('solution_description', '')
    parts_used = dados.get('parts_used', '')
    duration_hours = dados.get('duration_hours', 0) or 0
    notes = dados.get('notes', '')

    user_id = g.utilizador_atual['user_id']

    estado_actual = bd.execute('''
        SELECT field_value FROM asset_data
        WHERE asset_id = ? AND field_name = 'condition_status'
    ''', (intervencao['asset_id'],)).fetchone()
    current_status = estado_actual['field_value'] if estado_actual else 'Em Reparação'

    update_count = bd.execute('''
        SELECT COUNT(*) as count FROM intervention_edit_log WHERE intervention_id = ?
    ''', (id,)).fetchone()['count']

    try:
        if novo_estado == 'Operacional':
            bd.execute('''
                UPDATE interventions
                SET status = 'concluida', final_asset_status = ?, completed_at = CURRENT_TIMESTAMP,
                    updated_at = CURRENT_TIMESTAMP, updated_by = ?,
                    solution_description = COALESCE(?, solution_description),
                    parts_used = CASE WHEN ? != '' THEN ? ELSE parts_used END,
                    duration_hours = CASE WHEN ? > 0 THEN ? ELSE duration_hours END,
                    notes = CASE WHEN ? != '' THEN notes || CHAR(10) || ? ELSE notes END
                WHERE id = ?
            ''', (novo_estado, user_id, solution_description,
                  parts_used, parts_used, duration_hours, duration_hours,
                  notes, notes, id))

            bd.execute('''
                INSERT INTO intervention_edit_log (intervention_id, edited_by, field_name, old_value, new_value)
                VALUES (?, ?, ?, ?, ?)
            ''', (id, user_id, 'status', 'em_curso', f'concluida (Actualização #{update_count + 1})'))

            message = 'Intervenção concluída com sucesso'
        else:
            bd.execute('''
                UPDATE interventions
                SET updated_at = CURRENT_TIMESTAMP, updated_by = ?,
                    solution_description = CASE WHEN ? != '' THEN COALESCE(solution_description || CHAR(10), '') || ? ELSE solution_description END,
                    parts_used = CASE WHEN ? != '' THEN ? ELSE parts_used END,
                    duration_hours = CASE WHEN ? > 0 THEN duration_hours + ? ELSE duration_hours END,
                    notes = CASE WHEN ? != '' THEN COALESCE(notes || CHAR(10), '') || ? ELSE notes END
                WHERE id = ?
            ''', (user_id, solution_description, solution_description,
                  parts_used, parts_used, duration_hours, duration_hours,
                  notes, notes, id))

            if novo_estado:
                bd.execute('''
                    INSERT INTO intervention_edit_log (intervention_id, edited_by, field_name, old_value, new_value)
                    VALUES (?, ?, ?, ?, ?)
                ''', (id, user_id, 'asset_status', current_status, f'{novo_estado} (Actualização #{update_count + 1})'))

            message = f'Estado actualizado. Intervenção continua em curso (Actualização #{update_count + 1})'

        if novo_estado and novo_estado != current_status:
            bd.execute('''
                INSERT OR REPLACE INTO asset_data (asset_id, field_name, field_value)
                VALUES (?, 'condition_status', ?)
            ''', (intervencao['asset_id'], novo_estado))

            bd.execute('''
                INSERT INTO status_change_log (asset_id, previous_status, new_status, description, changed_by, intervention_id)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (intervencao['asset_id'], current_status,
                  novo_estado, descricao_estado or f'Alteração via intervenção #{id}', user_id, id))

        bd.commit()

        return jsonify({
            'message': message,
            'concluded': novo_estado == 'Operacional',
            'update_count': update_count + 1
        })

    except Exception as e:
        bd.rollback()
        return jsonify({'error': str(e)}), 500


@interventions_bp.route('/<int:id>', methods=['PUT'])
@requer_autenticacao
def editar_intervencao(id):
    """Edita/actualiza uma intervenção."""
    dados = request.json

    bd = obter_bd()
    intervencao = bd.execute('SELECT * FROM interventions WHERE id = ?', (id,)).fetchone()

    if not intervencao:
        return jsonify({'error': 'Intervenção não encontrada'}), 404

    if intervencao['status'] == 'concluida' and g.utilizador_atual['role'] != 'admin':
        return jsonify({'error': 'Intervenção já concluída. Apenas administradores podem editar.'}), 403

    user_id = g.utilizador_atual['user_id']
    campos_editaveis = ['problem_description', 'solution_description', 'parts_used',
                        'total_cost', 'duration_hours', 'notes']

    try:
        for campo in campos_editaveis:
            if campo in dados and dados[campo] != intervencao[campo]:
                bd.execute('''
                    INSERT INTO intervention_edit_log (intervention_id, edited_by, field_name, old_value, new_value)
                    VALUES (?, ?, ?, ?, ?)
                ''', (id, user_id, campo, str(intervencao[campo] or ''), str(dados[campo] or '')))

                bd.execute(f'UPDATE interventions SET {campo} = ?, updated_at = CURRENT_TIMESTAMP, updated_by = ? WHERE id = ?',
                           (dados[campo], user_id, id))

        bd.commit()
        return jsonify({'message': 'Intervenção actualizada'})

    except Exception as e:
        bd.rollback()
        return jsonify({'error': str(e)}), 500


@interventions_bp.route('/<int:id>', methods=['DELETE'])
@requer_admin
def eliminar_intervencao(id):
    """Elimina uma intervenção (apenas admin)."""
    bd = obter_bd()

    intervencao = bd.execute('SELECT * FROM interventions WHERE id = ?', (id,)).fetchone()
    if not intervencao:
        return jsonify({'error': 'Intervenção não encontrada'}), 404

    # Eliminar ficheiros físicos
    ficheiros = bd.execute('SELECT file_path FROM intervention_files WHERE intervention_id = ?', (id,)).fetchall()
    for f in ficheiros:
        try:
            if os.path.exists(f['file_path']):
                os.remove(f['file_path'])
        except OSError:
            pass

    bd.execute('DELETE FROM intervention_files WHERE intervention_id = ?', (id,))
    bd.execute('DELETE FROM intervention_technicians WHERE intervention_id = ?', (id,))
    bd.execute('DELETE FROM intervention_edit_log WHERE intervention_id = ?', (id,))
    bd.execute('DELETE FROM intervention_time_logs WHERE intervention_id = ?', (id,))
    bd.execute('DELETE FROM interventions WHERE id = ?', (id,))

    bd.commit()
    return jsonify({'message': 'Intervenção eliminada'})


# ----- FICHEIROS DE INTERVENÇÕES -----

@interventions_bp.route('/<int:id>/files', methods=['POST'])
@requer_autenticacao
def upload_ficheiro_intervencao(id):
    """Faz upload de um ficheiro para uma intervenção."""
    bd = obter_bd()

    intervencao = bd.execute('SELECT * FROM interventions WHERE id = ?', (id,)).fetchone()
    if not intervencao:
        return jsonify({'error': 'Intervenção não encontrada'}), 404

    if 'file' not in request.files:
        return jsonify({'error': 'Nenhum ficheiro enviado'}), 400

    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'Nome do ficheiro vazio'}), 400

    if not allowed_file(file.filename):
        return jsonify({'error': f'Tipo de ficheiro não permitido. Permitidos: {", ".join(config.ALLOWED_EXTENSIONS)}'}), 400

    # Verificar tamanho
    file.seek(0, 2)
    size = file.tell()
    file.seek(0)

    if size > config.MAX_FILE_SIZE:
        return jsonify({'error': f'Ficheiro muito grande. Máximo: {config.MAX_FILE_SIZE / 1024 / 1024}MB'}), 400

    category = request.form.get('category', 'outros')
    description = request.form.get('description', '')
    cost_value = request.form.get('cost_value')

    # Criar pasta da intervenção
    pasta_intervencao = os.path.join(config.PASTA_INTERVENCOES, str(id))
    os.makedirs(pasta_intervencao, exist_ok=True)

    # Gerar nome único
    ext = file.filename.rsplit('.', 1)[1].lower()
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    novo_nome = f"INT{id}_{category}_{timestamp}.{ext}"
    caminho_completo = os.path.join(pasta_intervencao, novo_nome)

    file.save(caminho_completo)

    # Registar na BD
    cursor = bd.execute('''
        INSERT INTO intervention_files (intervention_id, file_category, file_name, original_name, file_path, file_type, file_size, description, cost_value, uploaded_by)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (id, category, novo_nome, file.filename, caminho_completo, ext, size, description,
          float(cost_value) if cost_value else None, g.utilizador_atual['user_id']))

    bd.commit()

    return jsonify({
        'id': cursor.lastrowid,
        'file_name': novo_nome,
        'message': 'Ficheiro carregado com sucesso'
    }), 201


@interventions_bp.route('/<int:id>/files/<int:file_id>', methods=['GET'])
@requer_autenticacao
def download_ficheiro_intervencao(id, file_id):
    """Download de um ficheiro de intervenção."""
    bd = obter_bd()

    ficheiro = bd.execute('''
        SELECT * FROM intervention_files WHERE id = ? AND intervention_id = ?
    ''', (file_id, id)).fetchone()

    if not ficheiro:
        return jsonify({'error': 'Ficheiro não encontrado'}), 404

    if not os.path.exists(ficheiro['file_path']):
        return jsonify({'error': 'Ficheiro físico não encontrado'}), 404

    return send_file(ficheiro['file_path'], as_attachment=True,
                     download_name=ficheiro['original_name'])


@interventions_bp.route('/<int:id>/files/<int:file_id>', methods=['DELETE'])
@requer_autenticacao
def eliminar_ficheiro_intervencao(id, file_id):
    """Elimina um ficheiro de intervenção."""
    bd = obter_bd()

    ficheiro = bd.execute('''
        SELECT * FROM intervention_files WHERE id = ? AND intervention_id = ?
    ''', (file_id, id)).fetchone()

    if not ficheiro:
        return jsonify({'error': 'Ficheiro não encontrado'}), 404

    # Eliminar ficheiro físico
    try:
        if os.path.exists(ficheiro['file_path']):
            os.remove(ficheiro['file_path'])
    except OSError:
        pass

    bd.execute('DELETE FROM intervention_files WHERE id = ?', (file_id,))
    bd.commit()

    return jsonify({'message': 'Ficheiro eliminado'})


# ----- TEMPO DE TRABALHO -----

@interventions_bp.route('/<int:id>/time', methods=['POST'])
@requer_autenticacao
def registar_tempo_intervencao(id):
    """Regista tempo de trabalho numa intervenção."""
    bd = obter_bd()

    intervencao = bd.execute('SELECT * FROM interventions WHERE id = ?', (id,)).fetchone()
    if not intervencao:
        return jsonify({'error': 'Intervenção não encontrada'}), 404

    dados = request.json
    time_spent = dados.get('time_spent', 0)
    description = dados.get('description', '')

    if time_spent <= 0:
        return jsonify({'error': 'Tempo deve ser maior que zero'}), 400

    user_id = g.utilizador_atual['user_id']

    bd.execute('''
        INSERT INTO intervention_time_logs (intervention_id, logged_by, time_spent, description)
        VALUES (?, ?, ?, ?)
    ''', (id, user_id, time_spent, description))

    # Actualizar duração total
    bd.execute('''
        UPDATE interventions SET duration_hours = duration_hours + ?, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
    ''', (time_spent, id))

    bd.commit()

    return jsonify({'message': 'Tempo registado com sucesso'}), 201
