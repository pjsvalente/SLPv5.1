"""
SmartLamppost - Rotas de Gestão do Esquema (Campos Dinâmicos)
"""

import json
import sqlite3
from flask import request, jsonify, g

from app.routes import schema_bp
from app.database import obter_bd, registar_auditoria
from app.utils import requer_autenticacao, requer_admin


@schema_bp.route('', methods=['GET'])
@requer_autenticacao
def obter_esquema():
    """Devolve a lista de campos do esquema."""
    bd = obter_bd()
    campos = bd.execute('SELECT * FROM schema_fields ORDER BY field_order').fetchall()

    resultado = []
    for c in campos:
        campo_dict = dict(c)
        if campo_dict['field_options']:
            campo_dict['field_options'] = json.loads(campo_dict['field_options'])
        resultado.append(campo_dict)

    return jsonify(resultado)


@schema_bp.route('', methods=['POST'])
@requer_admin
def adicionar_campo():
    """Adiciona um novo campo ao esquema."""
    dados = request.json
    campos_obrigatorios = ['field_name', 'field_type', 'field_label', 'required']

    if not all(c in dados for c in campos_obrigatorios):
        return jsonify({'error': 'Campos obrigatórios: field_name, field_type, field_label, required'}), 400

    if not dados['field_name'].replace('_', '').isalnum():
        return jsonify({'error': 'field_name deve conter apenas letras, números e underscores'}), 400

    bd = obter_bd()
    max_ordem = bd.execute('SELECT MAX(field_order) FROM schema_fields').fetchone()[0] or 0
    opcoes = json.dumps(dados.get('field_options')) if dados.get('field_options') else None

    try:
        bd.execute('''
            INSERT INTO schema_fields (field_name, field_type, field_label, required, field_order, field_category, field_options)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (
            dados['field_name'], dados['field_type'], dados['field_label'],
            dados.get('required', 0), dados.get('field_order', max_ordem + 1),
            dados.get('field_category', 'custom'), opcoes
        ))
        bd.commit()
        registar_auditoria(bd, g.utilizador_atual['user_id'], 'CREATE', 'schema_fields', bd.lastrowid, None, dados)
        return jsonify({'message': 'Campo adicionado com sucesso'}), 201
    except sqlite3.IntegrityError:
        return jsonify({'error': 'Campo já existe'}), 400


@schema_bp.route('/<int:field_id>', methods=['PUT'])
@requer_admin
def atualizar_campo(field_id):
    """Atualiza um campo do esquema."""
    dados = request.json
    bd = obter_bd()

    campo_antigo = bd.execute('SELECT * FROM schema_fields WHERE id = ?', (field_id,)).fetchone()
    if not campo_antigo:
        return jsonify({'error': 'Campo não encontrado'}), 404

    opcoes = json.dumps(dados.get('field_options')) if dados.get('field_options') else None

    bd.execute('''
        UPDATE schema_fields
        SET field_label = ?, required = ?, field_order = ?, field_category = ?, field_options = ?
        WHERE id = ?
    ''', (
        dados.get('field_label', campo_antigo['field_label']),
        dados.get('required', campo_antigo['required']),
        dados.get('field_order', campo_antigo['field_order']),
        dados.get('field_category', campo_antigo['field_category']),
        opcoes, field_id
    ))
    bd.commit()
    registar_auditoria(bd, g.utilizador_atual['user_id'], 'UPDATE', 'schema_fields', field_id, dict(campo_antigo), dados)
    return jsonify({'message': 'Campo atualizado'})


@schema_bp.route('/<int:field_id>', methods=['DELETE'])
@requer_admin
def eliminar_campo(field_id):
    """Elimina um campo do esquema e os dados associados."""
    bd = obter_bd()

    campo = bd.execute('SELECT * FROM schema_fields WHERE id = ?', (field_id,)).fetchone()
    if not campo:
        return jsonify({'error': 'Campo não encontrado'}), 404

    bd.execute('DELETE FROM asset_data WHERE field_name = ?', (campo['field_name'],))
    bd.execute('DELETE FROM schema_fields WHERE id = ?', (field_id,))
    bd.commit()
    registar_auditoria(bd, g.utilizador_atual['user_id'], 'DELETE', 'schema_fields', field_id, dict(campo), None)
    return jsonify({'message': 'Campo eliminado'})
