"""
SmartLamppost - Rotas de Gestão de Utilizadores
"""

import sqlite3
from flask import request, jsonify, g

from app.routes import users_bp
from app.database import obter_bd
from app.utils import requer_autenticacao, requer_admin, hash_password


@users_bp.route('/technicians', methods=['GET'])
@requer_autenticacao
def listar_tecnicos():
    """Lista utilizadores que podem ser tecnicos (operators e admins)."""
    bd = obter_bd()
    users = bd.execute('''
        SELECT id, username, role, first_name, last_name, email FROM users
        WHERE role IN ('admin', 'operator')
        ORDER BY first_name, last_name, username
    ''').fetchall()
    result = []
    for u in users:
        user_dict = dict(u)
        if u['first_name'] and u['last_name']:
            user_dict['display_name'] = f"{u['first_name']} {u['last_name']}"
        else:
            user_dict['display_name'] = u['username']
        result.append(user_dict)
    return jsonify(result)


@users_bp.route('', methods=['GET'])
@requer_admin
def listar_utilizadores():
    """Lista todos os utilizadores do sistema."""
    bd = obter_bd()
    utilizadores = bd.execute(
        'SELECT id, username, role, first_name, last_name, email, created_at, last_login FROM users'
    ).fetchall()
    return jsonify([dict(u) for u in utilizadores])


@users_bp.route('', methods=['POST'])
@requer_admin
def criar_utilizador():
    """Cria um novo utilizador."""
    dados = request.json
    username = dados.get('username')
    password = dados.get('password')
    role = dados.get('role', 'operator')
    first_name = dados.get('first_name')
    last_name = dados.get('last_name')
    email = dados.get('email')

    if not username or not password:
        return jsonify({'error': 'Username e password obrigatórios'}), 400

    if not first_name or not last_name or not email:
        return jsonify({'error': 'Nome, apelido e email são obrigatórios'}), 400

    if role not in ['admin', 'operator', 'visitor']:
        return jsonify({'error': 'Role inválido. Deve ser: admin, operator ou visitor'}), 400

    bd = obter_bd()
    try:
        bd.execute('''
            INSERT INTO users (username, password_hash, role, first_name, last_name, email)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (username, hash_password(password), role, first_name, last_name, email))
        bd.commit()
        return jsonify({'message': 'Utilizador criado com sucesso'}), 201
    except sqlite3.IntegrityError:
        return jsonify({'error': 'Username já existe'}), 400


@users_bp.route('/<int:user_id>', methods=['PUT'])
@requer_admin
def actualizar_utilizador(user_id):
    """Actualiza um utilizador existente."""
    dados = request.json
    bd = obter_bd()

    user = bd.execute('SELECT * FROM users WHERE id = ?', (user_id,)).fetchone()
    if not user:
        return jsonify({'error': 'Utilizador não encontrado'}), 404

    # Campos actualizáveis
    first_name = dados.get('first_name', user['first_name'])
    last_name = dados.get('last_name', user['last_name'])
    email = dados.get('email', user['email'])
    role = dados.get('role', user['role'])

    if role not in ['admin', 'operator', 'visitor']:
        return jsonify({'error': 'Role inválido'}), 400

    bd.execute('''
        UPDATE users SET first_name = ?, last_name = ?, email = ?, role = ? WHERE id = ?
    ''', (first_name, last_name, email, role, user_id))

    # Se foi fornecida nova password
    if dados.get('password'):
        bd.execute('UPDATE users SET password_hash = ? WHERE id = ?',
                   (hash_password(dados['password']), user_id))

    bd.commit()
    return jsonify({'message': 'Utilizador actualizado'})


@users_bp.route('/<int:user_id>', methods=['DELETE'])
@requer_admin
def eliminar_utilizador(user_id):
    """Elimina um utilizador."""
    if user_id == g.utilizador_atual['user_id']:
        return jsonify({'error': 'Não pode eliminar a própria conta'}), 400

    bd = obter_bd()
    bd.execute('DELETE FROM sessions WHERE user_id = ?', (user_id,))
    bd.execute('DELETE FROM users WHERE id = ?', (user_id,))
    bd.commit()
    return jsonify({'message': 'Utilizador eliminado'})
