"""
SmartLamppost - Rotas de Gestão de Técnicos Externos
"""

from flask import request, jsonify, g

from app.routes import technicians_bp
from app.database import obter_bd
from app.utils import requer_autenticacao, requer_admin


@technicians_bp.route('', methods=['GET'])
@requer_autenticacao
def listar_tecnicos_externos():
    """Lista todos os técnicos externos activos."""
    bd = obter_bd()
    tecnicos = bd.execute('''
        SELECT et.*, u.username as created_by_name
        FROM external_technicians et
        LEFT JOIN users u ON et.created_by = u.id
        WHERE et.active = 1
        ORDER BY et.company, et.name
    ''').fetchall()
    return jsonify([dict(t) for t in tecnicos])


@technicians_bp.route('', methods=['POST'])
@requer_autenticacao
def criar_tecnico_externo():
    """Cria um novo técnico externo."""
    dados = request.json

    if not dados.get('name') or not dados.get('company'):
        return jsonify({'error': 'Nome e empresa são obrigatórios'}), 400

    bd = obter_bd()
    try:
        cursor = bd.execute('''
            INSERT INTO external_technicians (name, company, phone, email, notes, created_by)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (dados['name'], dados['company'], dados.get('phone'),
              dados.get('email'), dados.get('notes'), g.utilizador_atual['user_id']))
        bd.commit()
        return jsonify({'id': cursor.lastrowid, 'message': 'Técnico externo criado'}), 201
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@technicians_bp.route('/<int:id>', methods=['PUT'])
@requer_autenticacao
def atualizar_tecnico_externo(id):
    """Atualiza um técnico externo."""
    dados = request.json
    bd = obter_bd()

    tecnico = bd.execute('SELECT * FROM external_technicians WHERE id = ?', (id,)).fetchone()
    if not tecnico:
        return jsonify({'error': 'Técnico não encontrado'}), 404

    bd.execute('''
        UPDATE external_technicians
        SET name = ?, company = ?, phone = ?, email = ?, notes = ?
        WHERE id = ?
    ''', (
        dados.get('name', tecnico['name']),
        dados.get('company', tecnico['company']),
        dados.get('phone', tecnico['phone']),
        dados.get('email', tecnico['email']),
        dados.get('notes', tecnico['notes']),
        id
    ))
    bd.commit()

    return jsonify({'message': 'Técnico atualizado'})


@technicians_bp.route('/<int:id>', methods=['DELETE'])
@requer_admin
def desativar_tecnico_externo(id):
    """Desactiva um técnico externo (soft delete)."""
    bd = obter_bd()
    bd.execute('UPDATE external_technicians SET active = 0 WHERE id = ?', (id,))
    bd.commit()
    return jsonify({'message': 'Técnico externo desativado'})
