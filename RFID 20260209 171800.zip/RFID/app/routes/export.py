"""
SmartLamppost - Rotas de Exportação e Importação
"""

import re
import json
from io import BytesIO
from datetime import datetime
from flask import request, jsonify, g, send_file

from app.routes import export_bp
from app.database import obter_bd, registar_auditoria
from app.utils import requer_autenticacao, requer_admin
from app.extensions import EXCEL_DISPONIVEL
from app.routes.assets import gerar_proximo_serial

if EXCEL_DISPONIVEL:
    from openpyxl import Workbook, load_workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side, numbers
    from openpyxl.utils import get_column_letter


# ── Definição de colunas fixas para exportação ────────────────────────────────

NOMES_MODULOS_FIXOS = [
    'Luminária 1', 'Luminária 2', 'Q. Elétrico', 'Cofrete', 'Telemetria',
    'Carregador EV', 'MUPI', 'Lateral', 'Antena'
]

# (label_legível, nome_campo_bd)
COLUNAS_BASE = [
    ('Nº Série', 'serial_number'),
    ('Data Criação', 'created_at'),
    ('Última Atualização', 'updated_at'),
    ('Tipo de Luminária', 'luminaire_type'),
    ('RFID Tag', 'rfid_tag'),
    ('Referência do Produto', 'product_reference'),
    ('Fabricante', 'manufacturer'),
    ('Modelo', 'model'),
    ('Data de Instalação', 'installation_date'),
    ('Localização', 'installation_location'),
    ('GPS Latitude', 'gps_latitude'),
    ('GPS Longitude', 'gps_longitude'),
    ('Município', 'municipality'),
    ('Morada', 'street_address'),
    ('Última Inspeção', 'last_inspection_date'),
    ('Próxima Inspeção', 'next_inspection_date'),
    ('Próxima Manutenção', 'next_maintenance_date'),
    ('Notas de Manutenção', 'maintenance_notes'),
    ('Estado', 'condition_status'),
    ('Observações', 'notes'),
]

COLUNAS_SPECS = [
    ('Altura (m)', 'height_meters'),
    ('Material', 'material'),
    ('Cor da Coluna', 'column_color'),
    ('Potência (W)', 'power_watts'),
    ('Tipologia de Ligação', 'connection_type'),
    ('Fim da Garantia', 'warranty_end_date'),
    ('Certificado de Garantia', 'warranty_certificate'),
    # Balanço Elétrico
    ('Potência Máx Q.E./Cofrete (W)', 'electrical_max_power'),
    ('Potência Instalada (W)', 'total_installed_power'),
    ('Potência Restante (W)', 'remaining_power'),
    ('Tipologia Ligação (Balanço)', 'electrical_connection_type'),
]


# ── Rotas ─────────────────────────────────────────────────────────────────────

@export_bp.route('/export/excel/fields', methods=['GET'])
@requer_autenticacao
def campos_disponiveis_export():
    """Lista campos disponiveis para exportacao, agrupados por categoria."""
    bd = obter_bd()
    esquema = bd.execute('SELECT * FROM schema_fields ORDER BY field_category, field_order').fetchall()

    categorias = {}
    for campo in esquema:
        cat = campo['field_category']
        if cat not in categorias:
            categorias[cat] = []
        categorias[cat].append({
            'field_name': campo['field_name'],
            'field_label': campo['field_label'],
            'field_type': campo['field_type']
        })

    nomes_categorias = {
        'identification': 'Identificacao', 'specifications': 'Especificacoes',
        'installation': 'Instalacao', 'warranty': 'Garantia',
        'maintenance': 'Manutencao', 'equipment': 'Equipamento',
        'other': 'Outros', 'custom': 'Personalizados'
    }

    return jsonify([
        {'category': cat, 'category_label': nomes_categorias.get(cat, cat.title()), 'fields': campos}
        for cat, campos in categorias.items()
    ])


@export_bp.route('/export/excel', methods=['GET', 'POST'])
@requer_autenticacao
def exportar_excel():
    """Exporta todos os dados para Excel."""
    if not EXCEL_DISPONIVEL:
        return jsonify({'error': 'Funcionalidade Excel não disponível'}), 500

    try:
        campos_selecionados = None
        if request.method == 'POST' and request.is_json:
            dados = request.get_json(silent=True) or {}
            campos_selecionados = dados.get('fields')

        output = criar_ficheiro_excel(campos_selecionados)
        return send_file(
            output,
            mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            as_attachment=True,
            download_name=f'smartlamppost_export_{datetime.now().strftime("%Y%m%d_%H%M%S")}.xlsx'
        )
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@export_bp.route('/import/preview', methods=['POST'])
@requer_admin
def preview_import():
    """Analisa ficheiro Excel e retorna preview sem importar."""
    if not EXCEL_DISPONIVEL:
        return jsonify({'error': 'Funcionalidade Excel não disponível'}), 500

    if 'file' not in request.files:
        return jsonify({'error': 'Nenhum ficheiro enviado'}), 400

    ficheiro = request.files['file']
    if ficheiro.filename == '':
        return jsonify({'error': 'Nome do ficheiro vazio'}), 400

    try:
        wb = load_workbook(ficheiro)
        bd = obter_bd()

        # Encontrar folha de ativos
        ws_ativos = None
        for nome in wb.sheetnames:
            if nome.lower().strip() == 'ativos':
                ws_ativos = wb[nome]
                break
        if ws_ativos is None and len(wb.sheetnames) >= 1:
            ws_ativos = wb[wb.sheetnames[0]]

        if ws_ativos is None:
            return jsonify({'error': 'Folha de ativos não encontrada'}), 400

        # Ler dados
        rows = _read_sheet_data(ws_ativos)

        # Analisar cada linha
        preview_items = []
        stats = {
            'total': 0, 'novos': 0, 'existentes': 0, 'sem_alteracoes': 0,
            'seriais_gerados': 0, 'forcados_suspensos': 0, 'erros': 0
        }

        for row_data in rows:
            sn = row_data.get('serial_number')
            if sn is not None:
                sn = str(sn).strip()

            # Verificar campos obrigatórios
            missing_fields = _check_mandatory_fields(row_data)
            will_be_suspended = len(missing_fields) > 0

            item = {
                'excel_row': row_data.get('_excel_row', '?'),
                'serial_number': sn or '',
                'serial_gerado': False,
                'condition_status': str(row_data.get('condition_status') or '').strip(),
                'rfid_tag': str(row_data.get('rfid_tag') or '').strip()[:20] if row_data.get('rfid_tag') else '',
                'location': str(row_data.get('installation_location') or '').strip()[:30] if row_data.get('installation_location') else '',
                'manufacturer': str(row_data.get('manufacturer') or '').strip()[:20] if row_data.get('manufacturer') else '',
                'model': str(row_data.get('model') or '').strip()[:20] if row_data.get('model') else '',
                'status': 'ok',
                'action': 'criar',
                'will_be_suspended': will_be_suspended,
                'missing_fields': missing_fields,
                'error': None
            }

            # Se serial vazio, vai ser gerado automaticamente
            if not sn:
                item['serial_gerado'] = True
                item['serial_number'] = '[Auto]'
                stats['seriais_gerados'] += 1
                item['action'] = 'criar'
                stats['novos'] += 1
            else:
                # Verificar se existe
                existe = bd.execute(
                    'SELECT id FROM assets WHERE serial_number = ?', (sn,)
                ).fetchone()

                if existe:
                    asset_id = existe['id']
                    # Verificar se há alterações
                    current_data = _get_asset_current_data(bd, asset_id)
                    current_modules = _get_asset_current_modules(bd, asset_id)
                    excel_modules = _extract_modules_from_row(row_data)

                    if _compare_asset_data(current_data, row_data, current_modules, excel_modules, debug_serial=sn):
                        item['action'] = 'sem_alteracoes'
                        stats['sem_alteracoes'] += 1
                    else:
                        item['action'] = 'atualizar'
                        stats['existentes'] += 1
                else:
                    item['action'] = 'criar'
                    stats['novos'] += 1

            # Contar forçados suspensos
            if will_be_suspended and item['condition_status'].lower() != 'suspenso':
                stats['forcados_suspensos'] += 1

            stats['total'] += 1
            preview_items.append(item)

        return jsonify({
            'success': True,
            'filename': ficheiro.filename,
            'stats': stats,
            'preview': preview_items[:100],  # Limitar a 100 para performance
            'total_rows': len(preview_items),
            'truncated': len(preview_items) > 100
        })

    except Exception as e:
        return jsonify({'error': f'Erro ao analisar ficheiro: {str(e)}'}), 500


@export_bp.route('/import/excel', methods=['POST'])
@requer_admin
def importar_excel():
    """Importa dados de um ficheiro Excel (4 folhas)."""
    if not EXCEL_DISPONIVEL:
        return jsonify({'error': 'Funcionalidade Excel não disponível'}), 500

    if 'file' not in request.files:
        return jsonify({'error': 'Nenhum ficheiro enviado'}), 400

    ficheiro = request.files['file']
    if ficheiro.filename == '':
        return jsonify({'error': 'Nome do ficheiro vazio'}), 400

    modo = request.form.get('mode', 'update')
    convert_suspended = request.form.get('convert_suspended', 'true').lower() == 'true'

    try:
        wb = load_workbook(ficheiro)
        bd = obter_bd()
        user_id = g.utilizador_atual['user_id']
        user_cache = _build_user_lookup(bd)

        stats = {
            'ativos': {
                'criados': 0, 'atualizados': 0, 'ignorados': 0, 'sem_alteracoes': 0,
                'modulos_importados': 0, 'suspensos_convertidos': 0, 'suspensos_bloqueados': 0,
                'seriais_gerados': 0, 'forcados_suspensos': 0
            },
            'intervencoes': {'criadas': 0, 'tecnicos_associados': 0},
            'historico_estados': {'criados': 0},
            'historico_actualizacoes': {'criadas': 0},
            'erros': [],
        }

        # Obter folhas por nome ou índice
        ws_ativos = None
        ws_hist_estados = None
        ws_intervencoes = None
        ws_hist_actualizacoes = None

        nomes_folhas = wb.sheetnames
        for nome in nomes_folhas:
            nl = nome.lower().strip()
            if nl == 'ativos':
                ws_ativos = wb[nome]
            elif 'estado' in nl:
                ws_hist_estados = wb[nome]
            elif 'interven' in nl:
                ws_intervencoes = wb[nome]
            elif 'actualiza' in nl or 'atualiza' in nl:
                ws_hist_actualizacoes = wb[nome]

        # Fallback por índice se não encontrou por nome
        if ws_ativos is None and len(nomes_folhas) >= 1:
            ws_ativos = wb[nomes_folhas[0]]

        # 1. Ativos → serial_to_id
        serial_to_id = {}
        if ws_ativos:
            _import_sheet_ativos(bd, ws_ativos, modo, user_id, user_cache, serial_to_id, stats, convert_suspended)

        # Se serial_to_id está vazio, carregar da BD
        if not serial_to_id:
            for row in bd.execute('SELECT id, serial_number FROM assets').fetchall():
                serial_to_id[row['serial_number']] = row['id']

        # 2. Intervenções → int_id_map
        int_id_map = {}
        if ws_intervencoes:
            _import_sheet_intervencoes(bd, ws_intervencoes, user_id, user_cache, serial_to_id, int_id_map, stats)

        # 3. Histórico Estados
        if ws_hist_estados:
            _import_sheet_historico_estados(bd, ws_hist_estados, user_id, user_cache, serial_to_id, int_id_map, stats)

        # 4. Histórico Actualizações
        if ws_hist_actualizacoes:
            _import_sheet_historico_actualizacoes(bd, ws_hist_actualizacoes, user_id, user_cache, int_id_map, stats)

        registar_auditoria(bd, user_id, 'IMPORT_EXCEL', 'assets', None, None, {
            'filename': ficheiro.filename,
            'mode': modo,
            'statistics': {k: v for k, v in stats.items() if k != 'erros'},
            'errors': len(stats['erros']),
        })
        bd.commit()

        return jsonify({
            'success': True,
            'mode': modo,
            'statistics': {k: v for k, v in stats.items() if k != 'erros'},
            'errors': stats['erros'][:50],
            'total_errors': len(stats['erros']),
        })

    except Exception as e:
        try:
            bd.rollback()
        except Exception:
            pass
        return jsonify({'error': f'Erro ao processar ficheiro: {str(e)}'}), 500


# Campos a excluir de asset_data (vão para tabela assets ou são colunas de módulos/derivados)
_SKIP_FROM_ASSET_DATA = {
    'serial_number', 'created_at', 'updated_at',
}
# Colunas de módulos fixos
for _mn in NOMES_MODULOS_FIXOS:
    _slug = _mn.lower().replace(' ', '_').replace('.', '')
    _SKIP_FROM_ASSET_DATA.add(f'mod_{_slug}_desc')
    _SKIP_FROM_ASSET_DATA.add(f'mod_{_slug}_serial')
# Colunas de módulos adicionais
for _i in range(1, 6):
    _SKIP_FROM_ASSET_DATA.add(f'mod_adicional_{_i}_nome')
    _SKIP_FROM_ASSET_DATA.add(f'mod_adicional_{_i}_serial')
# Colunas derivadas de última manutenção
_SKIP_FROM_ASSET_DATA.update({'last_maint_date', 'last_maint_type', 'last_maint_desc', 'last_maint_by'})

# Campos de data em asset_data que precisam de conversão
_DATE_FIELDS_ASSET = {
    'installation_date', 'last_inspection_date', 'next_inspection_date',
    'next_maintenance_date', 'warranty_end_date',
}

# Slugs dos módulos fixos (na mesma ordem de NOMES_MODULOS_FIXOS)
_MODULE_SLUGS = [n.lower().replace(' ', '_').replace('.', '') for n in NOMES_MODULOS_FIXOS]

# Campos obrigatórios para um ativo ser Operacional
_CAMPOS_OBRIGATORIOS = {'rfid_tag', 'manufacturer', 'model'}

# Campos a ignorar na comparação "Sem alterações"
# Inclui variantes de nomes que podem vir do Excel (headers sanitizados)
_CAMPOS_IGNORAR_COMPARACAO = {
    # IDs e timestamps do sistema
    'id', 'created_at', 'created_by', 'updated_at', 'updated_by',
    # Variantes sanitizadas (Excel headers)
    'createdat', 'updatedat', 'createdby', 'updatedby',
    'data_criacao', 'data_criação', 'ultima_atualizacao', 'última_atualização',
    # Notas (podem variar entre importações)
    'notes', 'observations', 'comentarios', 'notas',
    # Metadados internos
    '_excel_row',
}


def _normalize_value(val):
    """Normaliza um valor para comparação.

    Trata:
    - None/empty → ''
    - Floats inteiros (100.0) → '100'
    - Datas em diferentes formatos → 'YYYY-MM-DD' ou 'YYYY-MM-DD HH:MM:SS'
    - Whitespace e trim
    """
    if val is None:
        return ''

    # Se for datetime, converter para string ISO
    if isinstance(val, datetime):
        return val.strftime('%Y-%m-%d %H:%M:%S')

    s = str(val).strip()

    if not s:
        return ''

    # Números: remover .0 trailing (Excel lê inteiros como floats)
    if s.replace('.', '', 1).replace('-', '', 1).isdigit():
        try:
            f = float(s)
            if f == int(f):
                return str(int(f))
            return s
        except (ValueError, OverflowError):
            pass

    # Datas: normalizar formato DD/MM/YYYY → YYYY-MM-DD
    # e DD/MM/YYYY HH:MM:SS → YYYY-MM-DD HH:MM:SS
    date_patterns = [
        ('%d/%m/%Y %H:%M:%S', '%Y-%m-%d %H:%M:%S'),
        ('%d/%m/%Y', '%Y-%m-%d'),
        ('%d\\%m\\%Y %H:%M:%S', '%Y-%m-%d %H:%M:%S'),
        ('%d\\%m\\%Y', '%Y-%m-%d'),
    ]
    for fmt_in, fmt_out in date_patterns:
        try:
            dt = datetime.strptime(s, fmt_in)
            return dt.strftime(fmt_out)
        except ValueError:
            continue

    # Datas já em formato ISO: normalizar microsegundos
    if len(s) > 19 and '.' in s:
        # Ex: 2026-01-29 17:19:26.076942 → 2026-01-29 17:19:26
        try:
            dt = datetime.strptime(s[:19], '%Y-%m-%d %H:%M:%S')
            return dt.strftime('%Y-%m-%d %H:%M:%S')
        except ValueError:
            pass

    return s


def _get_asset_current_data(bd, asset_id):
    """Obtém os dados atuais de um ativo da BD."""
    rows = bd.execute(
        'SELECT field_name, field_value FROM asset_data WHERE asset_id = ?',
        (asset_id,)
    ).fetchall()
    return {row['field_name']: row['field_value'] or '' for row in rows}


def _get_asset_current_modules(bd, asset_id):
    """Obtém os módulos atuais de um ativo da BD, normalizados para comparação."""
    rows = bd.execute(
        'SELECT module_name, module_description, serial_number FROM asset_module_serials WHERE asset_id = ?',
        (asset_id,)
    ).fetchall()
    # Retorna set de tuplos (module_name_normalizado, serial_normalizado)
    modules = set()
    for row in rows:
        mn = _normalize_value(row['module_name'])
        sn = _normalize_value(row['serial_number'])
        if mn or sn:
            modules.add((mn, sn))
    return modules


def _extract_modules_from_row(row_data):
    """Extrai módulos do row_data do Excel, normalizados para comparação."""
    modules = set()

    # Módulos fixos
    for i, nome_mod in enumerate(NOMES_MODULOS_FIXOS):
        slug = _MODULE_SLUGS[i]
        desc = row_data.get(f'mod_{slug}_desc')
        serial = row_data.get(f'mod_{slug}_serial')

        if desc is not None:
            desc = str(desc).strip()
        if serial is not None:
            serial = str(serial).strip()

        if desc or serial:
            # module_name é o nome limpo do tipo
            modules.add((_normalize_value(nome_mod), _normalize_value(serial)))

    # Módulos adicionais
    for i in range(1, 6):
        nome = row_data.get(f'mod_adicional_{i}_nome')
        serial = row_data.get(f'mod_adicional_{i}_serial')

        if nome is not None:
            nome = str(nome).strip()
        if serial is not None:
            serial = str(serial).strip()

        if nome or serial:
            module_name = f'Módulo Adicional {i}'
            modules.add((_normalize_value(module_name), _normalize_value(serial)))

    return modules


def _field_should_ignore(field):
    """Verifica se um campo deve ser ignorado na comparação (case-insensitive)."""
    if not field:
        return True
    f_lower = field.lower().replace(' ', '_').replace('-', '_')
    # Verificar contra lista de ignorar (já em lowercase no set)
    for ignore_field in _CAMPOS_IGNORAR_COMPARACAO:
        if f_lower == ignore_field.lower() or f_lower.endswith(ignore_field.lower()):
            return True
    # Ignorar campos que contenham timestamp/data no nome
    if any(kw in f_lower for kw in ['created', 'updated', '_at', 'timestamp']):
        return True
    return False


def _compare_asset_data(current_data, excel_row_data, current_modules, excel_modules, debug_serial=None):
    """Compara dados atuais com dados do Excel. Retorna True se iguais (sem alterações)."""
    # Colectar todos os campos relevantes de ambos os lados
    all_fields = set()

    for field in excel_row_data.keys():
        if not field.startswith('_') and field not in _SKIP_FROM_ASSET_DATA and not _field_should_ignore(field):
            all_fields.add(field)

    for field in current_data.keys():
        if not _field_should_ignore(field):
            all_fields.add(field)

    # DEBUG: Lista de diferenças encontradas
    diferencas = []

    # Comparar cada campo
    for field in all_fields:
        excel_val = _normalize_value(excel_row_data.get(field))
        current_val = _normalize_value(current_data.get(field, ''))

        # Ignorar campos vazios em ambos
        if not excel_val and not current_val:
            continue

        if excel_val != current_val:
            diferencas.append(f"  {field}: BD='{current_val}' vs Excel='{excel_val}'")

    # Comparar módulos
    modules_diff = current_modules != excel_modules
    if modules_diff:
        diferencas.append(f"  [MÓDULOS] BD={current_modules} vs Excel={excel_modules}")

    # DEBUG: Imprimir diferenças se existirem
    if diferencas and debug_serial:
        print(f"[DEBUG IMPORT] {debug_serial} - DIFERENÇAS ENCONTRADAS:")
        for d in diferencas:
            print(d)
    elif debug_serial:
        print(f"[DEBUG IMPORT] {debug_serial} - SEM DIFERENÇAS (identical)")

    return len(diferencas) == 0


def _check_mandatory_fields(row_data):
    """Verifica se os campos obrigatórios estão preenchidos.
    Retorna lista de campos em falta.
    """
    missing = []
    for field in _CAMPOS_OBRIGATORIOS:
        val = row_data.get(field)
        if val is None or str(val).strip() == '':
            missing.append(field)
    return missing


def _force_suspenso_if_missing_mandatory(bd, asset_id, row_data, user_id, stats_erros=None):
    """Força condition_status = 'Suspenso' se campos obrigatórios em falta.
    Retorna True se foi forçado para Suspenso.
    """
    missing = _check_mandatory_fields(row_data)
    if not missing:
        return False

    # Obter status atual do Excel
    excel_status = _normalize_value(row_data.get('condition_status', ''))

    # Se já é Suspenso, não precisa forçar
    if excel_status.lower() == 'suspenso':
        return False

    # Forçar para Suspenso
    bd.execute(
        "INSERT OR REPLACE INTO asset_data (asset_id, field_name, field_value) VALUES (?, 'condition_status', 'Suspenso')",
        (asset_id,)
    )

    if stats_erros is not None:
        sn_row = bd.execute('SELECT serial_number FROM assets WHERE id = ?', (asset_id,)).fetchone()
        sn = sn_row['serial_number'] if sn_row else '?'
        campos = ', '.join(missing)
        stats_erros.append(f'{sn}: Forçado Suspenso - campos em falta: {campos}')

    return True


def _import_sheet_ativos(bd, ws, modo, user_id, user_cache, serial_to_id, stats, convert_suspended=True):
    """Importa Sheet 1: Ativos.

    Args:
        modo: 'create' (apenas criar), 'update' (apenas atualizar), 'upsert' (ambos), 'skip' (alias de create)
        convert_suspended: Se True, converte ativos com condition_status='Suspenso' para 'Operacional'

    Comportamentos:
        1. Se serial_number vazio → gera automaticamente (só em modos que criam)
        2. Se ativo existente e dados iguais → "sem alterações" (não toca na BD)
        3. Se campos obrigatórios em falta → força condition_status='Suspenso'

    Modos:
        - 'create' / 'skip': Apenas criar novos. Existentes são ignorados.
        - 'update': Apenas atualizar existentes. Novos são ignorados.
        - 'upsert': Criar novos e atualizar existentes.
    """
    rows = _read_sheet_data(ws)
    st = stats['ativos']

    # Normalizar modo: 'skip' é alias de 'create'
    if modo == 'skip':
        modo = 'create'

    for row_data in rows:
        try:
            excel_row = row_data.get('_excel_row', '?')
            sn = row_data.get('serial_number')
            if sn is not None:
                sn = str(sn).strip()

            # Verificar se ativo existe ANTES de gerar serial
            ativo_existente = None
            if sn:
                ativo_existente = bd.execute(
                    'SELECT id FROM assets WHERE serial_number = ?', (sn,)
                ).fetchone()

            # Se Nº Série vazio, gerar automaticamente (só em modos que criam)
            serial_gerado = False
            if not sn:
                if modo == 'update':
                    # Modo update: ignorar linhas sem serial (não pode criar)
                    st['ignorados'] += 1
                    continue
                sn = gerar_proximo_serial(bd, 'assets')
                row_data['serial_number'] = sn
                serial_gerado = True
                st['seriais_gerados'] += 1

            if ativo_existente:
                asset_id = ativo_existente['id']
                serial_to_id[sn] = asset_id

                # Modo 'create': ignorar existentes
                if modo == 'create':
                    st['ignorados'] += 1
                    continue

                # Modos 'update' e 'upsert': verificar se há alterações antes de atualizar
                current_data = _get_asset_current_data(bd, asset_id)
                current_modules = _get_asset_current_modules(bd, asset_id)
                excel_modules = _extract_modules_from_row(row_data)

                if _compare_asset_data(current_data, row_data, current_modules, excel_modules, debug_serial=sn):
                    # Sem alterações - não tocar na BD
                    st['sem_alteracoes'] += 1
                    continue

                # Há alterações - fazer UPDATE
                bd.execute(
                    'UPDATE assets SET updated_at = CURRENT_TIMESTAMP, updated_by = ? WHERE id = ?',
                    (user_id, asset_id)
                )

                # INSERT OR REPLACE asset_data
                for field, val in row_data.items():
                    if field.startswith('_') or field in _SKIP_FROM_ASSET_DATA:
                        continue
                    if val is None:
                        continue
                    str_val = str(val).strip() if val else ''
                    if not str_val:
                        continue
                    if field in _DATE_FIELDS_ASSET:
                        str_val = _parse_date_import(val) or str_val
                    bd.execute(
                        'INSERT OR REPLACE INTO asset_data (asset_id, field_name, field_value) VALUES (?, ?, ?)',
                        (asset_id, field, str_val)
                    )

                # DELETE + re-INSERT módulos
                bd.execute('DELETE FROM asset_module_serials WHERE asset_id = ?', (asset_id,))
                st['modulos_importados'] += _import_modules_for_asset(bd, asset_id, user_id, row_data)
                st['atualizados'] += 1

                # Verificar campos obrigatórios e forçar Suspenso se necessário
                if _force_suspenso_if_missing_mandatory(bd, asset_id, row_data, user_id, stats['erros']):
                    st['forcados_suspensos'] += 1
                # Converter Suspenso → Operacional se solicitado (só se não foi forçado)
                elif convert_suspended:
                    conv, bloq = _convert_suspended_to_operational(bd, asset_id, user_id, stats['erros'])
                    st['suspensos_convertidos'] += conv
                    st['suspensos_bloqueados'] += bloq
            else:
                # Ativo não existe - verificar modo
                if modo == 'update':
                    # Modo update: ignorar novos (não criar)
                    st['ignorados'] += 1
                    continue

                # Modos 'create' e 'upsert': criar novo asset
                cursor = bd.execute(
                    'INSERT INTO assets (serial_number, created_by, updated_by) VALUES (?, ?, ?)',
                    (sn, user_id, user_id)
                )
                asset_id = cursor.lastrowid
                serial_to_id[sn] = asset_id

                # INSERT asset_data
                for field, val in row_data.items():
                    if field.startswith('_') or field in _SKIP_FROM_ASSET_DATA:
                        continue
                    if val is None:
                        continue
                    str_val = str(val).strip() if val else ''
                    if not str_val:
                        continue
                    if field in _DATE_FIELDS_ASSET:
                        str_val = _parse_date_import(val) or str_val
                    bd.execute(
                        'INSERT INTO asset_data (asset_id, field_name, field_value) VALUES (?, ?, ?)',
                        (asset_id, field, str_val)
                    )

                # INSERT módulos
                st['modulos_importados'] += _import_modules_for_asset(bd, asset_id, user_id, row_data)
                st['criados'] += 1

                # Verificar campos obrigatórios e forçar Suspenso se necessário
                if _force_suspenso_if_missing_mandatory(bd, asset_id, row_data, user_id, stats['erros']):
                    st['forcados_suspensos'] += 1
                # Converter Suspenso → Operacional se solicitado (só se não foi forçado)
                elif convert_suspended:
                    conv, bloq = _convert_suspended_to_operational(bd, asset_id, user_id, stats['erros'])
                    st['suspensos_convertidos'] += conv
                    st['suspensos_bloqueados'] += bloq

        except Exception as e:
            stats['erros'].append(f'Ativos linha {row_data.get("_excel_row", "?")}: {e}')


def _convert_suspended_to_operational(bd, asset_id, user_id, stats_erros=None):
    """Converte ativo Suspenso para Operacional. Retorna (convertidos, bloqueados).

    Só converte se o ativo tiver todos os campos obrigatórios preenchidos:
    - rfid_tag, manufacturer, model
    """
    status_row = bd.execute(
        "SELECT field_value FROM asset_data WHERE asset_id = ? AND field_name = 'condition_status'",
        (asset_id,)
    ).fetchone()

    if status_row and status_row['field_value'] == 'Suspenso':
        # Verificar campos obrigatórios
        missing = []
        for field in _CAMPOS_OBRIGATORIOS:
            row = bd.execute(
                "SELECT field_value FROM asset_data WHERE asset_id = ? AND field_name = ?",
                (asset_id, field)
            ).fetchone()
            val = (row['field_value'] or '').strip() if row else ''
            if not val:
                missing.append(field)

        if missing:
            # Campos em falta - NÃO converter, manter Suspenso
            if stats_erros is not None:
                sn_row = bd.execute('SELECT serial_number FROM assets WHERE id = ?', (asset_id,)).fetchone()
                sn = sn_row['serial_number'] if sn_row else '?'
                campos = ', '.join(missing)
                stats_erros.append(f'{sn}: campos em falta ({campos}) - manteve Suspenso')
            return (0, 1)  # (convertidos=0, bloqueados=1)

        # Todos os campos presentes - converter para Operacional
        bd.execute(
            "UPDATE asset_data SET field_value = 'Operacional' WHERE asset_id = ? AND field_name = 'condition_status'",
            (asset_id,)
        )
        # Registar mudança de estado
        bd.execute('''
            INSERT INTO status_change_log (asset_id, previous_status, new_status, description, changed_by)
            VALUES (?, 'Suspenso', 'Operacional', 'Convertido durante importação Excel', ?)
        ''', (asset_id, user_id))
        return (1, 0)  # (convertidos=1, bloqueados=0)
    return (0, 0)


def _import_modules_for_asset(bd, asset_id, user_id, row_data):
    """Insere módulos fixos e adicionais para um ativo. Retorna contagem de módulos inseridos."""
    count = 0

    # 8 Módulos fixos
    for i, nome_mod in enumerate(NOMES_MODULOS_FIXOS):
        slug = _MODULE_SLUGS[i]
        desc = row_data.get(f'mod_{slug}_desc')
        serial = row_data.get(f'mod_{slug}_serial')

        if desc is not None:
            desc = str(desc).strip()
        if serial is not None:
            serial = str(serial).strip()

        if not desc and not serial:
            continue

        # module_name = sempre o nome limpo do tipo (ex: 'Luminária', 'Q. Elétrico')
        module_name = nome_mod
        module_description = desc or ''

        bd.execute('''
            INSERT INTO asset_module_serials (asset_id, module_name, module_description, serial_number, updated_by)
            VALUES (?, ?, ?, ?, ?)
        ''', (asset_id, module_name, module_description, serial or '', user_id))
        count += 1

    # 5 Módulos adicionais
    for i in range(1, 6):
        nome = row_data.get(f'mod_adicional_{i}_nome')
        serial = row_data.get(f'mod_adicional_{i}_serial')

        if nome is not None:
            nome = str(nome).strip()
        if serial is not None:
            serial = str(serial).strip()

        if not nome and not serial:
            continue

        module_name = f'Módulo Adicional {i}'
        module_description = nome or ''

        bd.execute('''
            INSERT INTO asset_module_serials (asset_id, module_name, module_description, serial_number, updated_by)
            VALUES (?, ?, ?, ?, ?)
        ''', (asset_id, module_name, module_description, serial or '', user_id))
        count += 1

    return count


def _import_sheet_intervencoes(bd, ws, user_id, user_cache, serial_to_id, int_id_map, stats):
    """Importa Sheet 3: Intervenções."""
    rows = _read_sheet_data(ws)
    st = stats['intervencoes']

    for row_data in rows:
        try:
            excel_row = row_data.get('_excel_row', '?')
            old_id = row_data.get('id')

            sn = row_data.get('serial_number')
            if sn is not None:
                sn = str(sn).strip()
            asset_id = serial_to_id.get(sn) if sn else None
            if not asset_id:
                stats['erros'].append(f'Intervenções linha {excel_row}: ativo "{sn}" não encontrado')
                continue

            created_by = _resolve_user_id(row_data.get('created_by_name'), user_cache, user_id)

            created_at = _parse_date_import(row_data.get('created_at'))
            completed_at = _parse_date_import(row_data.get('completed_at'))

            total_cost = row_data.get('total_cost')
            if total_cost is not None:
                try:
                    total_cost = float(total_cost)
                except (ValueError, TypeError):
                    total_cost = 0

            duration_hours = row_data.get('duration_hours')
            if duration_hours is not None:
                try:
                    duration_hours = float(duration_hours)
                except (ValueError, TypeError):
                    duration_hours = 0
            else:
                duration_hours = 0

            cursor = bd.execute('''
                INSERT INTO interventions
                    (asset_id, intervention_type, problem_description, solution_description,
                     parts_used, total_cost, duration_hours, status,
                     previous_asset_status, final_asset_status, notes,
                     created_by, created_at, completed_at, updated_by)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                asset_id,
                str(row_data.get('intervention_type') or '').strip(),
                str(row_data.get('problem_description') or '').strip() or None,
                str(row_data.get('solution_description') or '').strip() or None,
                str(row_data.get('parts_used') or '').strip() or None,
                total_cost or 0,
                duration_hours,
                str(row_data.get('status') or 'em_curso').strip(),
                str(row_data.get('previous_asset_status') or '').strip() or None,
                str(row_data.get('final_asset_status') or '').strip() or None,
                str(row_data.get('notes') or '').strip() or None,
                created_by,
                created_at,
                completed_at,
                user_id,
            ))
            new_id = cursor.lastrowid

            if old_id is not None:
                try:
                    int_id_map[int(old_id)] = new_id
                except (ValueError, TypeError):
                    pass

            st['criadas'] += 1

            # Processar técnicos (comma-separated)
            technicians_str = row_data.get('technicians')
            if technicians_str:
                technicians_str = str(technicians_str).strip()
                if technicians_str:
                    for tech_name in technicians_str.split(','):
                        tech_name = tech_name.strip()
                        if not tech_name:
                            continue
                        st['tecnicos_associados'] += _insert_technician(
                            bd, new_id, tech_name, user_cache, user_id
                        )

        except Exception as e:
            stats['erros'].append(f'Intervenções linha {row_data.get("_excel_row", "?")}: {e}')


def _insert_technician(bd, intervention_id, tech_text, user_cache, fallback_user_id):
    """Insere um técnico na intervention_technicians. Retorna 1 se inserido, 0 se não."""
    # Padrão "Nome (Empresa)" → externo
    match = re.match(r'^(.+?)\s*\((.+?)\)\s*$', tech_text)
    if match:
        name = match.group(1).strip()
        company = match.group(2).strip()
        # Lookup em external_technicians
        ext = bd.execute(
            'SELECT id FROM external_technicians WHERE LOWER(name) = LOWER(?) AND LOWER(company) = LOWER(?)',
            (name, company)
        ).fetchone()
        if ext:
            ext_id = ext['id']
        else:
            cursor = bd.execute(
                'INSERT INTO external_technicians (name, company, created_by) VALUES (?, ?, ?)',
                (name, company, fallback_user_id)
            )
            ext_id = cursor.lastrowid
        bd.execute(
            "INSERT INTO intervention_technicians (intervention_id, external_technician_id, role) VALUES (?, ?, 'participante')",
            (intervention_id, ext_id)
        )
        return 1
    else:
        # Interno → lookup no user_cache
        uid = _resolve_user_id(tech_text, user_cache, None)
        if uid:
            bd.execute(
                "INSERT INTO intervention_technicians (intervention_id, user_id, role) VALUES (?, ?, 'participante')",
                (intervention_id, uid)
            )
            return 1
    return 0


def _import_sheet_historico_estados(bd, ws, user_id, user_cache, serial_to_id, int_id_map, stats):
    """Importa Sheet 2: Histórico Estados."""
    rows = _read_sheet_data(ws)
    st = stats['historico_estados']

    for row_data in rows:
        try:
            excel_row = row_data.get('_excel_row', '?')

            sn = row_data.get('serial_number')
            if sn is not None:
                sn = str(sn).strip()
            asset_id = serial_to_id.get(sn) if sn else None
            if not asset_id:
                stats['erros'].append(f'Hist. Estados linha {excel_row}: ativo "{sn}" não encontrado')
                continue

            changed_by = _resolve_user_id(row_data.get('changed_by_name'), user_cache, user_id)
            changed_at = _parse_date_import(row_data.get('changed_at'))

            # Mapear intervention_id
            raw_int_id = row_data.get('intervention_id')
            mapped_int_id = None
            if raw_int_id is not None and str(raw_int_id).strip():
                try:
                    mapped_int_id = int_id_map.get(int(raw_int_id))
                except (ValueError, TypeError):
                    pass

            description = str(row_data.get('description') or '').strip()

            bd.execute('''
                INSERT INTO status_change_log
                    (asset_id, previous_status, new_status, description, changed_by, intervention_id, changed_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (
                asset_id,
                str(row_data.get('previous_status') or '').strip() or None,
                str(row_data.get('new_status') or '').strip(),
                description or 'Importado via Excel',
                changed_by,
                mapped_int_id,
                changed_at,
            ))
            st['criados'] += 1

        except Exception as e:
            stats['erros'].append(f'Hist. Estados linha {row_data.get("_excel_row", "?")}: {e}')


def _import_sheet_historico_actualizacoes(bd, ws, user_id, user_cache, int_id_map, stats):
    """Importa Sheet 4: Histórico Actualizações."""
    rows = _read_sheet_data(ws)
    st = stats['historico_actualizacoes']

    # Colunas derivadas a ignorar
    skip_cols = {'update_code', 'current_status', 'file_count', 'serial_number', 'intervention_type'}

    for row_data in rows:
        try:
            excel_row = row_data.get('_excel_row', '?')

            raw_int_id = row_data.get('intervention_id')
            if raw_int_id is None or not str(raw_int_id).strip():
                continue
            try:
                mapped_int_id = int_id_map.get(int(raw_int_id))
            except (ValueError, TypeError):
                mapped_int_id = None
            if not mapped_int_id:
                stats['erros'].append(f'Hist. Actualizações linha {excel_row}: intervenção "{raw_int_id}" não mapeada')
                continue

            edited_by = _resolve_user_id(row_data.get('edited_by_name'), user_cache, user_id)
            edited_at = _parse_date_import(row_data.get('edited_at'))

            field_name = str(row_data.get('field_name') or '').strip()
            new_value = row_data.get('new_value')
            if new_value is not None:
                new_value = str(new_value).strip()

            if not field_name:
                continue

            bd.execute('''
                INSERT INTO intervention_edit_log
                    (intervention_id, edited_by, edited_at, field_name, old_value, new_value)
                VALUES (?, ?, ?, ?, NULL, ?)
            ''', (
                mapped_int_id,
                edited_by,
                edited_at,
                field_name,
                new_value,
            ))
            st['criadas'] += 1

        except Exception as e:
            stats['erros'].append(f'Hist. Actualizações linha {row_data.get("_excel_row", "?")}: {e}')


# ── Helpers de formatação Excel ───────────────────────────────────────────────

def _estilos():
    """Retorna dicionário com estilos reutilizáveis."""
    borda_fina = Border(
        left=Side(style='thin'), right=Side(style='thin'),
        top=Side(style='thin'), bottom=Side(style='thin')
    )
    return {
        'fill_cabecalho': PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid"),
        'font_cabecalho': Font(bold=True, color="FFFFFF", size=11),
        'align_cabecalho': Alignment(horizontal="center", vertical="center", wrap_text=True),
        'fill_tecnico': PatternFill(start_color="E0E0E0", end_color="E0E0E0", fill_type="solid"),
        'font_tecnico': Font(size=9, italic=True, color="333333"),
        'borda': borda_fina,
    }


def _aplicar_cabecalho(ws, linha, cabecalhos, estilos):
    """Escreve uma linha de cabeçalho com estilo azul."""
    for col, texto in enumerate(cabecalhos, 1):
        c = ws.cell(row=linha, column=col, value=texto)
        c.fill = estilos['fill_cabecalho']
        c.font = estilos['font_cabecalho']
        c.alignment = estilos['align_cabecalho']
        c.border = estilos['borda']


def _aplicar_linha_tecnica(ws, linha, nomes_tecnicos, estilos):
    """Escreve a linha 2 com nomes técnicos entre parênteses."""
    for col, nome in enumerate(nomes_tecnicos, 1):
        c = ws.cell(row=linha, column=col, value=f'({nome})')
        c.fill = estilos['fill_tecnico']
        c.font = estilos['font_tecnico']
        c.border = estilos['borda']


def _aplicar_bordas(ws, linha_inicio, linha_fim, num_colunas, estilos):
    """Aplica bordas finas a um bloco de células."""
    for linha in range(linha_inicio, linha_fim + 1):
        for col in range(1, num_colunas + 1):
            ws.cell(row=linha, column=col).border = estilos['borda']


def _auto_largura(ws, max_largura=50):
    """Auto-ajusta largura das colunas."""
    for coluna in ws.columns:
        largura = 0
        for celula in coluna:
            try:
                if celula.value:
                    largura = max(largura, len(str(celula.value)))
            except Exception:
                pass
        letra = get_column_letter(coluna[0].column)
        ws.column_dimensions[letra].width = min(max(largura + 2, 8), max_largura)


def _formatar_data(valor):
    """Converte valor de data para string DD/MM/YYYY HH:MM:SS."""
    if not valor:
        return ''
    try:
        if isinstance(valor, datetime):
            return valor.strftime('%d/%m/%Y %H:%M:%S')
        s = str(valor)
        # Remover microsegundos se presentes (ex: 2026-01-29 17:19:26.076942)
        if '.' in s and len(s) > 19:
            s = s[:s.index('.')]
        for fmt_in, fmt_out in [
            ('%Y-%m-%d %H:%M:%S', '%d/%m/%Y %H:%M:%S'),
            ('%Y-%m-%dT%H:%M:%S', '%d/%m/%Y %H:%M:%S'),
            ('%Y-%m-%d', '%d/%m/%Y'),
        ]:
            try:
                return datetime.strptime(s, fmt_in).strftime(fmt_out)
            except ValueError:
                continue
        return s
    except Exception:
        return str(valor) if valor else ''


def _classificar_modulo(nome, descricao):
    """Classifica um módulo fixo num dos 9 tipos. Retorna índice 0-8 ou None.

    Índices: 0=Luminária 1, 1=Luminária 2, 2=Q. Elétrico, 3=Cofrete, 4=Telemetria,
             5=Carregador EV, 6=MUPI, 7=Lateral, 8=Antena
    """
    texto = f"{nome or ''} {descricao or ''}".lower()
    # Ordem: mais específicos primeiro para evitar falsos positivos
    if any(kw in texto for kw in ['cofrete', 'fusív', 'fusiv', 'fuse']):
        return 3
    if 'telemetria' in texto:
        return 4
    if any(kw in texto for kw in ['carregador', 'wallbox']):
        return 5
    if 'mupi' in texto:
        return 6
    if 'lateral' in texto:
        return 7
    if any(kw in texto for kw in ['antena', 'antenna']):
        return 8
    if any(kw in texto for kw in ['eléctrico', 'elétrico', 'eletrico', 'electrico', 'quadro el']):
        return 2
    # Luminárias: distinguir entre Luminária 1 e 2
    if any(kw in texto for kw in ['luminária', 'luminaria', 'led']):
        # Verificar se é explicitamente "2" ou "braço 2"
        if any(kw in texto for kw in ['luminária 2', 'luminaria 2', 'braço 2', 'braco 2', '_2']):
            return 1  # Luminária 2
        return 0  # Luminária 1 (default)
    return None


def _encontrar_serial_modulo(module_serials, tipo_modulo):
    """Encontra o serial de um módulo pelo tipo usando padrões flexíveis.

    As keys em module_serials vêm do frontend (JS) onde caracteres não-ASCII
    são substituídos por '_'.  Ex: 'Luminária' → 'Lumin_ria',
    'Q. Elétrico' → 'Q__El_trico'.  Colapsamos underscores múltiplos antes
    de fazer a correspondência por substring.
    """
    if not module_serials:
        return None

    padroes = {
        # Luminária 1: matches "Luminária", "Luminária Braço 1" (NOT "Braço 2")
        "Luminária 1": ["lumin_ria_bra_o_1", "luminaria_braco_1", "lumin_ria:"],
        # Luminária 2: matches "Luminária Braço 2"
        "Luminária 2": ["lumin_ria_bra_o_2", "luminaria_braco_2"],
        "Q. Elétrico": ["q_el", "eletrico", "electrico"],
        "Cofrete": ["cofrete"],
        "Telemetria": ["telemetria"],
        "Carregador EV": ["carregador", "charger", "_ev_"],
        "MUPI": ["mupi"],
        "Lateral": ["lateral"],
        "Antena": ["antena", "capsula"],
    }

    # Caso especial: "Luminária 1" deve capturar vários formatos
    if tipo_modulo == "Luminária 1":
        # Prioridade 1: "Luminária 1:" explícito (novo formato)
        for key, serial in module_serials.items():
            key_norm = re.sub(r'_+', '_', key.lower())
            if 'lumin_ria_1' in key_norm or 'luminaria_1' in key_norm:
                return serial
        # Prioridade 2: "Luminária Braço 1" (formato intermediário)
        for key, serial in module_serials.items():
            key_norm = re.sub(r'_+', '_', key.lower())
            if ('bra_o_1' in key_norm or 'braco_1' in key_norm) and 'lumin' in key_norm:
                return serial
        # Prioridade 3: "Luminária:" genérica (formato antigo, sem "2" no nome)
        for key, serial in module_serials.items():
            key_norm = re.sub(r'_+', '_', key.lower())
            if 'lumin' in key_norm and '_2' not in key_norm and 'bra_o_2' not in key_norm:
                return serial
        return None

    # Caso especial: "Luminária 2" deve capturar formatos de segunda luminária
    if tipo_modulo == "Luminária 2":
        for key, serial in module_serials.items():
            key_norm = re.sub(r'_+', '_', key.lower())
            if ('lumin_ria_2' in key_norm or 'luminaria_2' in key_norm or
                'bra_o_2' in key_norm or 'braco_2' in key_norm):
                return serial
        return None

    padroes_busca = padroes.get(tipo_modulo, [tipo_modulo.lower()])

    for key, serial in module_serials.items():
        # Normalizar: lowercase + colapsar underscores consecutivos
        key_norm = re.sub(r'_+', '_', key.lower())
        for padrao in padroes_busca:
            if padrao in key_norm:
                return serial
    return None


# ── Helpers de importação Excel ───────────────────────────────────────────────

def _parse_date_import(value):
    """Converte DD/MM/YYYY HH:MM:SS (formato do export) e datetime do openpyxl → YYYY-MM-DD HH:MM:SS."""
    if not value:
        return None
    if isinstance(value, datetime):
        return value.strftime('%Y-%m-%d %H:%M:%S')
    s = str(value).strip()
    if not s:
        return None
    for fmt_in, fmt_out in [
        ('%d/%m/%Y %H:%M:%S', '%Y-%m-%d %H:%M:%S'),
        ('%d/%m/%Y', '%Y-%m-%d %H:%M:%S'),
        ('%Y-%m-%d %H:%M:%S', '%Y-%m-%d %H:%M:%S'),
        ('%Y-%m-%dT%H:%M:%S', '%Y-%m-%d %H:%M:%S'),
        ('%Y-%m-%d', '%Y-%m-%d %H:%M:%S'),
    ]:
        try:
            return datetime.strptime(s, fmt_in).strftime(fmt_out)
        except ValueError:
            continue
    return s


def _build_user_lookup(bd):
    """Constrói cache {lowercase_name → user_id} com keys para username e 'first_name last_name'."""
    cache = {}
    users = bd.execute('SELECT id, username, first_name, last_name FROM users').fetchall()
    for u in users:
        cache[u['username'].lower()] = u['id']
        if u['first_name'] and u['last_name']:
            full = f"{u['first_name']} {u['last_name']}".lower()
            cache[full] = u['id']
    return cache


def _resolve_user_id(name, cache, fallback):
    """Resolve nome de utilizador para user_id. Retorna fallback se não encontrado."""
    if not name:
        return fallback
    key = str(name).strip().lower()
    return cache.get(key, fallback)


def _read_sheet_data(ws):
    """Lê uma folha: Row 2 = nomes técnicos (field_name), Row 3+ = dados.

    Retorna list[dict] onde cada dict inclui '_excel_row' para referência de erros.
    """
    if ws is None:
        return []

    max_col = ws.max_column or 0
    max_row = ws.max_row or 0
    if max_col == 0 or max_row < 3:
        return []

    # Row 2: nomes técnicos entre parênteses
    nomes_tecnicos = []
    for col in range(1, max_col + 1):
        valor = ws.cell(row=2, column=col).value
        if valor and str(valor).startswith('(') and str(valor).endswith(')'):
            nomes_tecnicos.append(str(valor)[1:-1])
        else:
            nomes_tecnicos.append(None)

    # Se não há nomes técnicos, usar Row 1 como fallback
    if not any(nomes_tecnicos):
        for col in range(1, max_col + 1):
            valor = ws.cell(row=1, column=col).value
            nomes_tecnicos[col - 1] = str(valor).strip() if valor else f'col_{col}'

    rows = []
    for linha in range(3, max_row + 1):
        dados = {'_excel_row': linha}
        tem_dados = False
        for col in range(1, max_col + 1):
            nome = nomes_tecnicos[col - 1]
            if not nome:
                continue
            valor = ws.cell(row=linha, column=col).value
            if valor is not None:
                dados[nome] = valor
                tem_dados = True
            else:
                dados[nome] = None
        if tem_dados:
            rows.append(dados)
    return rows


# ── Criação do ficheiro Excel (4 abas) ───────────────────────────────────────

def criar_ficheiro_excel(campos_selecionados=None):
    """Cria ficheiro Excel completo com 4 abas."""
    if not EXCEL_DISPONIVEL:
        raise Exception("Biblioteca openpyxl não disponível")

    bd = obter_bd()
    est = _estilos()
    wb = Workbook()

    _criar_aba_ativos(wb, bd, est)
    _criar_aba_historico_estados(wb, bd, est)
    _criar_aba_intervencoes(wb, bd, est)
    _criar_aba_historico_actualizacoes(wb, bd, est)

    output = BytesIO()
    wb.save(output)
    output.seek(0)
    return output


# ── Aba 1: Ativos (57 colunas) ───────────────────────────────────────────────

def _criar_aba_ativos(wb, bd, est):
    """Cria a aba 'Ativos' com 57 colunas."""
    ws = wb.active
    ws.title = "Ativos"

    # ── Construir listas de cabeçalhos e nomes técnicos ──
    cabecalhos = []
    nomes_bd = []

    # Dados base (20)
    for label, field in COLUNAS_BASE:
        cabecalhos.append(label)
        nomes_bd.append(field)

    # Especificações técnicas (7)
    for label, field in COLUNAS_SPECS:
        cabecalhos.append(label)
        nomes_bd.append(field)

    # 9 Módulos fixos (18 = 9 x 2)
    for nome_mod in NOMES_MODULOS_FIXOS:
        cabecalhos.append(f'{nome_mod} - Descrição')
        nomes_bd.append(f'mod_{nome_mod.lower().replace(" ", "_").replace(".", "")}_desc')
        cabecalhos.append(f'{nome_mod} - Nº Série')
        nomes_bd.append(f'mod_{nome_mod.lower().replace(" ", "_").replace(".", "")}_serial')

    # 5 Módulos adicionais (10 = 5 x 2)
    for i in range(1, 6):
        cabecalhos.append(f'Módulo Adicional {i} - Nome')
        nomes_bd.append(f'mod_adicional_{i}_nome')
        cabecalhos.append(f'Módulo Adicional {i} - Nº Série')
        nomes_bd.append(f'mod_adicional_{i}_serial')

    # Última manutenção (4)
    cabecalhos.extend(['Data Manutenção', 'Tipo Manutenção', 'Descrição Manutenção', 'Executado Por'])
    nomes_bd.extend(['last_maint_date', 'last_maint_type', 'last_maint_desc', 'last_maint_by'])

    num_colunas = len(cabecalhos)  # 57

    # ── Linha 1: cabeçalhos legíveis ──
    _aplicar_cabecalho(ws, 1, cabecalhos, est)

    # ── Linha 2: nomes técnicos ──
    _aplicar_linha_tecnica(ws, 2, nomes_bd, est)

    # ── Pré-carregar dados ──
    ativos = bd.execute('SELECT * FROM assets ORDER BY serial_number').fetchall()

    # asset_data por ativo
    todos_dados = {}
    for row in bd.execute('SELECT asset_id, field_name, field_value FROM asset_data').fetchall():
        aid = row['asset_id']
        if aid not in todos_dados:
            todos_dados[aid] = {}
        todos_dados[aid][row['field_name']] = row['field_value']

    # module_serials por ativo (converter para dict para suportar .get())
    todos_modulos = {}
    for row in bd.execute('SELECT * FROM asset_module_serials ORDER BY asset_id, module_name').fetchall():
        aid = row['asset_id']
        if aid not in todos_modulos:
            todos_modulos[aid] = []
        todos_modulos[aid].append(dict(row))

    # Última intervenção concluída por ativo
    ultima_manut = {}
    rows_manut = bd.execute('''
        SELECT i.asset_id, i.completed_at, i.intervention_type, i.problem_description,
               (SELECT GROUP_CONCAT(
                    COALESCE(u2.first_name || ' ' || u2.last_name, u2.username, et.name), ', ')
                FROM intervention_technicians it
                LEFT JOIN users u2 ON it.user_id = u2.id
                LEFT JOIN external_technicians et ON it.external_technician_id = et.id
                WHERE it.intervention_id = i.id) as tecnicos
        FROM interventions i
        WHERE i.status = 'concluida' AND i.completed_at IS NOT NULL
        ORDER BY i.completed_at DESC
    ''').fetchall()
    for row in rows_manut:
        aid = row['asset_id']
        if aid not in ultima_manut:
            ultima_manut[aid] = row

    # Set de nomes de tipo para detecção de descrições vazias/genéricas
    nomes_tipo_set = set(NOMES_MODULOS_FIXOS)

    # ── Linha 3+: dados ──
    for linha_num, ativo in enumerate(ativos, 3):
        aid = ativo['id']
        dados = todos_dados.get(aid, {})
        modulos = todos_modulos.get(aid, [])
        manut = ultima_manut.get(aid)

        col = 1

        # -- Dados base (20) --
        for _, field in COLUNAS_BASE:
            if field == 'serial_number':
                valor = ativo['serial_number']
            elif field == 'created_at':
                valor = _formatar_data(ativo['created_at'])
            elif field == 'updated_at':
                valor = _formatar_data(ativo['updated_at'])
            else:
                valor = dados.get(field, '')
            ws.cell(row=linha_num, column=col, value=valor or '')
            col += 1

        # -- Especificações (7) --
        for _, field in COLUNAS_SPECS:
            ws.cell(row=linha_num, column=col, value=dados.get(field, '') or '')
            col += 1

        # -- 9 Módulos fixos (18 colunas = 9 x 2) --
        # Classificar módulos do ativo nos 9 tipos
        modulos_fixos = [None] * 9  # (descricao, serial) para cada tipo
        modulos_nao_classificados = []

        for m in modulos:
            mn = m['module_name'] or ''
            # Ignorar módulos adicionais
            if mn.startswith('Módulo Adicional') or mn.startswith('Modulo Adicional'):
                continue
            idx = _classificar_modulo(mn, m.get('module_description'))
            if idx is not None and modulos_fixos[idx] is None:
                modulos_fixos[idx] = (m.get('module_description') or mn, m.get('serial_number') or '')
            else:
                modulos_nao_classificados.append(m)

        # Tentar classificar não-classificados pelo texto do attached_equipment
        equip_text = dados.get('attached_equipment', '') or ''
        equip_lines = [l.strip() for l in equip_text.split('\n') if l.strip()]
        for line in equip_lines:
            idx = _classificar_modulo(line, '')
            if idx is not None and modulos_fixos[idx] is None:
                # Procurar serial correspondente nos não-classificados
                line_key = line.replace(' ', '_')[:50]
                line_key_sanitized = ''.join(c if c.isalnum() or c == '_' else '_' for c in line_key)
                serial = ''
                for m in modulos_nao_classificados:
                    mn = m['module_name'] or ''
                    if mn == line_key_sanitized or (m.get('module_description') and line in (m.get('module_description') or '')):
                        serial = m.get('serial_number') or ''
                        modulos_nao_classificados.remove(m)
                        break
                modulos_fixos[idx] = (line, serial)

        # Preencher seriais em falta via correspondência flexível por padrão
        module_serials_dict = {
            m['module_name']: m.get('serial_number') or ''
            for m in modulos
            if (m['module_name'] or '') and
               not (m['module_name'] or '').startswith('Módulo Adicional') and
               not (m['module_name'] or '').startswith('Modulo Adicional') and
               m.get('serial_number')
        }
        for i, nome_mod in enumerate(NOMES_MODULOS_FIXOS):
            if modulos_fixos[i] is None:
                # Slot vazio: tentar encontrar descrição e serial
                serial = _encontrar_serial_modulo(module_serials_dict, nome_mod)
                if serial:
                    desc = ''
                    for m in modulos:
                        mn = m['module_name'] or ''
                        if m.get('serial_number') == serial:
                            desc = m.get('module_description') or mn
                            break
                    modulos_fixos[i] = (desc, serial)
            elif modulos_fixos[i][1] == '':
                # Tem descrição mas falta serial
                serial = _encontrar_serial_modulo(module_serials_dict, nome_mod)
                if serial:
                    modulos_fixos[i] = (modulos_fixos[i][0], serial)

        # Melhorar descrições que são apenas o nome do tipo com texto do attached_equipment
        for i, nome_mod in enumerate(NOMES_MODULOS_FIXOS):
            if modulos_fixos[i] is not None:
                desc_val, ser_val = modulos_fixos[i]
                if not desc_val or desc_val.strip() in nomes_tipo_set:
                    for line in equip_lines:
                        if line.lower().startswith(nome_mod.lower() + ':'):
                            modulos_fixos[i] = (line.strip(), ser_val)
                            break

        for i in range(9):
            desc, serial = modulos_fixos[i] if modulos_fixos[i] else ('', '')
            ws.cell(row=linha_num, column=col, value=desc)
            col += 1
            ws.cell(row=linha_num, column=col, value=serial)
            col += 1

        # -- 5 Módulos adicionais (10) --
        modulos_adicionais = sorted(
            [m for m in modulos
             if (m['module_name'] or '').startswith('Módulo Adicional')
             or (m['module_name'] or '').startswith('Modulo Adicional')],
            key=lambda m: int(''.join(filter(str.isdigit, m['module_name'] or '0')) or '0')
        )
        for i in range(5):
            if i < len(modulos_adicionais):
                ma = modulos_adicionais[i]
                ws.cell(row=linha_num, column=col, value=ma.get('module_description') or ma.get('module_name') or '')
                col += 1
                ws.cell(row=linha_num, column=col, value=ma.get('serial_number') or '')
                col += 1
            else:
                ws.cell(row=linha_num, column=col, value='')
                col += 1
                ws.cell(row=linha_num, column=col, value='')
                col += 1

        # -- Última manutenção (4) --
        if manut:
            ws.cell(row=linha_num, column=col, value=_formatar_data(manut['completed_at']))
            col += 1
            ws.cell(row=linha_num, column=col, value=manut['intervention_type'] or '')
            col += 1
            ws.cell(row=linha_num, column=col, value=manut['problem_description'] or '')
            col += 1
            ws.cell(row=linha_num, column=col, value=manut['tecnicos'] or '')
            col += 1
        else:
            for _ in range(4):
                ws.cell(row=linha_num, column=col, value='')
                col += 1

    # ── Formatação final ──
    ultima_linha = max(2, 2 + len(ativos))
    _aplicar_bordas(ws, 3, ultima_linha, num_colunas, est)
    _auto_largura(ws)
    ws.freeze_panes = 'A3'


# ── Aba 2: Histórico Estados ─────────────────────────────────────────────────

def _criar_aba_historico_estados(wb, bd, est):
    """Cria a aba 'Histórico Estados'."""
    ws = wb.create_sheet("Histórico Estados")

    cabecalhos = [
        'Nº Série', 'Estado Anterior', 'Novo Estado', 'Descrição',
        'Data/Hora', 'Alterado Por', 'ID Intervenção'
    ]
    nomes_bd = [
        'serial_number', 'previous_status', 'new_status', 'description',
        'changed_at', 'changed_by_name', 'intervention_id'
    ]
    num_colunas = len(cabecalhos)

    _aplicar_cabecalho(ws, 1, cabecalhos, est)
    _aplicar_linha_tecnica(ws, 2, nomes_bd, est)

    rows = bd.execute('''
        SELECT scl.*, a.serial_number,
               COALESCE(u.first_name || ' ' || u.last_name, u.username) as changed_by_name
        FROM status_change_log scl
        JOIN assets a ON scl.asset_id = a.id
        LEFT JOIN users u ON scl.changed_by = u.id
        ORDER BY scl.changed_at DESC
    ''').fetchall()

    for i, row in enumerate(rows, 3):
        ws.cell(row=i, column=1, value=row['serial_number'] or '')
        ws.cell(row=i, column=2, value=row['previous_status'] or '')
        ws.cell(row=i, column=3, value=row['new_status'] or '')
        ws.cell(row=i, column=4, value=row['description'] or '')
        ws.cell(row=i, column=5, value=_formatar_data(row['changed_at']))
        ws.cell(row=i, column=6, value=row['changed_by_name'] or '')
        ws.cell(row=i, column=7, value=row['intervention_id'] if row['intervention_id'] else '')

    ultima_linha = max(2, 2 + len(rows))
    _aplicar_bordas(ws, 3, ultima_linha, num_colunas, est)
    _auto_largura(ws)
    ws.freeze_panes = 'A3'


# ── Aba 3: Intervenções ──────────────────────────────────────────────────────

def _criar_aba_intervencoes(wb, bd, est):
    """Cria a aba 'Intervenções'."""
    ws = wb.create_sheet("Intervenções")

    cabecalhos = [
        'ID', 'Nº Série', 'Tipo', 'Descrição Problema', 'Descrição Solução',
        'Peças/Materiais', 'Custo Total (€)', 'Duração (h)',
        'Estado Intervenção', 'Estado Ativo Antes', 'Estado Ativo Depois',
        'Data Criação', 'Data Conclusão', 'Criado Por', 'Técnicos', 'Notas'
    ]
    nomes_bd = [
        'id', 'serial_number', 'intervention_type', 'problem_description',
        'solution_description', 'parts_used', 'total_cost', 'duration_hours',
        'status', 'previous_asset_status', 'final_asset_status',
        'created_at', 'completed_at', 'created_by_name', 'technicians', 'notes'
    ]
    num_colunas = len(cabecalhos)

    _aplicar_cabecalho(ws, 1, cabecalhos, est)
    _aplicar_linha_tecnica(ws, 2, nomes_bd, est)

    rows = bd.execute('''
        SELECT i.*, a.serial_number,
               COALESCE(u.first_name || ' ' || u.last_name, u.username) as created_by_name,
               (SELECT GROUP_CONCAT(
                    COALESCE(u2.first_name || ' ' || u2.last_name, u2.username,
                             et.name || ' (' || et.company || ')'), ', ')
                FROM intervention_technicians it
                LEFT JOIN users u2 ON it.user_id = u2.id
                LEFT JOIN external_technicians et ON it.external_technician_id = et.id
                WHERE it.intervention_id = i.id) as technicians
        FROM interventions i
        JOIN assets a ON i.asset_id = a.id
        LEFT JOIN users u ON i.created_by = u.id
        ORDER BY i.created_at DESC
    ''').fetchall()

    for i, row in enumerate(rows, 3):
        ws.cell(row=i, column=1, value=row['id'])
        ws.cell(row=i, column=2, value=row['serial_number'] or '')
        ws.cell(row=i, column=3, value=row['intervention_type'] or '')
        ws.cell(row=i, column=4, value=row['problem_description'] or '')
        ws.cell(row=i, column=5, value=row['solution_description'] or '')
        ws.cell(row=i, column=6, value=row['parts_used'] or '')

        # Custo com formato monetário
        custo = row['total_cost']
        c = ws.cell(row=i, column=7, value=custo if custo else 0)
        c.number_format = '#,##0.00'

        # Duração com formato decimal
        duracao = row['duration_hours']
        c = ws.cell(row=i, column=8, value=duracao if duracao else 0)
        c.number_format = '#,##0.00'

        ws.cell(row=i, column=9, value=row['status'] or '')
        ws.cell(row=i, column=10, value=row['previous_asset_status'] or '')
        ws.cell(row=i, column=11, value=row['final_asset_status'] or '')
        ws.cell(row=i, column=12, value=_formatar_data(row['created_at']))
        ws.cell(row=i, column=13, value=_formatar_data(row['completed_at']))
        ws.cell(row=i, column=14, value=row['created_by_name'] or '')
        ws.cell(row=i, column=15, value=row['technicians'] or '')
        ws.cell(row=i, column=16, value=row['notes'] or '')

    ultima_linha = max(2, 2 + len(rows))
    _aplicar_bordas(ws, 3, ultima_linha, num_colunas, est)
    _auto_largura(ws)
    ws.freeze_panes = 'A3'


# ── Aba 4: Histórico Actualizações ───────────────────────────────────────────

def _criar_aba_historico_actualizacoes(wb, bd, est):
    """Cria a aba 'Histórico Actualizações'."""
    ws = wb.create_sheet("Histórico Actualizações")

    cabecalhos = [
        'ID Intervenção', 'Nº Série Ativo', 'Tipo Intervenção',
        'Código Actualização', 'Data/Hora', 'Utilizador',
        'Campo', 'Valor', 'Estado Actual', 'Ficheiros Anexados'
    ]
    nomes_bd = [
        'intervention_id', 'serial_number', 'intervention_type',
        'update_code', 'edited_at', 'edited_by_name',
        'field_name', 'new_value', 'current_status', 'file_count'
    ]
    num_colunas = len(cabecalhos)

    _aplicar_cabecalho(ws, 1, cabecalhos, est)
    _aplicar_linha_tecnica(ws, 2, nomes_bd, est)

    # Ficheiros por intervenção (pré-carregar contagem)
    ficheiros_por_int = {}
    for row in bd.execute('''
        SELECT intervention_id, COUNT(*) as cnt,
               GROUP_CONCAT(original_name, '; ') as nomes
        FROM intervention_files GROUP BY intervention_id
    ''').fetchall():
        ficheiros_por_int[row['intervention_id']] = {
            'count': row['cnt'], 'nomes': row['nomes']
        }

    # Dados do edit_log
    rows = bd.execute('''
        SELECT e.*, i.intervention_type, i.status as current_status, a.serial_number,
               COALESCE(u.first_name || ' ' || u.last_name, u.username) as edited_by_name
        FROM intervention_edit_log e
        JOIN interventions i ON e.intervention_id = i.id
        JOIN assets a ON i.asset_id = a.id
        LEFT JOIN users u ON e.edited_by = u.id
        ORDER BY e.edited_at DESC
    ''').fetchall()

    for i, row in enumerate(rows, 3):
        int_id = row['intervention_id']
        edit_id = row['id']

        ws.cell(row=i, column=1, value=int_id)
        ws.cell(row=i, column=2, value=row['serial_number'] or '')
        ws.cell(row=i, column=3, value=row['intervention_type'] or '')
        ws.cell(row=i, column=4, value=f'ACT-{int_id}-{edit_id}')
        ws.cell(row=i, column=5, value=_formatar_data(row['edited_at']))
        ws.cell(row=i, column=6, value=row['edited_by_name'] or '')
        ws.cell(row=i, column=7, value=row['field_name'] or '')
        ws.cell(row=i, column=8, value=row['new_value'] or '')
        ws.cell(row=i, column=9, value=row['current_status'] or '')

        fi = ficheiros_por_int.get(int_id)
        if fi:
            ws.cell(row=i, column=10, value=f"{fi['count']} ficheiro(s): {fi['nomes']}")
        else:
            ws.cell(row=i, column=10, value='')

    ultima_linha = max(2, 2 + len(rows))
    _aplicar_bordas(ws, 3, ultima_linha, num_colunas, est)
    _auto_largura(ws)
    ws.freeze_panes = 'A3'
