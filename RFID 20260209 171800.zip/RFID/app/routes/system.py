"""
SmartLamppost - Rotas de Sistema (Health, Stats, Config)
"""

import os
import re
import json
from datetime import datetime
from flask import request, jsonify, g, send_file

from app.routes import system_bp
from app.database import obter_bd, obter_config, registar_auditoria
from app.utils import requer_autenticacao, requer_admin
from app.config import get_config
from app.extensions import EXCEL_DISPONIVEL

_config = get_config()


@system_bp.route('/health', methods=['GET'])
def health_check():
    """Endpoint de health check para verificar se o servidor está a funcionar."""
    return jsonify({
        'status': 'ok',
        'timestamp': datetime.now().isoformat(),
        'version': '3.0.0',
        'excel_available': EXCEL_DISPONIVEL
    })


# =============================================================================
# ESTATÍSTICAS
# =============================================================================

@system_bp.route('/stats', methods=['GET'])
@requer_autenticacao
def obter_estatisticas():
    """Devolve estatísticas gerais do sistema."""
    bd = obter_bd()

    total_ativos = bd.execute('SELECT COUNT(*) FROM assets').fetchone()[0]

    condicoes = bd.execute('''
        SELECT field_value, COUNT(*) as count FROM asset_data
        WHERE field_name = 'condition_status' GROUP BY field_value
    ''').fetchall()

    municipios = bd.execute('''
        SELECT field_value, COUNT(*) as count FROM asset_data
        WHERE field_name = 'municipality' AND field_value IS NOT NULL
        GROUP BY field_value ORDER BY count DESC LIMIT 10
    ''').fetchall()

    manutencoes_recentes = bd.execute('''
        SELECT COUNT(*) FROM maintenance_log WHERE performed_at > datetime('now', '-30 days')
    ''').fetchone()[0]

    manutencoes_programadas = bd.execute('''
        SELECT COUNT(*) FROM asset_data
        WHERE field_name = 'next_maintenance_date'
        AND field_value IS NOT NULL
        AND field_value != ''
        AND date(field_value) BETWEEN date('now') AND date('now', '+30 days')
    ''').fetchone()[0]

    ativos_manutencao = bd.execute('''
        SELECT a.serial_number, ad.field_value as maintenance_date,
               (SELECT field_value FROM asset_data WHERE asset_id = a.id AND field_name = 'municipality') as municipality,
               (SELECT field_value FROM asset_data WHERE asset_id = a.id AND field_name = 'maintenance_notes') as notes
        FROM assets a
        JOIN asset_data ad ON a.id = ad.asset_id
        WHERE ad.field_name = 'next_maintenance_date'
        AND ad.field_value IS NOT NULL
        AND ad.field_value != ''
        AND date(ad.field_value) BETWEEN date('now') AND date('now', '+30 days')
        ORDER BY ad.field_value ASC
        LIMIT 10
    ''').fetchall()

    return jsonify({
        'total_assets': total_ativos,
        'by_condition': [dict(c) for c in condicoes],
        'by_municipality': [dict(m) for m in municipios],
        'recent_maintenance_30d': manutencoes_recentes,
        'scheduled_maintenance_30d': manutencoes_programadas,
        'upcoming_maintenance': [dict(a) for a in ativos_manutencao]
    })


@system_bp.route('/stats/summary', methods=['GET'])
@requer_autenticacao
def obter_resumo_estatisticas():
    """Devolve resumo estatístico com filtro por município."""
    bd = obter_bd()
    municipio = request.args.get('municipality', '')

    todos_municipios = bd.execute('''
        SELECT DISTINCT field_value FROM asset_data
        WHERE field_name = 'municipality' AND field_value IS NOT NULL AND field_value != ''
        ORDER BY field_value
    ''').fetchall()

    if municipio:
        ids_ativos = bd.execute('''
            SELECT DISTINCT asset_id FROM asset_data WHERE field_name = 'municipality' AND field_value = ?
        ''', (municipio,)).fetchall()
        lista_ids = [a['asset_id'] for a in ids_ativos]

        if not lista_ids:
            return jsonify({
                'municipalities': [m['field_value'] for m in todos_municipios],
                'selected_municipality': municipio,
                'total_assets': 0, 'by_condition': [], 'warranty_valid': 0,
                'warranty_expiring_30d': 0, 'warranty_expiring_assets': [], 'assets_by_condition': []
            })

        placeholders = ','.join(['?' for _ in lista_ids])
        total_ativos = len(lista_ids)

        condicoes = bd.execute(f'''
            SELECT field_value, COUNT(*) as count FROM asset_data
            WHERE field_name = 'condition_status' AND asset_id IN ({placeholders})
            GROUP BY field_value
        ''', lista_ids).fetchall()

        garantia_valida = bd.execute(f'''
            SELECT COUNT(*) FROM asset_data
            WHERE field_name = 'warranty_end_date' AND field_value >= date('now') AND asset_id IN ({placeholders})
        ''', lista_ids).fetchone()[0]

        garantia_expirar = bd.execute(f'''
            SELECT ad.asset_id, ad.field_value as warranty_end, a.serial_number
            FROM asset_data ad JOIN assets a ON ad.asset_id = a.id
            WHERE ad.field_name = 'warranty_end_date'
            AND ad.field_value >= date('now') AND ad.field_value <= date('now', '+30 days')
            AND ad.asset_id IN ({placeholders}) ORDER BY ad.field_value
        ''', lista_ids).fetchall()

        ativos_por_condicao = []
        for cond in condicoes:
            ativos_cond = bd.execute(f'''
                SELECT a.serial_number, a.id FROM assets a
                JOIN asset_data ad ON a.id = ad.asset_id
                WHERE ad.field_name = 'condition_status' AND ad.field_value = ? AND a.id IN ({placeholders})
                LIMIT 10
            ''', [cond['field_value']] + lista_ids).fetchall()
            ativos_por_condicao.append({
                'condition': cond['field_value'], 'count': cond['count'],
                'sample_assets': [{'serial_number': a['serial_number'], 'id': a['id']} for a in ativos_cond]
            })
    else:
        total_ativos = bd.execute('SELECT COUNT(*) FROM assets').fetchone()[0]

        condicoes = bd.execute('''
            SELECT field_value, COUNT(*) as count FROM asset_data
            WHERE field_name = 'condition_status' GROUP BY field_value
        ''').fetchall()

        garantia_valida = bd.execute('''
            SELECT COUNT(*) FROM asset_data WHERE field_name = 'warranty_end_date' AND field_value >= date('now')
        ''').fetchone()[0]

        garantia_expirar = bd.execute('''
            SELECT ad.asset_id, ad.field_value as warranty_end, a.serial_number
            FROM asset_data ad JOIN assets a ON ad.asset_id = a.id
            WHERE ad.field_name = 'warranty_end_date'
            AND ad.field_value >= date('now') AND ad.field_value <= date('now', '+30 days')
            ORDER BY ad.field_value LIMIT 20
        ''').fetchall()

        ativos_por_condicao = []
        for cond in condicoes:
            ativos_cond = bd.execute('''
                SELECT a.serial_number, a.id FROM assets a
                JOIN asset_data ad ON a.id = ad.asset_id
                WHERE ad.field_name = 'condition_status' AND ad.field_value = ?
                LIMIT 10
            ''', (cond['field_value'],)).fetchall()
            ativos_por_condicao.append({
                'condition': cond['field_value'], 'count': cond['count'],
                'sample_assets': [{'serial_number': a['serial_number'], 'id': a['id']} for a in ativos_cond]
            })

    return jsonify({
        'municipalities': [m['field_value'] for m in todos_municipios],
        'selected_municipality': municipio or 'Todos',
        'total_assets': total_ativos,
        'by_condition': [dict(c) for c in condicoes],
        'warranty_valid': garantia_valida,
        'warranty_expiring_30d': len(garantia_expirar),
        'warranty_expiring_assets': [{'serial_number': w['serial_number'], 'warranty_end': w['warranty_end']} for w in garantia_expirar],
        'assets_by_condition': ativos_por_condicao
    })


# =============================================================================
# CONFIGURAÇÕES DO SISTEMA
# =============================================================================

@system_bp.route('/config/prefixes', methods=['GET'])
@requer_autenticacao
def obter_prefixos():
    """Devolve todas as configurações de prefixos."""
    bd = obter_bd()

    configs = bd.execute('''
        SELECT config_key, config_value, description, updated_at
        FROM system_config
        WHERE config_key LIKE 'prefix_%'
        ORDER BY config_key
    ''').fetchall()

    prefixes = {}
    for c in configs:
        prefixes[c['config_key']] = c['config_value']

    return jsonify({'prefixes': prefixes})


@system_bp.route('/config/prefixes', methods=['PUT'])
@requer_admin
def atualizar_prefixos():
    """Atualiza configurações de prefixos."""
    dados = request.json
    bd = obter_bd()
    user_id = g.utilizador_atual['user_id']

    campos_validos = [
        'prefix_assets', 'prefix_assets_digits',
        'prefix_int_preventiva', 'prefix_int_corretiva',
        'prefix_int_substituicao', 'prefix_int_inspecao', 'prefix_int_digits'
    ]

    for campo in campos_validos:
        if campo in dados:
            bd.execute('''
                UPDATE system_config
                SET config_value = ?, updated_at = CURRENT_TIMESTAMP, updated_by = ?
                WHERE config_key = ?
            ''', (dados[campo], user_id, campo))

    bd.commit()
    return jsonify({'message': 'Prefixos atualizados com sucesso'})


@system_bp.route('/config/colors', methods=['GET'])
@requer_autenticacao
def obter_cores():
    """Devolve lista de cores configuradas."""
    resultado = obter_config('colors_list', '[]')
    try:
        cores = json.loads(resultado)
    except json.JSONDecodeError:
        cores = []
    return jsonify({'colors': cores})


@system_bp.route('/config/colors', methods=['PUT'])
@requer_admin
def atualizar_cores():
    """Atualiza lista de cores."""
    dados = request.json
    cores = dados.get('colors', [])
    bd = obter_bd()
    user_id = g.utilizador_atual['user_id']

    bd.execute('''
        UPDATE system_config
        SET config_value = ?, updated_at = CURRENT_TIMESTAMP, updated_by = ?
        WHERE config_key = 'colors_list'
    ''', (json.dumps(cores), user_id))

    bd.commit()
    return jsonify({'message': 'Cores atualizadas com sucesso'})


@system_bp.route('/config/manufacturers', methods=['GET'])
@requer_autenticacao
def obter_fabricantes():
    """Devolve lista de fabricantes configurados."""
    resultado = obter_config('manufacturers_list', '[]')
    try:
        lista = json.loads(resultado)
    except json.JSONDecodeError:
        lista = []
    return jsonify({'manufacturers': lista})


@system_bp.route('/config/manufacturers', methods=['PUT'])
@requer_admin
def atualizar_fabricantes():
    """Atualiza lista de fabricantes."""
    dados = request.json
    lista = dados.get('manufacturers', [])
    bd = obter_bd()
    user_id = g.utilizador_atual['user_id']

    bd.execute('''
        UPDATE system_config
        SET config_value = ?, updated_at = CURRENT_TIMESTAMP, updated_by = ?
        WHERE config_key = 'manufacturers_list'
    ''', (json.dumps(lista), user_id))

    bd.commit()
    return jsonify({'message': 'Fabricantes atualizados com sucesso'})


@system_bp.route('/config/models', methods=['GET'])
@requer_autenticacao
def obter_modelos():
    """Devolve lista de modelos configurados."""
    resultado = obter_config('models_list', '[]')
    try:
        lista = json.loads(resultado)
    except json.JSONDecodeError:
        lista = []
    return jsonify({'models': lista})


@system_bp.route('/config/models', methods=['PUT'])
@requer_admin
def atualizar_modelos():
    """Atualiza lista de modelos."""
    dados = request.json
    lista = dados.get('models', [])
    bd = obter_bd()
    user_id = g.utilizador_atual['user_id']

    bd.execute('''
        UPDATE system_config
        SET config_value = ?, updated_at = CURRENT_TIMESTAMP, updated_by = ?
        WHERE config_key = 'models_list'
    ''', (json.dumps(lista), user_id))

    bd.commit()
    return jsonify({'message': 'Modelos atualizados com sucesso'})


@system_bp.route('/config/locations', methods=['GET'])
@requer_autenticacao
def obter_localizacoes():
    """Devolve lista de localizações."""
    resultado = obter_config('locations_list', '[]')
    try:
        lista = json.loads(resultado)
    except json.JSONDecodeError:
        lista = []
    return jsonify({'locations': lista})


@system_bp.route('/config/locations', methods=['PUT'])
@requer_autenticacao
def atualizar_localizacoes():
    """Atualiza lista de localizações."""
    dados = request.json
    lista = dados.get('locations', [])
    bd = obter_bd()
    user_id = g.utilizador_atual['user_id']

    bd.execute('''
        UPDATE system_config
        SET config_value = ?, updated_at = CURRENT_TIMESTAMP, updated_by = ?
        WHERE config_key = 'locations_list'
    ''', (json.dumps(lista), user_id))

    bd.commit()
    return jsonify({'message': 'Localizações atualizadas com sucesso'})


@system_bp.route('/config/locations/add', methods=['POST'])
@requer_autenticacao
def adicionar_localizacao():
    """Adiciona uma nova localização à lista."""
    dados = request.json
    nova = dados.get('location', '').strip()
    if not nova:
        return jsonify({'error': 'Localização não pode ser vazia'}), 400

    resultado = obter_config('locations_list', '[]')
    try:
        lista = json.loads(resultado)
    except json.JSONDecodeError:
        lista = []

    if nova not in lista:
        lista.append(nova)
        lista.sort()

        bd = obter_bd()
        user_id = g.utilizador_atual['user_id']
        bd.execute('''
            UPDATE system_config
            SET config_value = ?, updated_at = CURRENT_TIMESTAMP, updated_by = ?
            WHERE config_key = 'locations_list'
        ''', (json.dumps(lista), user_id))
        bd.commit()

    return jsonify({'message': 'Localização adicionada', 'locations': lista})


@system_bp.route('/config/municipalities', methods=['GET'])
@requer_autenticacao
def obter_municipios():
    """Devolve lista de municípios."""
    resultado = obter_config('municipalities_list', '[]')
    try:
        lista = json.loads(resultado)
    except json.JSONDecodeError:
        lista = []
    return jsonify({'municipalities': lista})


@system_bp.route('/config/municipalities', methods=['PUT'])
@requer_autenticacao
def atualizar_municipios():
    """Atualiza lista de municípios."""
    dados = request.json
    lista = dados.get('municipalities', [])
    bd = obter_bd()
    user_id = g.utilizador_atual['user_id']

    bd.execute('''
        UPDATE system_config
        SET config_value = ?, updated_at = CURRENT_TIMESTAMP, updated_by = ?
        WHERE config_key = 'municipalities_list'
    ''', (json.dumps(lista), user_id))

    bd.commit()
    return jsonify({'message': 'Municípios atualizados com sucesso'})


@system_bp.route('/config/municipalities/add', methods=['POST'])
@requer_autenticacao
def adicionar_municipio():
    """Adiciona um novo município à lista."""
    dados = request.json
    novo = dados.get('municipality', '').strip()
    if not novo:
        return jsonify({'error': 'Município não pode ser vazio'}), 400

    resultado = obter_config('municipalities_list', '[]')
    try:
        lista = json.loads(resultado)
    except json.JSONDecodeError:
        lista = []

    if novo not in lista:
        lista.append(novo)
        lista.sort()

        bd = obter_bd()
        user_id = g.utilizador_atual['user_id']
        bd.execute('''
            UPDATE system_config
            SET config_value = ?, updated_at = CURRENT_TIMESTAMP, updated_by = ?
            WHERE config_key = 'municipalities_list'
        ''', (json.dumps(lista), user_id))
        bd.commit()

    return jsonify({'message': 'Município adicionado', 'municipalities': lista})


@system_bp.route('/config/addresses', methods=['GET'])
@requer_autenticacao
def obter_moradas():
    """Devolve lista de moradas."""
    resultado = obter_config('addresses_list', '[]')
    try:
        lista = json.loads(resultado)
    except json.JSONDecodeError:
        lista = []
    return jsonify({'addresses': lista})


@system_bp.route('/config/addresses/add', methods=['POST'])
@requer_autenticacao
def adicionar_morada():
    """Adiciona uma nova morada à lista."""
    dados = request.json
    nova = dados.get('address', '').strip()
    if not nova:
        return jsonify({'error': 'Morada não pode ser vazia'}), 400

    resultado = obter_config('addresses_list', '[]')
    try:
        lista = json.loads(resultado)
    except json.JSONDecodeError:
        lista = []

    if nova not in lista:
        lista.append(nova)
        lista.sort()

        bd = obter_bd()
        user_id = g.utilizador_atual['user_id']
        bd.execute('''
            UPDATE system_config
            SET config_value = ?, updated_at = CURRENT_TIMESTAMP, updated_by = ?
            WHERE config_key = 'addresses_list'
        ''', (json.dumps(lista), user_id))
        bd.commit()

    return jsonify({'message': 'Morada adicionada', 'addresses': lista})


# =============================================================================
# MATERIAIS
# =============================================================================

@system_bp.route('/config/materials', methods=['GET'])
@requer_autenticacao
def obter_materiais():
    """Devolve lista de materiais configurados."""
    resultado = obter_config('materials_list', '[]')
    try:
        lista = json.loads(resultado)
    except json.JSONDecodeError:
        lista = []
    return jsonify({'materials': lista})


@system_bp.route('/config/materials', methods=['PUT'])
@requer_admin
def atualizar_materiais():
    """Atualiza lista de materiais."""
    dados = request.json
    lista = dados.get('materials', [])
    bd = obter_bd()
    user_id = g.utilizador_atual['user_id']

    # Verificar se config existe, senao criar
    existe = bd.execute(
        "SELECT 1 FROM system_config WHERE config_key = 'materials_list'"
    ).fetchone()

    if existe:
        bd.execute('''
            UPDATE system_config
            SET config_value = ?, updated_at = CURRENT_TIMESTAMP, updated_by = ?
            WHERE config_key = 'materials_list'
        ''', (json.dumps(lista), user_id))
    else:
        bd.execute('''
            INSERT INTO system_config (config_key, config_value, description, updated_by)
            VALUES ('materials_list', ?, 'Lista de materiais disponiveis', ?)
        ''', (json.dumps(lista), user_id))

    bd.commit()
    return jsonify({'message': 'Materiais atualizados com sucesso'})


# =============================================================================
# FAVORITOS (Global - para defaults no form de criacao)
# =============================================================================

@system_bp.route('/config/favorites', methods=['GET'])
@requer_autenticacao
def obter_favoritos():
    """Devolve os valores favoritos para defaults."""
    return jsonify({
        'manufacturer': obter_config('favorite_manufacturer', ''),
        'model': obter_config('favorite_model', ''),
        'material': obter_config('favorite_material', ''),
        'column_color': obter_config('favorite_column_color', '')
    })


@system_bp.route('/config/favorites', methods=['POST'])
@requer_admin
def definir_favoritos():
    """Define um ou mais valores favoritos."""
    dados = request.json
    bd = obter_bd()
    user_id = g.utilizador_atual['user_id']

    campos_validos = {
        'manufacturer': 'favorite_manufacturer',
        'model': 'favorite_model',
        'material': 'favorite_material',
        'column_color': 'favorite_column_color'
    }

    alterados = []
    for campo, config_key in campos_validos.items():
        if campo in dados:
            valor = dados[campo] or ''
            # Verificar se config existe
            existe = bd.execute(
                'SELECT 1 FROM system_config WHERE config_key = ?',
                (config_key,)
            ).fetchone()

            if existe:
                bd.execute('''
                    UPDATE system_config
                    SET config_value = ?, updated_at = CURRENT_TIMESTAMP, updated_by = ?
                    WHERE config_key = ?
                ''', (valor, user_id, config_key))
            else:
                bd.execute('''
                    INSERT INTO system_config (config_key, config_value, description, updated_by)
                    VALUES (?, ?, ?, ?)
                ''', (config_key, valor, f'Valor favorito para {campo}', user_id))
            alterados.append(campo)

    bd.commit()

    return jsonify({
        'message': f'Favoritos atualizados: {", ".join(alterados)}' if alterados else 'Nenhuma alteracao',
        'updated': alterados
    })


@system_bp.route('/config/counters', methods=['GET'])
@requer_autenticacao
def obter_contadores():
    """Devolve os valores actuais dos contadores."""
    bd = obter_bd()

    contadores = bd.execute('''
        SELECT counter_type, current_value, updated_at
        FROM sequence_counters
        ORDER BY counter_type
    ''').fetchall()

    # Obter prefixos para mostrar preview
    prefixos = {}
    configs = bd.execute('''
        SELECT config_key, config_value FROM system_config WHERE config_key LIKE 'prefix_%'
    ''').fetchall()
    for c in configs:
        prefixos[c['config_key']] = c['config_value']

    resultado = []
    for c in contadores:
        item = dict(c)
        # Calcular preview do próximo número
        tipo = c['counter_type']
        if tipo == 'assets':
            prefixo = prefixos.get('prefix_assets', 'SLP')
            digitos = int(prefixos.get('prefix_assets_digits', '9'))
        else:
            tipo_prefixo = f'prefix_{tipo}'
            prefixo = prefixos.get(tipo_prefixo, 'INT')
            digitos = int(prefixos.get('prefix_int_digits', '9'))

        proximo = c['current_value'] + 1
        item['next_preview'] = f"{prefixo}{str(proximo).zfill(digitos)}"
        resultado.append(item)

    return jsonify({'counters': resultado})


@system_bp.route('/config/counters/<string:counter_type>', methods=['PUT'])
@requer_admin
def atualizar_contador(counter_type):
    """Atualiza o valor de um contador (apenas admin)."""
    dados = request.json
    novo_valor = dados.get('value')

    if novo_valor is None or not isinstance(novo_valor, int) or novo_valor < 0:
        return jsonify({'error': 'Valor inválido. Deve ser um número inteiro >= 0'}), 400

    bd = obter_bd()

    # Verificar se contador existe
    contador = bd.execute(
        'SELECT * FROM sequence_counters WHERE counter_type = ?',
        (counter_type,)
    ).fetchone()

    if not contador:
        return jsonify({'error': 'Contador não encontrado'}), 404

    bd.execute('''
        UPDATE sequence_counters
        SET current_value = ?, updated_at = CURRENT_TIMESTAMP
        WHERE counter_type = ?
    ''', (novo_valor, counter_type))

    bd.commit()

    return jsonify({'message': f'Contador {counter_type} atualizado para {novo_valor}'})


@system_bp.route('/next-serial', methods=['GET'])
@requer_autenticacao
def obter_proximo_serial_preview():
    """Devolve preview do próximo número de série (sem incrementar)."""
    bd = obter_bd()

    prefixo = obter_config('prefix_assets', 'SLP')
    digitos = int(obter_config('prefix_assets_digits', '9'))

    resultado = bd.execute(
        'SELECT current_value FROM sequence_counters WHERE counter_type = ?',
        ('assets',)
    ).fetchone()

    proximo = (resultado['current_value'] if resultado else 0) + 1
    serial = f"{prefixo}{str(proximo).zfill(digitos)}"

    return jsonify({'next_serial': serial})


@system_bp.route('/config/next-number/<string:tipo>', methods=['GET'])
@requer_autenticacao
def preview_proximo_numero(tipo):
    """Preview do proximo numero SEM incrementar o contador."""
    tipos_validos = ['assets', 'int_preventiva', 'int_corretiva', 'int_substituicao', 'int_inspecao']

    if tipo not in tipos_validos:
        return jsonify({'error': 'Tipo invalido'}), 400

    bd = obter_bd()

    if tipo == 'assets':
        prefixo = obter_config('prefix_assets', 'SLP')
        digitos = int(obter_config('prefix_assets_digits', '9'))
    else:
        tipo_prefixo = f'prefix_{tipo}'
        prefixo = obter_config(tipo_prefixo, 'INT')
        digitos = int(obter_config('prefix_int_digits', '9'))

    resultado = bd.execute(
        'SELECT current_value FROM sequence_counters WHERE counter_type = ?',
        (tipo,)
    ).fetchone()

    proximo = (resultado['current_value'] if resultado else 0) + 1
    numero = f"{prefixo}{str(proximo).zfill(digitos)}"

    return jsonify({'number': numero, 'type': tipo})


@system_bp.route('/config/test-counter/<string:counter_type>', methods=['POST'])
@requer_admin
def testar_contador(counter_type):
    """Simula o proximo numero de um contador (preview sem incrementar).

    Se o body JSON incluir {"confirm": true}, incrementa efectivamente o contador.
    """
    tipos_validos = ['assets', 'int_preventiva', 'int_corretiva', 'int_substituicao', 'int_inspecao']
    if counter_type not in tipos_validos:
        return jsonify({'error': 'Tipo de contador invalido'}), 400

    bd = obter_bd()

    contador = bd.execute(
        'SELECT current_value FROM sequence_counters WHERE counter_type = ?',
        (counter_type,)
    ).fetchone()
    if not contador:
        return jsonify({'error': 'Contador nao encontrado'}), 404

    valor_atual = contador['current_value']
    proximo = valor_atual + 1

    if counter_type == 'assets':
        prefixo = obter_config('prefix_assets', 'SLP')
        digitos = int(obter_config('prefix_assets_digits', '9'))
    else:
        prefixo = obter_config(f'prefix_{counter_type}', 'INT')
        digitos = int(obter_config('prefix_int_digits', '9'))

    numero_formatado = f"{prefixo}{str(proximo).zfill(digitos)}"

    dados = request.get_json(silent=True) or {}
    confirmado = dados.get('confirm', False)

    if confirmado:
        bd.execute(
            'UPDATE sequence_counters SET current_value = ?, updated_at = CURRENT_TIMESTAMP WHERE counter_type = ?',
            (proximo, counter_type)
        )
        bd.commit()
        registar_auditoria(bd, g.utilizador_atual['user_id'], 'TEST_COUNTER', 'sequence_counters', None, None,
                           {'counter_type': counter_type, 'old_value': valor_atual, 'new_value': proximo})

    return jsonify({
        'counter_type': counter_type,
        'current_value': valor_atual,
        'next_value': proximo,
        'formatted': numero_formatado,
        'incremented': confirmado,
    })


@system_bp.route('/config/sequence/sync/<string:counter_type>', methods=['POST'])
@requer_admin
def sincronizar_contador(counter_type):
    """Sincroniza o contador com o máximo existente na BD."""
    bd = obter_bd()

    # Determinar tabela e campo para cada tipo de contador
    if counter_type == 'assets':
        # Buscar MAX do serial_number (ex: SLP000123 -> 123)
        rows = bd.execute('SELECT serial_number FROM assets').fetchall()
        max_val = 0
        for row in rows:
            sn = row['serial_number'] or ''
            # Extrair dígitos do final
            digits = ''.join(filter(str.isdigit, sn))
            if digits:
                max_val = max(max_val, int(digits))
    elif counter_type.startswith('int_'):
        # Buscar MAX do intervention_number
        rows = bd.execute('SELECT intervention_number FROM interventions').fetchall()
        max_val = 0
        for row in rows:
            num = row['intervention_number'] or ''
            # Ex: INTP000001-A01 -> 1
            parts = num.split('-')[0] if '-' in num else num
            digits = ''.join(filter(str.isdigit, parts))
            if digits:
                max_val = max(max_val, int(digits))
    else:
        return jsonify({'error': 'Tipo de contador desconhecido'}), 400

    # Obter valor atual
    current = bd.execute(
        'SELECT current_value FROM sequence_counters WHERE counter_type = ?',
        (counter_type,)
    ).fetchone()
    old_value = current['current_value'] if current else 0

    # Atualizar contador
    bd.execute(
        'UPDATE sequence_counters SET current_value = ?, updated_at = CURRENT_TIMESTAMP WHERE counter_type = ?',
        (max_val, counter_type)
    )
    bd.commit()

    registar_auditoria(bd, g.utilizador_atual['user_id'], 'SYNC_COUNTER', 'sequence_counters', None, None,
                       {'counter_type': counter_type, 'old_value': old_value, 'new_value': max_val})

    return jsonify({
        'success': True,
        'counter_type': counter_type,
        'old_value': old_value,
        'new_value': max_val
    })


@system_bp.route('/config/sequence/reset/<string:counter_type>', methods=['POST'])
@requer_admin
def resetar_contador(counter_type):
    """Reseta o contador para 0."""
    bd = obter_bd()

    # Obter valor atual
    current = bd.execute(
        'SELECT current_value FROM sequence_counters WHERE counter_type = ?',
        (counter_type,)
    ).fetchone()

    if not current:
        return jsonify({'error': 'Contador não encontrado'}), 404

    old_value = current['current_value']

    # Resetar para 0
    bd.execute(
        'UPDATE sequence_counters SET current_value = 0, updated_at = CURRENT_TIMESTAMP WHERE counter_type = ?',
        (counter_type,)
    )
    bd.commit()

    registar_auditoria(bd, g.utilizador_atual['user_id'], 'RESET_COUNTER', 'sequence_counters', None, None,
                       {'counter_type': counter_type, 'old_value': old_value, 'new_value': 0})

    return jsonify({
        'success': True,
        'counter_type': counter_type,
        'old_value': old_value,
        'new_value': 0
    })


@system_bp.route('/logo')
def servir_logo():
    """Serve a logo da empresa."""
    logo_path = os.path.join(_config.PASTA_ASSETS, 'logo.png')
    if os.path.exists(logo_path):
        return send_file(logo_path, mimetype='image/png')
    return '', 404


@system_bp.route('/audit-log', methods=['GET'])
@requer_admin
def obter_log_auditoria():
    """Devolve o log de auditoria com paginação."""
    bd = obter_bd()

    pagina = int(request.args.get('page', 1))
    por_pagina = int(request.args.get('per_page', 50))

    total = bd.execute('SELECT COUNT(*) FROM audit_log').fetchone()[0]

    logs = bd.execute('''
        SELECT al.*, u.username
        FROM audit_log al
        LEFT JOIN users u ON al.user_id = u.id
        ORDER BY al.timestamp DESC
        LIMIT ? OFFSET ?
    ''', (por_pagina, (pagina - 1) * por_pagina)).fetchall()

    return jsonify({
        'logs': [dict(l) for l in logs],
        'total': total,
        'page': pagina,
        'per_page': por_pagina,
        'pages': (total + por_pagina - 1) // por_pagina
    })


# =============================================================================
# REFERÊNCIA DO PRODUTO — Utilidade + Migração
# =============================================================================

def construir_referencia_produto(base_ref, modules_refs):
    """Constrói a referência do produto no formato Coluna.Módulo1.Módulo2...

    Todos os componentes são separados por ponto. Módulos vazios são ignorados.

    Args:
        base_ref:      Referência da coluna (ex: 'SLP-PSF04-1SL').
        modules_refs:  Lista ordenada de referências de módulos (strings ou None).

    Returns:
        String no formato 'SLP-PSF04-1SL.LUSA-16-700-04.QE-1LVE-01011-040A...'
    """
    parts = [base_ref]
    for ref in (modules_refs or []):
        if ref:
            parts.append(ref)
    return '.'.join(parts)


def _corrigir_referencia(ref_antiga):
    """Corrige uma referência do formato antigo (Coluna-Luminária.resto)
    para o novo formato (Coluna.Luminária.resto).

    Referências de coluna no catálogo têm sempre 3 segmentos: SLP-XXX-YYY.
    Se a primeira parte (antes do primeiro '.') tiver mais de 3 segmentos '-',
    significa que a luminária está colada à coluna com '-'.

    Returns:
        (ref_nova, alterada)  —  alterada=True se houve mudança.
    """
    if not ref_antiga:
        return ref_antiga, False

    partes = ref_antiga.split('.')
    primeiro = partes[0]
    segmentos = primeiro.split('-')

    # Coluna tem sempre 3 segmentos (SLP-XXX-YYY).
    # Se houver mais, os restantes pertencem à luminária.
    if len(segmentos) <= 3:
        return ref_antiga, False

    coluna = '-'.join(segmentos[:3])
    luminaria = '-'.join(segmentos[3:])
    nova_partes = [coluna, luminaria] + partes[1:]
    ref_nova = '.'.join(nova_partes)

    return ref_nova, ref_nova != ref_antiga


@system_bp.route('/admin/migrate-references', methods=['POST'])
@requer_admin
def migrar_referencias():
    """Migra product_reference do formato antigo (Coluna-Lum.resto)
    para o novo (Coluna.Lum.resto).

    Body JSON (opcional):
        { "dry_run": true }   — apenas reporta, não altera a BD.
    """
    dados = request.get_json(silent=True) or {}
    dry_run = dados.get('dry_run', False)

    bd = obter_bd()

    refs = bd.execute('''
        SELECT ad.id, ad.asset_id, ad.field_value, a.serial_number
        FROM asset_data ad
        JOIN assets a ON ad.asset_id = a.id
        WHERE ad.field_name = 'product_reference'
          AND ad.field_value IS NOT NULL
          AND ad.field_value != ''
    ''').fetchall()

    alterados = []
    inalterados = 0

    for row in refs:
        ref_antiga = row['field_value']
        ref_nova, mudou = _corrigir_referencia(ref_antiga)

        if mudou:
            alterados.append({
                'serial_number': row['serial_number'],
                'antes': ref_antiga,
                'depois': ref_nova,
                'asset_data_id': row['id']
            })
        else:
            inalterados += 1

    if not dry_run and alterados:
        try:
            for item in alterados:
                bd.execute(
                    'UPDATE asset_data SET field_value = ? WHERE id = ?',
                    (item['depois'], item['asset_data_id'])
                )
            bd.commit()
        except Exception as e:
            bd.rollback()
            return jsonify({'error': f'Erro na migração: {str(e)}'}), 500

    return jsonify({
        'dry_run': dry_run,
        'total_analisados': len(refs),
        'total_alterados': len(alterados),
        'total_inalterados': inalterados,
        'exemplos': alterados[:20]
    })


# =============================================================================
# AUTO-BACKUP SCHEDULER
# =============================================================================

@system_bp.route('/config/auto-backup', methods=['GET'])
@requer_admin
def obter_config_auto_backup():
    """Devolve configuração do backup automático."""
    from app.scheduler import obter_proximo_backup

    enabled = obter_config('auto_backup_enabled', 'true').lower() == 'true'
    day = int(obter_config('auto_backup_day', '0'))
    hour = int(obter_config('auto_backup_hour', '2'))
    minute = int(obter_config('auto_backup_minute', '0'))

    proximo = obter_proximo_backup()

    return jsonify({
        'enabled': enabled,
        'day': day,
        'hour': hour,
        'minute': minute,
        'next_run': proximo.get('next_run') if proximo else None,
        'next_run_formatted': proximo.get('next_run_formatted') if proximo else None
    })


@system_bp.route('/config/auto-backup', methods=['PUT'])
@requer_admin
def atualizar_config_auto_backup():
    """Atualiza configuração do backup automático."""
    from app.scheduler import atualizar_configuracao_backup

    dados = request.json
    bd = obter_bd()
    user_id = g.utilizador_atual['user_id']

    campos = {
        'enabled': 'auto_backup_enabled',
        'day': 'auto_backup_day',
        'hour': 'auto_backup_hour',
        'minute': 'auto_backup_minute'
    }

    for campo, config_key in campos.items():
        if campo in dados:
            valor = dados[campo]
            if campo == 'enabled':
                valor = 'true' if valor else 'false'
            else:
                valor = str(int(valor))

            # Verificar se config existe
            existe = bd.execute(
                'SELECT 1 FROM system_config WHERE config_key = ?',
                (config_key,)
            ).fetchone()

            if existe:
                bd.execute('''
                    UPDATE system_config
                    SET config_value = ?, updated_at = CURRENT_TIMESTAMP, updated_by = ?
                    WHERE config_key = ?
                ''', (valor, user_id, config_key))
            else:
                bd.execute('''
                    INSERT INTO system_config (config_key, config_value, description, updated_by)
                    VALUES (?, ?, ?, ?)
                ''', (config_key, valor, f'Config auto-backup: {campo}', user_id))

    bd.commit()

    # Atualizar scheduler
    atualizar_configuracao_backup()

    # Obter próxima execução
    from app.scheduler import obter_proximo_backup
    proximo = obter_proximo_backup()

    return jsonify({
        'message': 'Configuração de backup automático atualizada',
        'next_run': proximo.get('next_run') if proximo else None,
        'next_run_formatted': proximo.get('next_run_formatted') if proximo else None
    })


# =============================================================================
# LIMPAR BASE DE DADOS (Reset Total)
# =============================================================================

@system_bp.route('/admin/clear-database', methods=['POST'])
@requer_admin
def limpar_base_dados():
    """Limpa toda a base de dados exceto utilizadores e configurações.

    Requer:
        - confirmation: texto "CONFIRMO"
        - password: password do admin actual

    Processo:
        1. Verifica confirmação e password
        2. Cria backup automático
        3. Elimina dados (assets, intervenções, técnicos, logs)
        4. Reseta contadores para 0
    """
    import hashlib
    from app.routes.backup import criar_backup_interno

    dados = request.json or {}
    confirmacao = dados.get('confirmation', '')
    password = dados.get('password', '')

    # Validar confirmação
    if confirmacao != 'CONFIRMO':
        return jsonify({'error': 'Texto de confirmação inválido. Escreva exatamente "CONFIRMO"'}), 400

    # Validar password do admin
    bd = obter_bd()
    user_id = g.utilizador_atual['user_id']

    utilizador = bd.execute(
        'SELECT password_hash FROM users WHERE id = ?',
        (user_id,)
    ).fetchone()

    if not utilizador:
        return jsonify({'error': 'Utilizador não encontrado'}), 404

    hash_fornecido = hashlib.sha256(password.encode()).hexdigest()
    if hash_fornecido != utilizador['password_hash']:
        return jsonify({'error': 'Password incorreta'}), 401

    # Criar backup antes de limpar
    try:
        backup_resultado = criar_backup_interno(
            prefixo='pre_reset',
            user_id=user_id,
            motivo='Backup automático antes de reset da base de dados'
        )
        if not backup_resultado.get('success'):
            return jsonify({
                'error': f'Falha ao criar backup de segurança: {backup_resultado.get("error", "Erro desconhecido")}'
            }), 500
        backup_name = backup_resultado.get('backup_name', 'unknown')
    except Exception as e:
        return jsonify({
            'error': f'Erro ao criar backup de segurança: {str(e)}'
        }), 500

    # Limpar tabelas (ordem importante devido a foreign keys)
    tabelas_limpar = [
        'intervention_files',
        'intervention_technicians',
        'intervention_time_logs',
        'intervention_edit_log',
        'intervention_updates',
        'interventions',
        'status_change_log',
        'maintenance_log',
        'asset_module_serials',
        'asset_data',
        'assets',
        'external_technicians',
        'audit_log',
    ]

    try:
        for tabela in tabelas_limpar:
            bd.execute(f'DELETE FROM {tabela}')

        # Resetar contadores para 0
        bd.execute('UPDATE sequence_counters SET current_value = 0, updated_at = CURRENT_TIMESTAMP')

        # Registar no audit_log (novo após limpeza)
        registar_auditoria(bd, user_id, 'CLEAR_DATABASE', None, None, None, {
            'backup_created': backup_name,
            'tables_cleared': tabelas_limpar,
            'counters_reset': True
        })

        bd.commit()

    except Exception as e:
        bd.rollback()
        return jsonify({'error': f'Erro ao limpar base de dados: {str(e)}'}), 500

    return jsonify({
        'success': True,
        'message': 'Base de dados limpa com sucesso',
        'backup_created': backup_name,
        'tables_cleared': tabelas_limpar,
        'counters_reset': True
    })
