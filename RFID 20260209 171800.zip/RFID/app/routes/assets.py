"""
SmartLamppost - Rotas de Gestão de Ativos RFID
"""

import json
import sqlite3
from datetime import datetime
from flask import request, jsonify, g

from app.routes import assets_bp
from app.database import obter_bd, obter_config, registar_auditoria
from app.utils import requer_autenticacao, requer_admin
from app.routes.backup import criar_backup_interno


@assets_bp.route('/map', methods=['GET'])
@requer_autenticacao
def obter_ativos_mapa():
    """Devolve ativos com coordenadas GPS para visualizacao no mapa."""
    bd = obter_bd()
    municipio = request.args.get('municipality', '')
    estado = request.args.get('status', '')

    query = '''
        SELECT a.id, a.serial_number,
               lat.field_value as latitude,
               lon.field_value as longitude,
               loc.field_value as location,
               stat.field_value as status,
               ref.field_value as product_reference,
               mun.field_value as municipality,
               pw.field_value as power_watts,
               rfid.field_value as rfid_tag
        FROM assets a
        LEFT JOIN asset_data lat ON a.id = lat.asset_id AND lat.field_name = 'gps_latitude'
        LEFT JOIN asset_data lon ON a.id = lon.asset_id AND lon.field_name = 'gps_longitude'
        LEFT JOIN asset_data loc ON a.id = loc.asset_id AND loc.field_name = 'installation_location'
        LEFT JOIN asset_data stat ON a.id = stat.asset_id AND stat.field_name = 'condition_status'
        LEFT JOIN asset_data ref ON a.id = ref.asset_id AND ref.field_name = 'product_reference'
        LEFT JOIN asset_data mun ON a.id = mun.asset_id AND mun.field_name = 'municipality'
        LEFT JOIN asset_data pw ON a.id = pw.asset_id AND pw.field_name = 'power_watts'
        LEFT JOIN asset_data rfid ON a.id = rfid.asset_id AND rfid.field_name = 'rfid_tag'
        WHERE lat.field_value IS NOT NULL
          AND lon.field_value IS NOT NULL
          AND lat.field_value != ''
          AND lon.field_value != ''
    '''

    params = []

    if municipio:
        query += ' AND mun.field_value = ?'
        params.append(municipio)

    if estado:
        query += ' AND stat.field_value = ?'
        params.append(estado)

    query += ' ORDER BY a.serial_number'

    ativos = bd.execute(query, params).fetchall()

    resultado = []
    for a in ativos:
        try:
            lat = float(a['latitude']) if a['latitude'] else None
            lon = float(a['longitude']) if a['longitude'] else None
            if lat is not None and lon is not None:
                resultado.append({
                    'id': a['id'],
                    'serial_number': a['serial_number'],
                    'latitude': lat,
                    'longitude': lon,
                    'location': a['location'] or '',
                    'status': a['status'] or 'N/D',
                    'product_reference': a['product_reference'] or '',
                    'municipality': a['municipality'] or '',
                    'power_watts': a['power_watts'] or '',
                    'rfid_tag': a['rfid_tag'] or ''
                })
        except (ValueError, TypeError):
            continue

    municipios = bd.execute('''
        SELECT DISTINCT field_value FROM asset_data
        WHERE field_name = 'municipality' AND field_value IS NOT NULL AND field_value != ''
        ORDER BY field_value
    ''').fetchall()

    estados = bd.execute('''
        SELECT DISTINCT field_value FROM asset_data
        WHERE field_name = 'condition_status' AND field_value IS NOT NULL AND field_value != ''
        ORDER BY field_value
    ''').fetchall()

    return jsonify({
        'assets': resultado,
        'total': len(resultado),
        'filters': {
            'municipalities': [m['field_value'] for m in municipios],
            'statuses': [s['field_value'] for s in estados]
        }
    })


@assets_bp.route('', methods=['GET'])
@requer_autenticacao
def listar_ativos():
    """Lista todos os ativos com paginação e pesquisa."""
    bd = obter_bd()

    pagina = request.args.get('page', 1, type=int)
    por_pagina = request.args.get('per_page', 50, type=int)
    offset = (pagina - 1) * por_pagina
    pesquisa = request.args.get('search', '')

    if pesquisa:
        total = bd.execute('''
            SELECT COUNT(DISTINCT a.id) FROM assets a
            LEFT JOIN asset_data ad ON a.id = ad.asset_id
            WHERE a.serial_number LIKE ? OR ad.field_value LIKE ?
        ''', (f'%{pesquisa}%', f'%{pesquisa}%')).fetchone()[0]

        ativos = bd.execute('''
            SELECT DISTINCT a.* FROM assets a
            LEFT JOIN asset_data ad ON a.id = ad.asset_id
            WHERE a.serial_number LIKE ? OR ad.field_value LIKE ?
            ORDER BY a.updated_at DESC LIMIT ? OFFSET ?
        ''', (f'%{pesquisa}%', f'%{pesquisa}%', por_pagina, offset)).fetchall()
    else:
        total = bd.execute('SELECT COUNT(*) FROM assets').fetchone()[0]
        ativos = bd.execute('''
            SELECT * FROM assets ORDER BY updated_at DESC LIMIT ? OFFSET ?
        ''', (por_pagina, offset)).fetchall()

    resultado = []
    for ativo in ativos:
        ativo_dict = dict(ativo)
        dados = bd.execute('SELECT field_name, field_value FROM asset_data WHERE asset_id = ?',
                           (ativo['id'],)).fetchall()
        ativo_dict['data'] = {d['field_name']: d['field_value'] for d in dados}
        resultado.append(ativo_dict)

    return jsonify({
        'assets': resultado,
        'total': total,
        'page': pagina,
        'per_page': por_pagina,
        'pages': (total + por_pagina - 1) // por_pagina
    })


@assets_bp.route('/<string:serial_number>', methods=['GET'])
@requer_autenticacao
def obter_ativo(serial_number):
    """Devolve os detalhes de um ativo específico pelo número de série."""
    bd = obter_bd()
    ativo = bd.execute('SELECT * FROM assets WHERE serial_number = ?', (serial_number,)).fetchone()

    if not ativo:
        return jsonify({'error': 'Ativo não encontrado'}), 404

    ativo_dict = dict(ativo)
    dados = bd.execute('SELECT field_name, field_value FROM asset_data WHERE asset_id = ?',
                       (ativo['id'],)).fetchall()
    ativo_dict['data'] = {d['field_name']: d['field_value'] for d in dados}

    manutencoes = bd.execute('''
        SELECT m.*, u.username as performed_by_name
        FROM maintenance_log m LEFT JOIN users u ON m.performed_by = u.id
        WHERE m.asset_id = ? ORDER BY m.performed_at DESC
    ''', (ativo['id'],)).fetchall()
    ativo_dict['maintenance_history'] = [dict(m) for m in manutencoes]

    # Histórico de alterações de estado
    alteracoes_estado = bd.execute('''
        SELECT s.*, u.username as changed_by_name
        FROM status_change_log s LEFT JOIN users u ON s.changed_by = u.id
        WHERE s.asset_id = ? ORDER BY s.changed_at DESC
    ''', (ativo['id'],)).fetchall()
    ativo_dict['status_history'] = [dict(s) for s in alteracoes_estado]

    # Intervenções
    intervencoes = bd.execute('''
        SELECT i.*, u.username as created_by_name,
               (SELECT COUNT(*) FROM intervention_files WHERE intervention_id = i.id) as file_count
        FROM interventions i
        LEFT JOIN users u ON i.created_by = u.id
        WHERE i.asset_id = ?
        ORDER BY i.created_at DESC
    ''', (ativo['id'],)).fetchall()
    ativo_dict['interventions'] = [dict(i) for i in intervencoes]

    # Números de série dos módulos/equipamentos associados
    modulos = bd.execute('''
        SELECT module_name, module_description, serial_number, updated_at
        FROM asset_module_serials
        WHERE asset_id = ?
        ORDER BY module_name
    ''', (ativo['id'],)).fetchall()
    ativo_dict['module_serials'] = [dict(m) for m in modulos]

    # Mapa module_name → serial_number por tipo limpo (para o frontend/configurador)
    by_type = {}
    for m in modulos:
        mn = m['module_name'] or ''
        if not mn.startswith('Módulo Adicional'):
            by_type[mn] = m['serial_number'] or ''
    ativo_dict['module_serials_by_type'] = by_type

    return jsonify(ativo_dict)


def gerar_proximo_serial(bd, tipo='assets'):
    """Gera o proximo serial number a partir do contador e incrementa-o atomicamente.
    Verifica colisoes com seriais existentes (ex: importados sem actualizar contador)."""
    if tipo == 'assets':
        prefixo = obter_config('prefix_assets', 'SLP')
        digitos = int(obter_config('prefix_assets_digits', '9'))
    else:
        prefixo = obter_config(f'prefix_{tipo}', 'INT')
        digitos = int(obter_config('prefix_int_digits', '9'))

    resultado = bd.execute(
        'SELECT current_value FROM sequence_counters WHERE counter_type = ?',
        (tipo,)
    ).fetchone()
    valor_atual = resultado['current_value'] if resultado else 0
    proximo = valor_atual + 1

    # Verificar colisoes com seriais ja existentes (safety net)
    if tipo == 'assets':
        for _ in range(1000):
            serial = f"{prefixo}{str(proximo).zfill(digitos)}"
            existente = bd.execute(
                'SELECT 1 FROM assets WHERE serial_number = ?', (serial,)
            ).fetchone()
            if not existente:
                break
            proximo += 1

    bd.execute(
        'UPDATE sequence_counters SET current_value = ?, updated_at = CURRENT_TIMESTAMP WHERE counter_type = ?',
        (proximo, tipo)
    )

    return f"{prefixo}{str(proximo).zfill(digitos)}"


@assets_bp.route('', methods=['POST'])
@requer_autenticacao
def criar_ativo():
    """Cria um novo ativo. Se serial_number nao for fornecido, gera automaticamente."""
    dados = request.json
    serial_number = dados.get('serial_number', '').strip()
    auto_generated = False

    bd = obter_bd()

    if not serial_number:
        serial_number = gerar_proximo_serial(bd, 'assets')
        auto_generated = True

    # Validar campos obrigatórios
    campos_obrigatorios = bd.execute('SELECT field_name FROM schema_fields WHERE required = 1').fetchall()
    dados_ativo = dados.get('data', {})

    for campo in campos_obrigatorios:
        if campo['field_name'] not in dados_ativo or not dados_ativo[campo['field_name']]:
            return jsonify({'error': f'Campo obrigatório: {campo["field_name"]}'}), 400

    # Validar campos obrigatórios para Operacional
    condition_status = (dados_ativo.get('condition_status') or '').strip()
    if condition_status == 'Operacional':
        campos_operacional = {'rfid_tag': 'RFID Tag', 'manufacturer': 'Fabricante', 'model': 'Modelo'}
        em_falta = []
        for campo, label in campos_operacional.items():
            if not (dados_ativo.get(campo) or '').strip():
                em_falta.append(label)
        if em_falta:
            return jsonify({'error': f'Para Operacional, preencha: {", ".join(em_falta)}'}), 400

    try:
        cursor = bd.execute('''
            INSERT INTO assets (serial_number, created_by, updated_by) VALUES (?, ?, ?)
        ''', (serial_number, g.utilizador_atual['user_id'], g.utilizador_atual['user_id']))

        asset_id = cursor.lastrowid

        for nome_campo, valor in dados_ativo.items():
            if valor is not None:
                bd.execute('''
                    INSERT INTO asset_data (asset_id, field_name, field_value) VALUES (?, ?, ?)
                ''', (asset_id, nome_campo, str(valor)))

        bd.commit()
        registar_auditoria(bd, g.utilizador_atual['user_id'], 'CREATE', 'assets', asset_id, None, dados)
        return jsonify({
            'message': 'Ativo criado com sucesso',
            'serial_number': serial_number,
            'auto_generated': auto_generated
        }), 201
    except sqlite3.IntegrityError:
        return jsonify({'error': 'Número de Série já existe'}), 400


@assets_bp.route('/<string:serial_number>', methods=['PUT'])
@requer_autenticacao
def atualizar_ativo(serial_number):
    """Atualiza um ativo existente. Permite alterar RFID Tag se danificado."""
    bd = obter_bd()
    ativo = bd.execute('SELECT * FROM assets WHERE serial_number = ?', (serial_number,)).fetchone()

    if not ativo:
        return jsonify({'error': 'Ativo não encontrado'}), 404

    dados = request.json
    dados_ativo = dados.get('data', {})

    # Validar campos obrigatórios para Operacional
    condition_status = (dados_ativo.get('condition_status') or '').strip()
    if condition_status == 'Operacional':
        campos_operacional = {'rfid_tag': 'RFID Tag', 'manufacturer': 'Fabricante', 'model': 'Modelo'}
        em_falta = []
        for campo, label in campos_operacional.items():
            if not (dados_ativo.get(campo) or '').strip():
                em_falta.append(label)
        if em_falta:
            return jsonify({'error': f'Para Operacional, preencha: {", ".join(em_falta)}'}), 400

    # Obter dados antigos para auditoria
    dados_antigos = bd.execute('SELECT field_name, field_value FROM asset_data WHERE asset_id = ?',
                               (ativo['id'],)).fetchall()
    dados_antigos_dict = {d['field_name']: d['field_value'] for d in dados_antigos}

    for nome_campo, valor in dados_ativo.items():
        bd.execute('''
            INSERT OR REPLACE INTO asset_data (asset_id, field_name, field_value) VALUES (?, ?, ?)
        ''', (ativo['id'], nome_campo, str(valor) if valor is not None else None))

    bd.execute('UPDATE assets SET updated_at = ?, updated_by = ? WHERE id = ?',
               (datetime.now(), g.utilizador_atual['user_id'], ativo['id']))
    bd.commit()
    registar_auditoria(bd, g.utilizador_atual['user_id'], 'UPDATE', 'assets', ativo['id'],
                       dados_antigos_dict, dados_ativo)
    return jsonify({'message': 'Ativo atualizado'})


@assets_bp.route('/<string:serial_number>', methods=['DELETE'])
@requer_autenticacao
def eliminar_ativo(serial_number):
    """Elimina um ativo pelo número de série."""
    bd = obter_bd()
    ativo = bd.execute('SELECT * FROM assets WHERE serial_number = ?', (serial_number,)).fetchone()

    if not ativo:
        return jsonify({'error': 'Ativo não encontrado'}), 404

    dados_antigos = bd.execute('SELECT field_name, field_value FROM asset_data WHERE asset_id = ?',
                               (ativo['id'],)).fetchall()
    dados_antigos_dict = {d['field_name']: d['field_value'] for d in dados_antigos}

    bd.execute('DELETE FROM asset_data WHERE asset_id = ?', (ativo['id'],))
    bd.execute('DELETE FROM maintenance_log WHERE asset_id = ?', (ativo['id'],))
    bd.execute('DELETE FROM asset_module_serials WHERE asset_id = ?', (ativo['id'],))
    bd.execute('DELETE FROM assets WHERE id = ?', (ativo['id'],))

    # Decrementar o contador de ativos
    bd.execute('''
        UPDATE sequence_counters
        SET current_value = CASE WHEN current_value > 0 THEN current_value - 1 ELSE 0 END,
            updated_at = CURRENT_TIMESTAMP
        WHERE counter_type = 'assets'
    ''')

    bd.commit()
    registar_auditoria(bd, g.utilizador_atual['user_id'], 'DELETE', 'assets', ativo['id'],
                       {'serial_number': serial_number, **dados_antigos_dict}, None)
    return jsonify({'message': 'Ativo eliminado'})


@assets_bp.route('/bulk', methods=['DELETE'])
@requer_admin
def eliminar_ativos_em_massa():
    """Elimina multiplos ativos com backup automatico previo.

    Recebe JSON: {"serial_numbers": ["SLP001", "SLP002", ...]}
    Limite: 200 ativos por pedido.
    """
    dados = request.json
    serial_numbers = dados.get('serial_numbers', [])

    if not serial_numbers:
        return jsonify({'error': 'Nenhum ativo selecionado'}), 400

    if not isinstance(serial_numbers, list):
        return jsonify({'error': 'serial_numbers deve ser uma lista'}), 400

    if len(serial_numbers) > 200:
        return jsonify({'error': 'Maximo 200 ativos por pedido'}), 400

    user_id = g.utilizador_atual['user_id']

    # 1. Criar backup automatico ANTES de eliminar
    backup_result = criar_backup_interno(
        prefixo='auto_backup',
        user_id=user_id,
        motivo=f'Backup automatico antes de eliminar {len(serial_numbers)} ativos'
    )

    if not backup_result.get('success'):
        return jsonify({
            'error': 'Falha ao criar backup automatico. Nenhum ativo foi eliminado.',
            'backup_error': backup_result.get('error')
        }), 500

    backup_name = backup_result['backup_name']

    # 2. Eliminar ativos um a um (reutilizando logica do delete individual)
    bd = obter_bd()
    deleted = []
    failed = []

    for sn in serial_numbers:
        try:
            ativo = bd.execute('SELECT * FROM assets WHERE serial_number = ?', (sn,)).fetchone()
            if not ativo:
                failed.append({'serial_number': sn, 'error': 'Ativo nao encontrado'})
                continue

            # Guardar dados para auditoria
            dados_antigos = bd.execute(
                'SELECT field_name, field_value FROM asset_data WHERE asset_id = ?',
                (ativo['id'],)
            ).fetchall()
            dados_antigos_dict = {d['field_name']: d['field_value'] for d in dados_antigos}

            # Eliminar dados relacionados (mesma logica do delete individual)
            bd.execute('DELETE FROM asset_data WHERE asset_id = ?', (ativo['id'],))
            bd.execute('DELETE FROM maintenance_log WHERE asset_id = ?', (ativo['id'],))
            bd.execute('DELETE FROM asset_module_serials WHERE asset_id = ?', (ativo['id'],))
            bd.execute('DELETE FROM assets WHERE id = ?', (ativo['id'],))

            # Registar auditoria para cada ativo eliminado
            registar_auditoria(bd, user_id, 'BULK_DELETE', 'assets', ativo['id'],
                               {'serial_number': sn, **dados_antigos_dict}, None)

            deleted.append(sn)

        except Exception as e:
            failed.append({'serial_number': sn, 'error': str(e)})

    # 3. Ajustar contador (decrementar pelo numero de ativos eliminados)
    if deleted:
        bd.execute('''
            UPDATE sequence_counters
            SET current_value = CASE
                WHEN current_value >= ? THEN current_value - ?
                ELSE 0
            END,
            updated_at = CURRENT_TIMESTAMP
            WHERE counter_type = 'assets'
        ''', (len(deleted), len(deleted)))

    bd.commit()

    # 4. Registar auditoria global da operacao em massa
    registar_auditoria(bd, user_id, 'BULK_DELETE_COMPLETE', 'assets', None, None, {
        'total_requested': len(serial_numbers),
        'deleted_count': len(deleted),
        'failed_count': len(failed),
        'backup_name': backup_name,
        'deleted_serials': deleted[:50],  # Limitar para nao sobrecarregar o log
        'failed_details': failed[:20]
    })
    bd.commit()

    return jsonify({
        'success': True,
        'deleted': len(deleted),
        'failed': len(failed),
        'backup_name': backup_name,
        'deleted_serials': deleted,
        'failed_details': failed
    })


@assets_bp.route('/duplicate', methods=['POST'])
@requer_autenticacao
def duplicar_ativo():
    """Duplica um ativo N vezes com serial auto-gerado e estado Suspenso.

    Recebe JSON: {"serial_number": "SLP001", "quantity": 5}
    Limite: 99 copias por pedido.

    Campos duplicados: todos EXCETO rfid_tag, gps_latitude, gps_longitude.
    Modulos: duplica descricoes SEM numeros de serie.
    """
    dados = request.json
    serial_number = dados.get('serial_number', '').strip()
    quantity = dados.get('quantity', 1)

    if not serial_number:
        return jsonify({'error': 'serial_number obrigatorio'}), 400

    if not isinstance(quantity, int) or quantity < 1 or quantity > 99:
        return jsonify({'error': 'quantity deve ser entre 1 e 99'}), 400

    bd = obter_bd()
    user_id = g.utilizador_atual['user_id']

    # Obter ativo original
    original = bd.execute('SELECT * FROM assets WHERE serial_number = ?', (serial_number,)).fetchone()
    if not original:
        return jsonify({'error': 'Ativo nao encontrado'}), 404

    # Obter dados do ativo original
    dados_originais = bd.execute(
        'SELECT field_name, field_value FROM asset_data WHERE asset_id = ?',
        (original['id'],)
    ).fetchall()
    dados_dict = {d['field_name']: d['field_value'] for d in dados_originais}

    # Obter modulos do ativo original (sem serial_number)
    modulos_originais = bd.execute(
        'SELECT module_name, module_description FROM asset_module_serials WHERE asset_id = ?',
        (original['id'],)
    ).fetchall()

    # Campos a NAO duplicar
    campos_excluir = {'rfid_tag', 'gps_latitude', 'gps_longitude'}

    created_serials = []
    failed = []

    for i in range(quantity):
        try:
            # Gerar serial automatico
            novo_serial = gerar_proximo_serial(bd, 'assets')

            # Criar novo ativo
            cursor = bd.execute(
                'INSERT INTO assets (serial_number, created_by, updated_by) VALUES (?, ?, ?)',
                (novo_serial, user_id, user_id)
            )
            novo_id = cursor.lastrowid

            # Copiar dados (exceto campos excluidos)
            for field_name, field_value in dados_dict.items():
                if field_name in campos_excluir:
                    continue
                # Forcar condition_status = 'Suspenso'
                if field_name == 'condition_status':
                    field_value = 'Suspenso'
                if field_value is not None:
                    bd.execute(
                        'INSERT INTO asset_data (asset_id, field_name, field_value) VALUES (?, ?, ?)',
                        (novo_id, field_name, field_value)
                    )

            # Garantir que condition_status existe como Suspenso
            if 'condition_status' not in dados_dict:
                bd.execute(
                    'INSERT INTO asset_data (asset_id, field_name, field_value) VALUES (?, ?, ?)',
                    (novo_id, 'condition_status', 'Suspenso')
                )

            # Copiar modulos SEM serial_number
            for mod in modulos_originais:
                bd.execute(
                    'INSERT INTO asset_module_serials (asset_id, module_name, module_description, serial_number) VALUES (?, ?, ?, ?)',
                    (novo_id, mod['module_name'], mod['module_description'], '')
                )

            created_serials.append(novo_serial)

        except Exception as e:
            failed.append({'index': i + 1, 'error': str(e)})

    bd.commit()

    # Registar auditoria
    registar_auditoria(bd, user_id, 'DUPLICATE', 'assets', original['id'], None, {
        'source_serial': serial_number,
        'quantity_requested': quantity,
        'created_count': len(created_serials),
        'created_serials': created_serials[:20],
        'failed_count': len(failed)
    })
    bd.commit()

    return jsonify({
        'success': True,
        'source_serial': serial_number,
        'created': len(created_serials),
        'created_serials': created_serials,
        'failed': len(failed),
        'failed_details': failed
    })


@assets_bp.route('/<string:serial_number>/maintenance', methods=['POST'])
@requer_autenticacao
def adicionar_manutencao(serial_number):
    """Adiciona um registo de manutenção a um ativo."""
    bd = obter_bd()
    ativo = bd.execute('SELECT * FROM assets WHERE serial_number = ?', (serial_number,)).fetchone()

    if not ativo:
        return jsonify({'error': 'Ativo não encontrado'}), 404

    dados = request.json
    bd.execute('''
        INSERT INTO maintenance_log (asset_id, action_type, description, performed_by)
        VALUES (?, ?, ?, ?)
    ''', (ativo['id'], dados.get('action_type'), dados.get('description'), g.utilizador_atual['user_id']))
    bd.commit()
    return jsonify({'message': 'Registo de manutenção adicionado'}), 201


# =============================================================================
# ALTERAÇÃO DE ESTADO EM MASSA
# =============================================================================

@assets_bp.route('/change-status', methods=['POST'])
@requer_autenticacao
def alterar_estado_ativos():
    """
    Altera o estado de um ou mais ativos.
    Espera: { serial_numbers: [...], new_status: '...', description: '...' }
    """
    dados = request.json
    serial_numbers = dados.get('serial_numbers', [])
    novo_estado = dados.get('new_status')
    descricao = dados.get('description', '').strip()

    # Validações
    if not serial_numbers:
        return jsonify({'error': 'Nenhum ativo selecionado'}), 400

    if not novo_estado:
        return jsonify({'error': 'Estado não especificado'}), 400

    if not descricao:
        return jsonify({'error': 'Descrição obrigatória'}), 400

    estados_validos = ['Operacional', 'Manutenção Necessária', 'Em Reparação', 'Desativado']
    if novo_estado not in estados_validos:
        return jsonify({'error': f'Estado inválido. Estados válidos: {", ".join(estados_validos)}'}), 400

    bd = obter_bd()
    user_id = g.utilizador_atual['user_id']

    resultados = {'sucesso': [], 'erros': []}

    for sn in serial_numbers:
        try:
            # Obter ativo
            ativo = bd.execute('SELECT id FROM assets WHERE serial_number = ?', (sn,)).fetchone()
            if not ativo:
                resultados['erros'].append({'serial_number': sn, 'erro': 'Ativo não encontrado'})
                continue

            asset_id = ativo['id']

            # Obter estado anterior
            estado_anterior_row = bd.execute('''
                SELECT field_value FROM asset_data
                WHERE asset_id = ? AND field_name = 'condition_status'
            ''', (asset_id,)).fetchone()
            estado_anterior = estado_anterior_row['field_value'] if estado_anterior_row else None

            # Actualizar estado em asset_data
            bd.execute('''
                INSERT OR REPLACE INTO asset_data (asset_id, field_name, field_value)
                VALUES (?, 'condition_status', ?)
            ''', (asset_id, novo_estado))

            # Actualizar timestamp do ativo
            bd.execute('''
                UPDATE assets SET updated_at = CURRENT_TIMESTAMP, updated_by = ?
                WHERE id = ?
            ''', (user_id, asset_id))

            # Registar no histórico de alterações de estado
            bd.execute('''
                INSERT INTO status_change_log (asset_id, previous_status, new_status, description, changed_by)
                VALUES (?, ?, ?, ?, ?)
            ''', (asset_id, estado_anterior, novo_estado, descricao, user_id))

            # Registar na auditoria
            bd.execute('''
                INSERT INTO audit_log (user_id, action, table_name, record_id, old_values, new_values)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (user_id, 'STATUS_CHANGE', 'assets', asset_id,
                  json.dumps({'condition_status': estado_anterior}),
                  json.dumps({'condition_status': novo_estado, 'description': descricao})))

            resultados['sucesso'].append({
                'serial_number': sn,
                'estado_anterior': estado_anterior,
                'novo_estado': novo_estado
            })

        except Exception as e:
            resultados['erros'].append({'serial_number': sn, 'erro': str(e)})

    bd.commit()

    return jsonify({
        'message': f'{len(resultados["sucesso"])} ativo(s) atualizado(s)',
        'resultados': resultados
    })


@assets_bp.route('/<string:serial_number>/status-history', methods=['GET'])
@requer_autenticacao
def obter_historico_estado(serial_number):
    """Devolve o histórico de alterações de estado de um ativo."""
    bd = obter_bd()
    ativo = bd.execute('SELECT id FROM assets WHERE serial_number = ?', (serial_number,)).fetchone()

    if not ativo:
        return jsonify({'error': 'Ativo não encontrado'}), 404

    historico = bd.execute('''
        SELECT s.*, u.username as changed_by_name
        FROM status_change_log s
        LEFT JOIN users u ON s.changed_by = u.id
        WHERE s.asset_id = ?
        ORDER BY s.changed_at DESC
    ''', (ativo['id'],)).fetchall()

    return jsonify({
        'serial_number': serial_number,
        'history': [dict(h) for h in historico]
    })


# =============================================================================
# NÚMEROS DE SÉRIE DOS MÓDULOS/EQUIPAMENTOS
# =============================================================================

@assets_bp.route('/<string:serial_number>/modules', methods=['GET'])
@requer_autenticacao
def obter_modulos_ativo(serial_number):
    """Devolve os números de série dos módulos/equipamentos de um ativo."""
    bd = obter_bd()
    ativo = bd.execute('SELECT id FROM assets WHERE serial_number = ?', (serial_number,)).fetchone()

    if not ativo:
        return jsonify({'error': 'Ativo não encontrado'}), 404

    modulos = bd.execute('''
        SELECT id, module_name, module_description, serial_number, updated_at
        FROM asset_module_serials
        WHERE asset_id = ?
        ORDER BY module_name
    ''', (ativo['id'],)).fetchall()

    return jsonify({
        'asset_serial_number': serial_number,
        'modules': [dict(m) for m in modulos]
    })


@assets_bp.route('/<string:serial_number>/modules', methods=['POST'])
@requer_autenticacao
def adicionar_modulo_ativo(serial_number):
    """Adiciona ou atualiza o número de série de um módulo/equipamento."""
    bd = obter_bd()
    ativo = bd.execute('SELECT id FROM assets WHERE serial_number = ?', (serial_number,)).fetchone()

    if not ativo:
        return jsonify({'error': 'Ativo não encontrado'}), 404

    dados = request.json
    module_name = dados.get('module_name')
    module_description = dados.get('module_description', '')
    module_serial = dados.get('serial_number', '')

    if not module_name:
        return jsonify({'error': 'Nome do módulo obrigatório'}), 400

    user_id = g.utilizador_atual['user_id']

    bd.execute('''
        INSERT INTO asset_module_serials (asset_id, module_name, module_description, serial_number, updated_by, updated_at)
        VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
        ON CONFLICT(asset_id, module_name) DO UPDATE SET
            module_description = excluded.module_description,
            serial_number = excluded.serial_number,
            updated_by = excluded.updated_by,
            updated_at = CURRENT_TIMESTAMP
    ''', (ativo['id'], module_name, module_description, module_serial, user_id))

    bd.commit()

    registar_auditoria(bd, user_id, 'UPDATE_MODULE', 'asset_module_serials', ativo['id'],
                       None, {'module_name': module_name, 'serial_number': module_serial})

    return jsonify({'message': 'Módulo atualizado com sucesso'})


@assets_bp.route('/<string:serial_number>/modules/bulk', methods=['POST'])
@requer_autenticacao
def atualizar_modulos_ativo_em_massa(serial_number):
    """Atualiza vários módulos de uma vez (usado pelo frontend ao guardar)."""
    bd = obter_bd()
    ativo = bd.execute('SELECT id FROM assets WHERE serial_number = ?', (serial_number,)).fetchone()

    if not ativo:
        return jsonify({'error': 'Ativo não encontrado'}), 404

    dados = request.json
    modulos = dados.get('modules', [])

    user_id = g.utilizador_atual['user_id']

    for modulo in modulos:
        module_name = modulo.get('module_name')
        module_description = modulo.get('module_description', '')
        module_serial = modulo.get('serial_number', '')

        if module_name:
            bd.execute('''
                INSERT INTO asset_module_serials (asset_id, module_name, module_description, serial_number, updated_by, updated_at)
                VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                ON CONFLICT(asset_id, module_name) DO UPDATE SET
                    module_description = CASE
                        WHEN excluded.module_description != '' THEN excluded.module_description
                        ELSE asset_module_serials.module_description
                    END,
                    serial_number = excluded.serial_number,
                    updated_by = excluded.updated_by,
                    updated_at = CURRENT_TIMESTAMP
            ''', (ativo['id'], module_name, module_description, module_serial, user_id))

    bd.commit()

    registar_auditoria(bd, user_id, 'BULK_UPDATE_MODULES', 'asset_module_serials', ativo['id'],
                       None, {'modules_count': len(modulos)})

    return jsonify({'message': f'{len(modulos)} módulo(s) atualizado(s)'})


@assets_bp.route('/<string:serial_number>/modules/<string:module_name>', methods=['DELETE'])
@requer_autenticacao
def eliminar_modulo_ativo(serial_number, module_name):
    """Remove um módulo de um ativo."""
    bd = obter_bd()
    ativo = bd.execute('SELECT id FROM assets WHERE serial_number = ?', (serial_number,)).fetchone()

    if not ativo:
        return jsonify({'error': 'Ativo não encontrado'}), 404

    bd.execute('''
        DELETE FROM asset_module_serials
        WHERE asset_id = ? AND module_name = ?
    ''', (ativo['id'], module_name))

    bd.commit()

    return jsonify({'message': 'Módulo removido'})
