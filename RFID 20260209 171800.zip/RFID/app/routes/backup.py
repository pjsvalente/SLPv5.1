"""
SmartLamppost - Rotas de Backup e Restauro
"""

import os
import shutil
import zipfile
from io import BytesIO
from datetime import datetime
from flask import request, jsonify, g, send_file

from app.routes import backup_bp
from app.database import obter_bd, registar_auditoria
from app.utils import requer_admin
from app.config import get_config

config = get_config()


def criar_backup_interno(prefixo='backup', user_id=None, motivo=None):
    """Cria um backup completo da BD e uploads. Funcao interna reutilizavel.

    Args:
        prefixo: Prefixo do nome do backup (default: 'backup')
        user_id: ID do utilizador para auditoria (opcional)
        motivo: Descricao do motivo do backup para auditoria (opcional)

    Returns:
        dict com 'success', 'backup_name', 'file_path' ou 'error'
    """
    try:
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        nome_backup = f'{prefixo}_{timestamp}'
        pasta_backup = os.path.join(config.PASTA_BACKUPS, nome_backup)

        os.makedirs(pasta_backup, exist_ok=True)

        # Copiar base de dados
        shutil.copy2(config.BASE_DADOS, os.path.join(pasta_backup, 'smartlamppost.db'))

        # Copiar pasta de uploads se existir (continuar mesmo se falhar - BD é o essencial)
        uploads_copied = False
        if os.path.exists(config.PASTA_UPLOADS):
            uploads_dest = os.path.join(pasta_backup, 'uploads')
            try:
                # Copiar ficheiro a ficheiro para maior controlo sobre erros
                for root, dirs, files in os.walk(config.PASTA_UPLOADS):
                    rel_path = os.path.relpath(root, config.PASTA_UPLOADS)
                    dest_dir = os.path.join(uploads_dest, rel_path) if rel_path != '.' else uploads_dest
                    try:
                        os.makedirs(dest_dir, exist_ok=True)
                    except (PermissionError, OSError):
                        continue
                    for file in files:
                        try:
                            src = os.path.join(root, file)
                            dst = os.path.join(dest_dir, file)
                            shutil.copy2(src, dst)
                            uploads_copied = True
                        except (PermissionError, OSError):
                            pass  # Ignorar ficheiros que nao podem ser copiados
            except Exception:
                pass  # Continuar mesmo se uploads falhar completamente

        # Criar ZIP
        zip_path = os.path.join(config.PASTA_BACKUPS, f'{nome_backup}.zip')
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(pasta_backup):
                for file in files:
                    file_path = os.path.join(root, file)
                    arcname = os.path.relpath(file_path, pasta_backup)
                    zipf.write(file_path, arcname)

        # Limpar pasta temporária
        shutil.rmtree(pasta_backup)

        # Limpar backups antigos
        _limpar_backups_antigos()

        # Registar auditoria se user_id fornecido
        if user_id:
            bd = obter_bd()
            detalhes = {'backup_name': nome_backup}
            if motivo:
                detalhes['motivo'] = motivo
            registar_auditoria(bd, user_id, 'BACKUP_CREATE', 'system', None, None, detalhes)
            bd.commit()

        return {
            'success': True,
            'backup_name': nome_backup,
            'file_path': zip_path
        }

    except Exception as e:
        return {'success': False, 'error': str(e)}


@backup_bp.route('/backup', methods=['POST'])
@requer_admin
def criar_backup():
    """Cria um backup completo da base de dados e ficheiros."""
    user_id = g.utilizador_atual['user_id']

    resultado = criar_backup_interno(prefixo='backup', user_id=user_id)

    if resultado.get('success'):
        return jsonify({
            'success': True,
            'message': 'Backup criado com sucesso',
            'backup_name': resultado['backup_name'],
            'file_path': resultado['file_path']
        })
    else:
        return jsonify({'error': f"Erro ao criar backup: {resultado.get('error')}"}), 500


@backup_bp.route('/backup/download/<string:backup_name>', methods=['GET'])
@requer_admin
def download_backup(backup_name):
    """Download de um backup específico."""
    zip_path = os.path.join(config.PASTA_BACKUPS, f'{backup_name}.zip')

    if not os.path.exists(zip_path):
        return jsonify({'error': 'Backup não encontrado'}), 404

    return send_file(
        zip_path,
        mimetype='application/zip',
        as_attachment=True,
        download_name=f'{backup_name}.zip'
    )


def _identificar_tipo_backup(nome):
    """Identifica o tipo de backup pelo prefixo do nome."""
    nome_lower = nome.lower()
    if nome_lower.startswith('pre_restore') or nome_lower.startswith('pre-restore'):
        return 'pre_restore', 'pre-restore'
    if nome_lower.startswith('pre_bulk') or nome_lower.startswith('pre-bulk'):
        return 'pre_bulk', 'pre-bulk-delete'
    if nome_lower.startswith('pre_import') or nome_lower.startswith('pre-import'):
        return 'pre_import', 'pre-import'
    if nome_lower.startswith('auto') or nome_lower.startswith('scheduled'):
        return 'auto', 'auto-backup'
    if nome_lower.startswith('manual') or nome_lower.startswith('man'):
        return 'manual', 'manual-backup'
    # Default: backup genérico (provavelmente manual via UI)
    if nome_lower.startswith('backup_'):
        return 'manual', 'backup'
    return 'other', nome


def _formatar_data_backup(dt):
    """Formata datetime para exibição compacta: DD/MM HH:MM."""
    return dt.strftime('%d/%m %H:%M')


@backup_bp.route('/backup/list', methods=['GET'])
@requer_admin
def listar_backups():
    """Lista todos os backups disponíveis com informação expandida."""
    backups = []

    if os.path.exists(config.PASTA_BACKUPS):
        for ficheiro in os.listdir(config.PASTA_BACKUPS):
            if ficheiro.endswith('.zip'):
                caminho = os.path.join(config.PASTA_BACKUPS, ficheiro)
                stats = os.stat(caminho)
                nome_base = ficheiro.replace('.zip', '')
                dt_criacao = datetime.fromtimestamp(stats.st_mtime)
                tipo, display_prefix = _identificar_tipo_backup(nome_base)

                # Construir display_name legível
                # Ex: backup_20260206_141500 → backup-20260206-141500
                display_name = nome_base.replace('_', '-')

                backups.append({
                    'name': nome_base,
                    'filename': ficheiro,
                    'display_name': display_name,
                    'type': tipo,
                    'created_at': dt_criacao.isoformat(),
                    'created_at_formatted': _formatar_data_backup(dt_criacao),
                    'size': stats.st_size,
                    'size_kb': round(stats.st_size / 1024),
                    'size_mb': round(stats.st_size / (1024 * 1024), 2),
                })

    # Ordenar por data (mais recente primeiro)
    backups.sort(key=lambda x: x['created_at'], reverse=True)

    return jsonify({'backups': backups})


@backup_bp.route('/backup/<string:backup_name>', methods=['DELETE'])
@requer_admin
def eliminar_backup(backup_name):
    """Elimina um backup específico."""
    zip_path = os.path.join(config.PASTA_BACKUPS, f'{backup_name}.zip')

    if not os.path.exists(zip_path):
        return jsonify({'error': 'Backup não encontrado'}), 404

    try:
        os.remove(zip_path)

        bd = obter_bd()
        registar_auditoria(bd, g.utilizador_atual['user_id'], 'BACKUP_DELETE', 'system',
                           None, None, {'backup_name': backup_name})
        bd.commit()

        return jsonify({'message': 'Backup eliminado com sucesso'})
    except Exception as e:
        return jsonify({'error': f'Erro ao eliminar backup: {str(e)}'}), 500


@backup_bp.route('/backup/restore', methods=['POST'])
@requer_admin
def restaurar_backup():
    """Restaura um backup a partir de um ficheiro ZIP enviado."""
    if 'file' not in request.files:
        return jsonify({'error': 'Nenhum ficheiro enviado'}), 400

    ficheiro = request.files['file']
    if ficheiro.filename == '':
        return jsonify({'error': 'Nome do ficheiro vazio'}), 400

    if not ficheiro.filename.endswith('.zip'):
        return jsonify({'error': 'Ficheiro deve ser um ZIP'}), 400

    try:
        # Criar backup antes de restaurar
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        backup_antes = f'pre_restore_{timestamp}'

        # Extrair para pasta temporária
        pasta_temp = os.path.join(config.PASTA_BACKUPS, f'restore_temp_{timestamp}')
        os.makedirs(pasta_temp, exist_ok=True)

        with zipfile.ZipFile(ficheiro, 'r') as zipf:
            zipf.extractall(pasta_temp)

        # Verificar se contém a base de dados
        db_path = os.path.join(pasta_temp, 'smartlamppost.db')
        if not os.path.exists(db_path):
            shutil.rmtree(pasta_temp)
            return jsonify({'error': 'Backup inválido: base de dados não encontrada'}), 400

        # Fazer backup do estado actual
        shutil.copy2(config.BASE_DADOS, os.path.join(config.PASTA_BACKUPS, f'{backup_antes}.db'))

        # Restaurar base de dados
        shutil.copy2(db_path, config.BASE_DADOS)

        # Restaurar uploads se existir
        uploads_path = os.path.join(pasta_temp, 'uploads')
        if os.path.exists(uploads_path):
            if os.path.exists(config.PASTA_UPLOADS):
                shutil.rmtree(config.PASTA_UPLOADS)
            shutil.copytree(uploads_path, config.PASTA_UPLOADS)

        # Limpar pasta temporária
        shutil.rmtree(pasta_temp)

        return jsonify({
            'success': True,
            'message': 'Backup restaurado com sucesso',
            'pre_restore_backup': backup_antes
        })

    except Exception as e:
        return jsonify({'error': f'Erro ao restaurar backup: {str(e)}'}), 500


def _limpar_backups_antigos():
    """Remove backups antigos mantendo apenas os últimos MAX_BACKUPS."""
    if not os.path.exists(config.PASTA_BACKUPS):
        return

    backups = []
    for ficheiro in os.listdir(config.PASTA_BACKUPS):
        if ficheiro.endswith('.zip'):
            caminho = os.path.join(config.PASTA_BACKUPS, ficheiro)
            backups.append((caminho, os.path.getmtime(caminho)))

    # Ordenar por data (mais antigo primeiro)
    backups.sort(key=lambda x: x[1])

    # Remover os mais antigos
    while len(backups) > config.MAX_BACKUPS:
        caminho, _ = backups.pop(0)
        try:
            os.remove(caminho)
        except OSError:
            pass
