"""
SmartLamppost - Registo de Blueprints
"""

from flask import Blueprint

# Criar blueprints
auth_bp = Blueprint('auth', __name__, url_prefix='/api/auth')
users_bp = Blueprint('users', __name__, url_prefix='/api/users')
schema_bp = Blueprint('schema', __name__, url_prefix='/api/schema')
assets_bp = Blueprint('assets', __name__, url_prefix='/api/assets')
interventions_bp = Blueprint('interventions', __name__, url_prefix='/api/interventions')
technicians_bp = Blueprint('technicians', __name__, url_prefix='/api/external-technicians')
catalog_bp = Blueprint('catalog', __name__, url_prefix='/api/catalog')
system_bp = Blueprint('system', __name__, url_prefix='/api')
export_bp = Blueprint('export', __name__, url_prefix='/api')
backup_bp = Blueprint('backup', __name__, url_prefix='/api')


def register_blueprints(app):
    """Regista todos os blueprints na aplicação."""
    from app.routes import auth, users, schema, assets, interventions
    from app.routes import technicians, catalog, system, export, backup

    app.register_blueprint(auth_bp)
    app.register_blueprint(users_bp)
    app.register_blueprint(schema_bp)
    app.register_blueprint(assets_bp)
    app.register_blueprint(interventions_bp)
    app.register_blueprint(technicians_bp)
    app.register_blueprint(catalog_bp)
    app.register_blueprint(system_bp)
    app.register_blueprint(export_bp)
    app.register_blueprint(backup_bp)
