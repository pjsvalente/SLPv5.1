"""
SmartLamppost - Rotas de Gestao do Catalogo
"""

import os
import sqlite3
from io import BytesIO
from flask import request, jsonify, g, send_file

from app.routes import catalog_bp
from app.database import obter_bd
from app.utils import requer_autenticacao, requer_admin
from app.config import get_config
from app.extensions import EXCEL_DISPONIVEL

if EXCEL_DISPONIVEL:
    from openpyxl import Workbook, load_workbook
    from openpyxl.styles import Font, PatternFill, Alignment

config = get_config()


# =============================================================================
# ESTATISTICAS DO CATALOGO
# =============================================================================

@catalog_bp.route('/stats', methods=['GET'])
@requer_autenticacao
def obter_stats_catalogo():
    """Devolve estatisticas do catalogo."""
    bd = obter_bd()
    return jsonify({
        'columns': bd.execute('SELECT COUNT(*) FROM catalog_columns').fetchone()[0],
        'luminaires': bd.execute('SELECT COUNT(*) FROM catalog_luminaires').fetchone()[0],
        'electrical': bd.execute('SELECT COUNT(*) FROM catalog_electrical_panels').fetchone()[0],
        'fuse_boxes': bd.execute('SELECT COUNT(*) FROM catalog_fuse_boxes').fetchone()[0],
        'telemetry': bd.execute('SELECT COUNT(*) FROM catalog_telemetry_panels').fetchone()[0],
        'ev': bd.execute('SELECT COUNT(*) FROM catalog_module_ev').fetchone()[0],
        'mupi': bd.execute('SELECT COUNT(*) FROM catalog_module_mupi').fetchone()[0],
        'lateral': bd.execute('SELECT COUNT(*) FROM catalog_module_lateral').fetchone()[0],
        'antenna': bd.execute('SELECT COUNT(*) FROM catalog_module_antenna').fetchone()[0]
    })


# =============================================================================
# MODULOS COMPATIVEIS COM UMA COLUNA
# =============================================================================

@catalog_bp.route('/compatible-modules/<int:column_id>', methods=['GET'])
@requer_autenticacao
def obter_modulos_compativeis(column_id):
    """
    Devolve os modulos compativeis com uma coluna especifica.
    Filtra baseado nos campos mod1-mod8 da coluna e altura quando aplicavel.
    """
    bd = obter_bd()

    # Obter dados da coluna
    coluna = bd.execute('SELECT * FROM catalog_columns WHERE id = ?', (column_id,)).fetchone()
    if not coluna:
        return jsonify({'error': 'Coluna nao encontrada'}), 404

    altura = coluna['height_m']
    resultado = {
        'column': dict(coluna),
        'modules': {}
    }

    # =========================================================================
    # Mod. 1 - Luminarias
    # Valores possiveis: "Tipo 1", "Tipo 2", "Nao"
    # Filtrar por tipo e altura da coluna
    # =========================================================================
    mod1_valor = coluna['mod1_luminaire'] or 'Nao'
    if mod1_valor.lower() != 'nao' and mod1_valor.lower() != 'não':
        query = 'SELECT * FROM catalog_luminaires WHERE 1=1'
        params = []

        # Filtrar por tipo
        if 'tipo 1' in mod1_valor.lower():
            query += ' AND type_1 = 1'
        elif 'tipo 2' in mod1_valor.lower():
            query += ' AND type_2 = 1'

        # Filtrar por altura da coluna
        if altura:
            query += ' AND column_height_m = ?'
            params.append(altura)

        query += ' ORDER BY luminaire_type, reference'
        luminarias = bd.execute(query, params).fetchall()
        resultado['modules']['luminaires'] = {
            'available': True,
            'filter_type': mod1_valor,
            'items': [dict(l) for l in luminarias]
        }
    else:
        resultado['modules']['luminaires'] = {'available': False, 'filter_type': mod1_valor, 'items': []}

    # =========================================================================
    # Mod. 2 - Quadros Eletricos
    # Valores possiveis: "Sim", "Nao"
    # =========================================================================
    mod2_valor = coluna['mod2_electrical'] or 'Nao'
    if mod2_valor.lower() in ('sim', 'yes', '1'):
        quadros = bd.execute('SELECT * FROM catalog_electrical_panels ORDER BY panel_type, reference').fetchall()
        resultado['modules']['electrical'] = {
            'available': True,
            'filter_type': mod2_valor,
            'items': [dict(q) for q in quadros]
        }
    else:
        resultado['modules']['electrical'] = {'available': False, 'filter_type': mod2_valor, 'items': []}

    # =========================================================================
    # Mod. 3 - Cofretes Fusivel
    # Valores possiveis: "Tipo S", "Tipo D", "Nao"
    # =========================================================================
    mod3_valor = coluna['mod3_fuse_box'] or 'Nao'
    if mod3_valor.lower() != 'nao' and mod3_valor.lower() != 'não':
        query = 'SELECT * FROM catalog_fuse_boxes WHERE 1=1'

        if 'tipo s' in mod3_valor.lower() or 's' == mod3_valor.lower():
            query += ' AND type_s = 1'
        elif 'tipo d' in mod3_valor.lower() or 'd' == mod3_valor.lower():
            query += ' AND type_d = 1'

        query += ' ORDER BY fuse_type, reference'
        cofretes = bd.execute(query).fetchall()
        resultado['modules']['fuse_boxes'] = {
            'available': True,
            'filter_type': mod3_valor,
            'items': [dict(c) for c in cofretes]
        }
    else:
        resultado['modules']['fuse_boxes'] = {'available': False, 'filter_type': mod3_valor, 'items': []}

    # =========================================================================
    # Mod. 4 - Quadros Telemetria
    # Valores possiveis: "Sim", "Nao"
    # =========================================================================
    mod4_valor = coluna['mod4_telemetry'] or 'Nao'
    if mod4_valor.lower() in ('sim', 'yes', '1'):
        quadros = bd.execute('SELECT * FROM catalog_telemetry_panels ORDER BY panel_type, reference').fetchall()
        resultado['modules']['telemetry'] = {
            'available': True,
            'filter_type': mod4_valor,
            'items': [dict(q) for q in quadros]
        }
    else:
        resultado['modules']['telemetry'] = {'available': False, 'filter_type': mod4_valor, 'items': []}

    # =========================================================================
    # Mod. 5 - CVE (Carregador Veiculo Eletrico)
    # Valores possiveis: "Sim", "Nao"
    # =========================================================================
    mod5_valor = coluna['mod5_ev'] or 'Nao'
    if mod5_valor.lower() in ('sim', 'yes', '1'):
        modulos = bd.execute('SELECT * FROM catalog_module_ev ORDER BY module_type, reference').fetchall()
        resultado['modules']['ev'] = {
            'available': True,
            'filter_type': mod5_valor,
            'items': [dict(m) for m in modulos]
        }
    else:
        resultado['modules']['ev'] = {'available': False, 'filter_type': mod5_valor, 'items': []}

    # =========================================================================
    # Mod. 6 - MUPI
    # Valores possiveis: "Sim", "Nao"
    # =========================================================================
    mod6_valor = coluna['mod6_mupi'] or 'Nao'
    if mod6_valor.lower() in ('sim', 'yes', '1'):
        modulos = bd.execute('SELECT * FROM catalog_module_mupi ORDER BY module_type, reference').fetchall()
        resultado['modules']['mupi'] = {
            'available': True,
            'filter_type': mod6_valor,
            'items': [dict(m) for m in modulos]
        }
    else:
        resultado['modules']['mupi'] = {'available': False, 'filter_type': mod6_valor, 'items': []}

    # =========================================================================
    # Mod. 7 - Lateral
    # Valores possiveis: "Sim", "Nao" (normalmente sempre Sim)
    # =========================================================================
    mod7_valor = coluna['mod7_lateral'] or 'Sim'
    if mod7_valor.lower() in ('sim', 'yes', '1'):
        modulos = bd.execute('SELECT * FROM catalog_module_lateral ORDER BY module_type, reference').fetchall()
        resultado['modules']['lateral'] = {
            'available': True,
            'filter_type': mod7_valor,
            'items': [dict(m) for m in modulos]
        }
    else:
        resultado['modules']['lateral'] = {'available': False, 'filter_type': mod7_valor, 'items': []}

    # =========================================================================
    # Mod. 8 - Capsula Antena
    # Valores possiveis: "Sim", "Nao" (normalmente sempre Sim)
    # Filtrar por altura da coluna
    # =========================================================================
    mod8_valor = coluna['mod8_antenna'] or 'Sim'
    if mod8_valor.lower() in ('sim', 'yes', '1'):
        if altura:
            modulos = bd.execute(
                'SELECT * FROM catalog_module_antenna WHERE column_height_m = ? ORDER BY reference',
                (altura,)
            ).fetchall()
        else:
            modulos = bd.execute('SELECT * FROM catalog_module_antenna ORDER BY column_height_m, reference').fetchall()

        resultado['modules']['antenna'] = {
            'available': True,
            'filter_type': mod8_valor,
            'items': [dict(m) for m in modulos]
        }
    else:
        resultado['modules']['antenna'] = {'available': False, 'filter_type': mod8_valor, 'items': []}

    return jsonify(resultado)


@catalog_bp.route('/compatible-modules-by-ref/<reference>', methods=['GET'])
@requer_autenticacao
def obter_modulos_compativeis_por_ref(reference):
    """
    Devolve os modulos compativeis com uma coluna especificada pela referencia.
    """
    bd = obter_bd()
    coluna = bd.execute('SELECT id FROM catalog_columns WHERE reference = ?', (reference,)).fetchone()
    if not coluna:
        return jsonify({'error': 'Coluna nao encontrada'}), 404

    # Redirecionar para o endpoint por ID
    return obter_modulos_compativeis(coluna['id'])


# =============================================================================
# CALCULO DE POTENCIAS
# =============================================================================

@catalog_bp.route('/calculate-power', methods=['POST'])
@requer_autenticacao
def calcular_potencia():
    """
    Calcula o balanço de potências para uma configuração de módulos.

    Body JSON:
        {
            "electrical_panel_id": int (opcional),
            "fuse_box_id": int (opcional),
            "modules": {
                "luminaire_1_id": int,
                "luminaire_2_id": int,
                "telemetry_id": int,
                "ev_id": int,
                "mupi_id": int
            }
        }

    Returns:
        {
            "max_power": int (potência máxima do Q.E. ou Cofrete),
            "max_power_source": str ("Q. Elétrico" ou "Cofrete"),
            "connection_type": str ("Monofásica" ou "Trifásica"),
            "modules_power": [
                {"name": "Luminária 1", "power": 70, "connection": "Monofásica"},
                ...
            ],
            "total_installed": int (soma das potências dos módulos),
            "remaining": int (max - total),
            "warning": bool (true se total > max),
            "over_capacity": bool (true se total > max * 1.0)
        }
    """
    bd = obter_bd()
    dados = request.json or {}

    max_power = 0
    max_power_source = None
    connection_type = None
    modules_power = []

    # Obter potência máxima do Q. Elétrico
    if dados.get('electrical_panel_id'):
        qe = bd.execute(
            'SELECT * FROM catalog_electrical_panels WHERE id = ?',
            (dados['electrical_panel_id'],)
        ).fetchone()
        if qe:
            max_power = qe['max_power_total'] or 0
            max_power_source = 'Q. Elétrico'
            connection_type = qe['connection_type']

    # Se não há Q.E., verificar Cofrete
    if not max_power and dados.get('fuse_box_id'):
        cf = bd.execute(
            'SELECT * FROM catalog_fuse_boxes WHERE id = ?',
            (dados['fuse_box_id'],)
        ).fetchone()
        if cf:
            max_power = cf['max_power_total'] or 0
            max_power_source = 'Cofrete'
            connection_type = cf['connection_type']

    # Calcular potências dos módulos selecionados
    modules = dados.get('modules', {})

    # Luminária 1
    if modules.get('luminaire_1_id'):
        lum = bd.execute('SELECT * FROM catalog_luminaires WHERE id = ?', (modules['luminaire_1_id'],)).fetchone()
        if lum and lum['power_watts']:
            modules_power.append({
                'name': 'Luminária 1',
                'reference': lum['reference'],
                'power': lum['power_watts'],
                'connection': lum['connection_type']
            })

    # Luminária 2
    if modules.get('luminaire_2_id'):
        lum = bd.execute('SELECT * FROM catalog_luminaires WHERE id = ?', (modules['luminaire_2_id'],)).fetchone()
        if lum and lum['power_watts']:
            modules_power.append({
                'name': 'Luminária 2',
                'reference': lum['reference'],
                'power': lum['power_watts'],
                'connection': lum['connection_type']
            })

    # Telemetria
    if modules.get('telemetry_id'):
        tel = bd.execute('SELECT * FROM catalog_telemetry_panels WHERE id = ?', (modules['telemetry_id'],)).fetchone()
        if tel and tel['power_watts']:
            modules_power.append({
                'name': 'Telemetria',
                'reference': tel['reference'],
                'power': tel['power_watts'],
                'connection': tel['connection_type']
            })

    # Carregador EV
    if modules.get('ev_id'):
        ev = bd.execute('SELECT * FROM catalog_module_ev WHERE id = ?', (modules['ev_id'],)).fetchone()
        if ev and ev['power_watts']:
            modules_power.append({
                'name': 'Carregador EV',
                'reference': ev['reference'],
                'power': ev['power_watts'],
                'connection': ev['connection_type']
            })

    # MUPI
    if modules.get('mupi_id'):
        mupi = bd.execute('SELECT * FROM catalog_module_mupi WHERE id = ?', (modules['mupi_id'],)).fetchone()
        if mupi and mupi['power_watts']:
            modules_power.append({
                'name': 'MUPI',
                'reference': mupi['reference'],
                'power': mupi['power_watts'],
                'connection': mupi['connection_type']
            })

    # Calcular totais
    total_installed = sum(m['power'] for m in modules_power)
    remaining = max_power - total_installed if max_power else None

    return jsonify({
        'max_power': max_power,
        'max_power_source': max_power_source,
        'connection_type': connection_type,
        'modules_power': modules_power,
        'total_installed': total_installed,
        'remaining': remaining,
        'warning': remaining is not None and remaining < 0,
        'over_capacity': remaining is not None and remaining < 0
    })


# =============================================================================
# LISTAGEM DE ITENS DO CATALOGO
# =============================================================================

@catalog_bp.route('/columns', methods=['GET'])
@requer_autenticacao
def listar_colunas_catalogo():
    """Lista todas as colunas do catalogo com filtros."""
    bd = obter_bd()

    pack = request.args.get('pack')
    height = request.args.get('height')
    fixing = request.args.get('fixing')

    query = 'SELECT * FROM catalog_columns WHERE 1=1'
    params = []

    if pack:
        query += ' AND pack = ?'
        params.append(pack)

    if height:
        query += ' AND height_m = ?'
        params.append(int(height))

    if fixing:
        query += ' AND fixing = ?'
        params.append(fixing)

    query += ' ORDER BY pack, height_m, reference'
    colunas = bd.execute(query, params).fetchall()

    return jsonify([dict(c) for c in colunas])


@catalog_bp.route('/packs', methods=['GET'])
@requer_autenticacao
def listar_packs():
    """Lista os packs disponiveis."""
    bd = obter_bd()
    packs = bd.execute('SELECT DISTINCT pack FROM catalog_columns ORDER BY pack').fetchall()
    return jsonify([p['pack'] for p in packs])


@catalog_bp.route('/luminaires', methods=['GET'])
@requer_autenticacao
def listar_luminarias():
    """Lista luminarias, opcionalmente filtradas por altura e tipo."""
    bd = obter_bd()
    height = request.args.get('height', type=int)
    lum_type = request.args.get('type')

    query = 'SELECT * FROM catalog_luminaires WHERE 1=1'
    params = []

    if height:
        query += ' AND column_height_m = ?'
        params.append(height)

    if lum_type:
        if lum_type == 'Tipo 1':
            query += ' AND type_1 = 1'
        elif lum_type == 'Tipo 2':
            query += ' AND type_2 = 1'

    query += ' ORDER BY luminaire_type, reference'
    luminarias = bd.execute(query, params).fetchall()

    return jsonify([dict(l) for l in luminarias])


@catalog_bp.route('/electrical-panels', methods=['GET'])
@requer_autenticacao
def listar_quadros_eletricos():
    """Lista todos os quadros eletricos do catalogo."""
    bd = obter_bd()
    quadros = bd.execute('SELECT * FROM catalog_electrical_panels ORDER BY panel_type, reference').fetchall()
    return jsonify([dict(q) for q in quadros])


@catalog_bp.route('/fuse-boxes', methods=['GET'])
@requer_autenticacao
def listar_cofretes():
    """Lista todos os cofretes fusivel do catalogo."""
    bd = obter_bd()
    cofretes = bd.execute('SELECT * FROM catalog_fuse_boxes ORDER BY fuse_type, reference').fetchall()
    return jsonify([dict(c) for c in cofretes])


@catalog_bp.route('/telemetry-panels', methods=['GET'])
@requer_autenticacao
def listar_quadros_telemetria():
    """Lista todos os quadros de telemetria do catalogo."""
    bd = obter_bd()
    quadros = bd.execute('SELECT * FROM catalog_telemetry_panels ORDER BY panel_type, reference').fetchall()
    return jsonify([dict(q) for q in quadros])


# URLs com /modules/ para compatibilidade com frontend
@catalog_bp.route('/modules/ev', methods=['GET'])
@requer_autenticacao
def listar_modulos_ev():
    """Lista todos os modulos EV do catalogo."""
    bd = obter_bd()
    modulos = bd.execute('SELECT * FROM catalog_module_ev ORDER BY module_type, reference').fetchall()
    return jsonify([dict(m) for m in modulos])


@catalog_bp.route('/modules/mupi', methods=['GET'])
@requer_autenticacao
def listar_modulos_mupi():
    """Lista todos os modulos MUPI do catalogo."""
    bd = obter_bd()
    modulos = bd.execute('SELECT * FROM catalog_module_mupi ORDER BY module_type, reference').fetchall()
    return jsonify([dict(m) for m in modulos])


@catalog_bp.route('/modules/lateral', methods=['GET'])
@requer_autenticacao
def listar_modulos_laterais():
    """Lista todos os modulos laterais do catalogo."""
    bd = obter_bd()
    modulos = bd.execute('SELECT * FROM catalog_module_lateral ORDER BY module_type, reference').fetchall()
    return jsonify([dict(m) for m in modulos])


@catalog_bp.route('/modules/antenna', methods=['GET'])
@requer_autenticacao
def listar_modulos_antena():
    """Lista todos os modulos antena do catalogo."""
    bd = obter_bd()
    height = request.args.get('height', type=int)

    if height:
        modulos = bd.execute('''
            SELECT * FROM catalog_module_antenna WHERE column_height_m = ? ORDER BY reference
        ''', (height,)).fetchall()
    else:
        modulos = bd.execute('SELECT * FROM catalog_module_antenna ORDER BY column_height_m, reference').fetchall()

    return jsonify([dict(m) for m in modulos])


# =============================================================================
# GESTAO DE ITENS DO CATALOGO
# =============================================================================

@catalog_bp.route('/item/<tab>', methods=['POST'])
@requer_admin
def adicionar_item_catalogo(tab):
    """Adiciona um item ao catalogo."""
    dados = request.json
    bd = obter_bd()

    try:
        if tab == 'columns':
            bd.execute('''INSERT INTO catalog_columns
                (description, reference, pack, column_type, fixing, height_m, arm_count, arm_street, arm_sidewalk,
                 luminaire_included, mod1_luminaire, mod2_electrical, mod3_fuse_box, mod4_telemetry,
                 mod5_ev, mod6_mupi, mod7_lateral, mod8_antenna)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                (dados.get('description', ''), dados.get('reference', ''), dados.get('pack', 'BAREBONE'),
                 dados.get('column_type', 'Standard'), dados.get('fixing', 'Flange'),
                 dados.get('height_m', 0), dados.get('arm_count', 0), dados.get('arm_street', 0), dados.get('arm_sidewalk', 0),
                 dados.get('luminaire_included', 'Nao'), dados.get('mod1_luminaire', 'Nao'), dados.get('mod2_electrical', 'Nao'),
                 dados.get('mod3_fuse_box', 'Nao'), dados.get('mod4_telemetry', 'Nao'), dados.get('mod5_ev', 'Nao'),
                 dados.get('mod6_mupi', 'Nao'), dados.get('mod7_lateral', 'Sim'), dados.get('mod8_antenna', 'Sim')))

        elif tab == 'luminaires':
            ref = dados.get('reference', '')
            bd.execute('''INSERT INTO catalog_luminaires
                (luminaire_type, description, reference, manufacturer_ref, column_height_m, type_1, type_2)
                VALUES (?, ?, ?, ?, ?, ?, ?)''',
                (dados.get('luminaire_type', ''), dados.get('description', ''), ref,
                 dados.get('manufacturer_ref', ''), dados.get('column_height_m'),
                 1 if dados.get('type_1') else 0, 1 if dados.get('type_2') else 0))

        elif tab == 'electrical':
            ref = dados.get('reference', '')
            short = dados.get('short_reference') or ref.replace('SLP-', '')
            bd.execute('''INSERT INTO catalog_electrical_panels (panel_type, description, reference, short_reference)
                VALUES (?, ?, ?, ?)''', (dados.get('panel_type', ''), dados.get('description', ''), ref, short))

        elif tab == 'fuse_boxes':
            ref = dados.get('reference', '')
            short = dados.get('short_reference') or ref.replace('SLP-', '')
            bd.execute('''INSERT INTO catalog_fuse_boxes (fuse_type, description, reference, short_reference, type_s, type_d)
                VALUES (?, ?, ?, ?, ?, ?)''',
                (dados.get('fuse_type', ''), dados.get('description', ''), ref, short,
                 1 if dados.get('type_s') else 0, 1 if dados.get('type_d') else 0))

        elif tab == 'telemetry':
            ref = dados.get('reference', '')
            short = dados.get('short_reference') or ref.replace('SLP-', '')
            bd.execute('''INSERT INTO catalog_telemetry_panels (panel_type, description, reference, short_reference)
                VALUES (?, ?, ?, ?)''', (dados.get('panel_type', ''), dados.get('description', ''), ref, short))

        elif tab == 'ev':
            ref = dados.get('reference', '')
            short = dados.get('short_reference') or ref.replace('SLPS-', '').replace('SLP-', '')
            bd.execute('''INSERT INTO catalog_module_ev (module_type, description, reference, short_reference)
                VALUES (?, ?, ?, ?)''', (dados.get('module_type', ''), dados.get('description', ''), ref, short))

        elif tab == 'mupi':
            ref = dados.get('reference', '')
            short = dados.get('short_reference') or ref.replace('SLPS-', '').replace('SLP-', '')
            bd.execute('''INSERT INTO catalog_module_mupi (module_type, description, reference, short_reference)
                VALUES (?, ?, ?, ?)''', (dados.get('module_type', ''), dados.get('description', ''), ref, short))

        elif tab == 'lateral':
            ref = dados.get('reference', '')
            short = dados.get('short_reference') or ref.replace('SLP-', '')
            bd.execute('''INSERT INTO catalog_module_lateral (module_type, description, reference, short_reference)
                VALUES (?, ?, ?, ?)''', (dados.get('module_type', ''), dados.get('description', ''), ref, short))

        elif tab == 'antenna':
            ref = dados.get('reference', '')
            short = dados.get('short_reference') or ref.replace('SLPC-', '').replace('SLP-', '')
            bd.execute('''INSERT INTO catalog_module_antenna (module_type, description, reference, short_reference, column_height_m)
                VALUES (?, ?, ?, ?, ?)''',
                (dados.get('module_type', ''), dados.get('description', ''), ref, short, dados.get('column_height_m')))

        else:
            return jsonify({'error': f'Tab desconhecida: {tab}'}), 400

        bd.commit()
        return jsonify({'success': True, 'message': 'Item adicionado com sucesso'})

    except sqlite3.IntegrityError as e:
        return jsonify({'error': f'Referencia ja existe: {str(e)}'}), 400
    except Exception as e:
        return jsonify({'error': f'Erro ao adicionar: {str(e)}'}), 500


@catalog_bp.route('/item/<tab>/<int:item_id>', methods=['DELETE'])
@requer_admin
def remover_item_catalogo(tab, item_id):
    """Remove um item do catalogo."""
    bd = obter_bd()

    tables = {
        'columns': 'catalog_columns',
        'luminaires': 'catalog_luminaires',
        'electrical': 'catalog_electrical_panels',
        'fuse_boxes': 'catalog_fuse_boxes',
        'telemetry': 'catalog_telemetry_panels',
        'ev': 'catalog_module_ev',
        'mupi': 'catalog_module_mupi',
        'lateral': 'catalog_module_lateral',
        'antenna': 'catalog_module_antenna'
    }

    if tab not in tables:
        return jsonify({'error': f'Tab desconhecida: {tab}'}), 400

    try:
        bd.execute(f'DELETE FROM {tables[tab]} WHERE id = ?', (item_id,))
        bd.commit()
        return jsonify({'success': True, 'message': 'Item removido com sucesso'})
    except Exception as e:
        return jsonify({'error': f'Erro ao remover: {str(e)}'}), 500


# =============================================================================
# LIMPAR E RESETAR CATALOGO
# =============================================================================

@catalog_bp.route('/clear', methods=['DELETE'])
@requer_admin
def limpar_catalogo():
    """Limpa todo o catalogo."""
    try:
        bd = obter_bd()
        bd.execute('DELETE FROM catalog_columns')
        bd.execute('DELETE FROM catalog_luminaires')
        bd.execute('DELETE FROM catalog_electrical_panels')
        bd.execute('DELETE FROM catalog_fuse_boxes')
        bd.execute('DELETE FROM catalog_telemetry_panels')
        bd.execute('DELETE FROM catalog_module_ev')
        bd.execute('DELETE FROM catalog_module_mupi')
        bd.execute('DELETE FROM catalog_module_lateral')
        bd.execute('DELETE FROM catalog_module_antenna')
        bd.commit()
        return jsonify({'success': True, 'message': 'Catalogo limpo com sucesso'})
    except Exception as e:
        return jsonify({'error': f'Erro ao limpar: {str(e)}'}), 500


@catalog_bp.route('/reset', methods=['POST'])
@requer_admin
def resetar_catalogo():
    """Limpa todo o catalogo (alias para clear)."""
    return limpar_catalogo()


# =============================================================================
# CARREGAR CATALOGO PADRAO
# =============================================================================

@catalog_bp.route('/load-default', methods=['POST'])
@requer_admin
def carregar_catalogo_padrao():
    """Carrega dados padrao do catalogo."""
    try:
        bd = obter_bd()
        stats = {'columns': 0, 'luminaires': 0, 'electrical': 0, 'fuse_boxes': 0,
                 'telemetry': 0, 'ev': 0, 'mupi': 0, 'lateral': 0, 'antenna': 0}

        # Limpar tabelas existentes
        bd.execute('DELETE FROM catalog_columns')
        bd.execute('DELETE FROM catalog_luminaires')
        bd.execute('DELETE FROM catalog_electrical_panels')
        bd.execute('DELETE FROM catalog_fuse_boxes')
        bd.execute('DELETE FROM catalog_telemetry_panels')
        bd.execute('DELETE FROM catalog_module_ev')
        bd.execute('DELETE FROM catalog_module_mupi')
        bd.execute('DELETE FROM catalog_module_lateral')
        bd.execute('DELETE FROM catalog_module_antenna')

        # LUMINARIAS (Mod. 1)
        luminaires_data = [
            ('Luminaria Braco', 'Luminaria para colunas de 3 metros', 'LUSA-16-700', 'L75B44261030005', 3, 1, 0),
            ('Luminaria Braco', 'Luminaria para colunas de 4 metros', 'LUSA-16-700', 'L75B44261030005', 4, 1, 0),
            ('Luminaria Braco', 'Luminaria para colunas de 6 metros', 'LUSA-24-700', 'L75B44261430005', 6, 1, 0),
            ('Luminaria Braco', 'Luminaria para colunas de 8 metros', 'LUSA-32-700', 'L75B44262030005', 8, 1, 0),
            ('Luminaria Braco', 'Luminaria para colunas de 10 metros', 'LUSA-36-700', 'L76B44262630005', 10, 1, 0),
            ('Luminaria Topo', 'Luminaria 360 para colunas de 4m sem braco', 'APE360', 'LNX114111230000', 4, 0, 1),
        ]
        for ltype, desc, ref, mref, height, t1, t2 in luminaires_data:
            bd.execute('''INSERT INTO catalog_luminaires
                (luminaire_type, description, reference, manufacturer_ref, column_height_m, type_1, type_2)
                VALUES (?, ?, ?, ?, ?, ?, ?)''', (ltype, desc, ref, mref, height, t1, t2))
        stats['luminaires'] = len(luminaires_data)

        # QUADROS ELETRICOS (Mod. 2)
        electrical_data = [
            ('Q.E. Monofasico', 'Quadro eletrico SLP MONO PLAIN PACK 1', 'SLP-1LPL-10000-040A'),
            ('Q.E. Monofasico', 'Quadro eletrico SLP MONO BASIC PACK 1', 'SLP-1LBA-01000-040A'),
            ('Q.E. Monofasico', 'Quadro eletrico SLP MONO BASIC PACK 2', 'SLP-1LBA-02000-040A'),
            ('Q.E. Trifasico', 'Quadro eletrico SLP TRI PLAIN PACK 1', 'SLP-3LPL-10000-063A'),
            ('Q.E. Trifasico', 'Quadro eletrico SLP TRI BASIC PACK 1', 'SLP-3LBA-01000-063A'),
            ('Q.E. Trifasico', 'Quadro eletrico SLP TRI BASIC PACK 2', 'SLP-3LBA-02000-063A'),
        ]
        for ptype, desc, ref in electrical_data:
            short = ref.replace('SLP-', '')
            bd.execute('''INSERT INTO catalog_electrical_panels
                (panel_type, description, reference, short_reference) VALUES (?, ?, ?, ?)''',
                (ptype, desc, ref, short))
        stats['electrical'] = len(electrical_data)

        # COFRETES FUSIVEL (Mod. 3)
        fuse_data = [
            ('Cofrete Simples', 'Cofrete fusivel tipo S', 'SLP-CF-S', 'CF-S', 1, 0),
            ('Cofrete Duplo', 'Cofrete fusivel tipo D', 'SLP-CF-D', 'CF-D', 0, 1),
        ]
        for ftype, desc, ref, short, ts, td in fuse_data:
            bd.execute('''INSERT INTO catalog_fuse_boxes
                (fuse_type, description, reference, short_reference, type_s, type_d) VALUES (?, ?, ?, ?, ?, ?)''',
                (ftype, desc, ref, short, ts, td))
        stats['fuse_boxes'] = len(fuse_data)

        # TELEMETRIA (Mod. 4)
        telemetry_data = [
            ('Telemetria Standard', 'Modulo de telemetria standard', 'SLP-TEL-STD', 'TEL-STD'),
            ('Telemetria Advanced', 'Modulo de telemetria avancado', 'SLP-TEL-ADV', 'TEL-ADV'),
        ]
        for ptype, desc, ref, short in telemetry_data:
            bd.execute('''INSERT INTO catalog_telemetry_panels
                (panel_type, description, reference, short_reference) VALUES (?, ?, ?, ?)''',
                (ptype, desc, ref, short))
        stats['telemetry'] = len(telemetry_data)

        # MODULOS EV (Mod. 5)
        ev_data = [
            ('EV 3.7kW', 'Carregador EV 3.7kW Monofasico', 'SLPS-EV-3.7M', 'EV-3.7M'),
            ('EV 7.4kW', 'Carregador EV 7.4kW Monofasico', 'SLPS-EV-7.4M', 'EV-7.4M'),
            ('EV 11kW', 'Carregador EV 11kW Trifasico', 'SLPS-EV-11T', 'EV-11T'),
            ('EV 22kW', 'Carregador EV 22kW Trifasico', 'SLPS-EV-22T', 'EV-22T'),
        ]
        for mtype, desc, ref, short in ev_data:
            bd.execute('''INSERT INTO catalog_module_ev
                (module_type, description, reference, short_reference) VALUES (?, ?, ?, ?)''',
                (mtype, desc, ref, short))
        stats['ev'] = len(ev_data)

        # MODULOS MUPI (Mod. 6)
        mupi_data = [
            ('MUPI Standard', 'Painel MUPI standard', 'SLPS-MUPI-STD', 'MUPI-STD'),
            ('MUPI Digital', 'Painel MUPI digital', 'SLPS-MUPI-DIG', 'MUPI-DIG'),
        ]
        for mtype, desc, ref, short in mupi_data:
            bd.execute('''INSERT INTO catalog_module_mupi
                (module_type, description, reference, short_reference) VALUES (?, ?, ?, ?)''',
                (mtype, desc, ref, short))
        stats['mupi'] = len(mupi_data)

        # MODULOS LATERAL (Mod. 7)
        lateral_data = [
            ('Lateral Standard', 'Modulo lateral standard', 'SLP-LAT-STD', 'LAT-STD'),
        ]
        for mtype, desc, ref, short in lateral_data:
            bd.execute('''INSERT INTO catalog_module_lateral
                (module_type, description, reference, short_reference) VALUES (?, ?, ?, ?)''',
                (mtype, desc, ref, short))
        stats['lateral'] = len(lateral_data)

        # MODULOS ANTENA (Mod. 8)
        antenna_data = [
            ('Antena 3m', 'Modulo antena para 3m', 'SLPC-ANT-3M', 'ANT-3M', 3),
            ('Antena 4m', 'Modulo antena para 4m', 'SLPC-ANT-4M', 'ANT-4M', 4),
            ('Antena 6m', 'Modulo antena para 6m', 'SLPC-ANT-6M', 'ANT-6M', 6),
            ('Antena 8m', 'Modulo antena para 8m', 'SLPC-ANT-8M', 'ANT-8M', 8),
            ('Antena 10m', 'Modulo antena para 10m', 'SLPC-ANT-10M', 'ANT-10M', 10),
        ]
        for mtype, desc, ref, short, height in antenna_data:
            bd.execute('''INSERT INTO catalog_module_antenna
                (module_type, description, reference, short_reference, column_height_m) VALUES (?, ?, ?, ?, ?)''',
                (mtype, desc, ref, short, height))
        stats['antenna'] = len(antenna_data)

        # COLUNAS - Gerar combinacoes basicas
        packs = ['BAREBONE', 'BASIC', 'ESSENCIAL', 'PREMIUM']
        heights = [3, 4, 6, 8, 10]
        fixings = [('Flange', 'F'), ('Chumbadouro', 'C')]

        for pack in packs:
            for height in heights:
                for fixing_name, fixing_code in fixings:
                    ref = f"SLP-{pack[0]}{fixing_code}{height:02d}-00S"
                    desc = f"Coluna {pack} {height}m {fixing_name}"
                    bd.execute('''INSERT OR REPLACE INTO catalog_columns
                        (description, reference, pack, column_type, fixing, height_m,
                         arm_count, arm_street, arm_sidewalk, luminaire_included,
                         mod1_luminaire, mod2_electrical, mod3_fuse_box, mod4_telemetry,
                         mod5_ev, mod6_mupi, mod7_lateral, mod8_antenna)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                        (desc, ref, pack, 'Standard', fixing_name, height,
                         0, 0, 0, 'Nao', 'Nao', 'Nao', 'Nao', 'Nao', 'Nao', 'Nao', 'Sim', 'Sim'))
                    stats['columns'] += 1

        bd.commit()

        return jsonify({
            'success': True,
            'message': 'Catalogo padrao carregado com sucesso',
            'stats': stats
        })

    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'error': f'Erro ao carregar catalogo: {str(e)}'}), 500


# =============================================================================
# IMPORTACAO E EXPORTACAO
# =============================================================================

@catalog_bp.route('/import', methods=['POST'])
@requer_admin
def importar_catalogo():
    """Importa catalogo a partir de ficheiro Excel com todas as folhas."""
    if not EXCEL_DISPONIVEL:
        return jsonify({'error': 'Funcionalidade Excel nao disponivel'}), 500

    if 'file' not in request.files:
        return jsonify({'error': 'Nenhum ficheiro enviado'}), 400

    ficheiro = request.files['file']
    if ficheiro.filename == '':
        return jsonify({'error': 'Nome do ficheiro vazio'}), 400

    replace_all = request.args.get('replace', 'true').lower() == 'true'

    try:
        wb = load_workbook(ficheiro)
        bd = obter_bd()

        stats = {'columns': 0, 'luminaires': 0, 'electrical': 0, 'fuse_boxes': 0,
                 'telemetry': 0, 'ev': 0, 'mupi': 0, 'lateral': 0, 'antenna': 0}
        errors = []

        if replace_all:
            bd.execute('DELETE FROM catalog_columns')
            bd.execute('DELETE FROM catalog_luminaires')
            bd.execute('DELETE FROM catalog_electrical_panels')
            bd.execute('DELETE FROM catalog_fuse_boxes')
            bd.execute('DELETE FROM catalog_telemetry_panels')
            bd.execute('DELETE FROM catalog_module_ev')
            bd.execute('DELETE FROM catalog_module_mupi')
            bd.execute('DELETE FROM catalog_module_lateral')
            bd.execute('DELETE FROM catalog_module_antenna')

        def get_val(val, default=''):
            """Extrai valor da celula, retornando default se vazio."""
            if val is None:
                return default
            return str(val).strip() if val else default

        def get_int(val, default=0):
            """Extrai valor inteiro da celula."""
            if val is None:
                return default
            try:
                return int(val)
            except (ValueError, TypeError):
                return default

        def get_float(val, default=None):
            """Extrai valor float da celula."""
            if val is None:
                return default
            try:
                return float(val)
            except (ValueError, TypeError):
                return default

        def is_sim(val):
            """Verifica se o valor representa 'Sim'."""
            if val is None:
                return 0
            return 1 if str(val).strip().lower() in ('sim', 'yes', '1', 'true') else 0

        # Mapeamento de nomes de folhas
        folhas = {
            'coluna': None,
            'luminaria': None,
            'eletrico': None,
            'cofrete': None,
            'telemetria': None,
            'cve': None,
            'mupi': None,
            'lateral': None,
            'antena': None
        }

        # Identificar folhas pelo nome (case-insensitive)
        # Prioriza prefixo "mod. X" que eh mais fiavel
        for sheet_name in wb.sheetnames:
            nome_lower = sheet_name.lower()
            # Folha principal de colunas (sem prefixo mod.)
            if 'coluna' in nome_lower and 'mod' not in nome_lower:
                folhas['coluna'] = sheet_name
            # Mod. 1 - Luminaria
            elif 'mod. 1' in nome_lower:
                folhas['luminaria'] = sheet_name
            # Mod. 2 - Quadro Eletrico (nota: o Excel tem "Quando" em vez de "Quadro")
            elif 'mod. 2' in nome_lower:
                folhas['eletrico'] = sheet_name
            # Mod. 3 - Cofrete Fusivel
            elif 'mod. 3' in nome_lower:
                folhas['cofrete'] = sheet_name
            # Mod. 4 - Quadro Telemetria
            elif 'mod. 4' in nome_lower:
                folhas['telemetria'] = sheet_name
            # Mod. 5 - CVE (Carregador Veiculo Eletrico)
            elif 'mod. 5' in nome_lower:
                folhas['cve'] = sheet_name
            # Mod. 6 - MUPI
            elif 'mod. 6' in nome_lower:
                folhas['mupi'] = sheet_name
            # Mod. 7 - Lateral
            elif 'mod. 7' in nome_lower:
                folhas['lateral'] = sheet_name
            # Mod. 8 - Capsula Antena
            elif 'mod. 8' in nome_lower:
                folhas['antena'] = sheet_name
            # Fallback: identificar por palavras-chave se nao tiver prefixo
            elif 'lumin' in nome_lower and folhas['luminaria'] is None:
                folhas['luminaria'] = sheet_name
            elif 'telemetria' in nome_lower and folhas['telemetria'] is None:
                folhas['telemetria'] = sheet_name
            elif 'cve' in nome_lower and folhas['cve'] is None:
                folhas['cve'] = sheet_name
            elif 'mupi' in nome_lower and folhas['mupi'] is None:
                folhas['mupi'] = sheet_name
            elif 'lateral' in nome_lower and folhas['lateral'] is None:
                folhas['lateral'] = sheet_name
            elif ('antena' in nome_lower or 'capsula' in nome_lower) and folhas['antena'] is None:
                folhas['antena'] = sheet_name

        # =====================================================================
        # IMPORTAR COLUNAS (folha "Coluna")
        # Cabecalho na linha 2, dados a partir da linha 3
        # =====================================================================
        if folhas['coluna']:
            ws = wb[folhas['coluna']]
            for row in ws.iter_rows(min_row=3, values_only=True):
                if not row or len(row) < 2 or not row[1]:
                    continue
                try:
                    # Colunas: Descricao, Referencia, Pack, Tipo, Fixacao, Altura,
                    # Braco Lum, Braco Rua, Braco Passeio, Lum Incluida,
                    # Mod1, Mod2, Mod3, Mod4, Mod5, Mod6, Mod7, Mod8
                    bd.execute('''INSERT OR REPLACE INTO catalog_columns
                        (description, reference, pack, column_type, fixing, height_m,
                         arm_count, arm_street, arm_sidewalk, luminaire_included,
                         mod1_luminaire, mod2_electrical, mod3_fuse_box, mod4_telemetry,
                         mod5_ev, mod6_mupi, mod7_lateral, mod8_antenna)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                        (get_val(row[0]),                    # description
                         get_val(row[1]),                    # reference
                         get_val(row[2], 'BAREBONE'),        # pack
                         get_val(row[3], 'Standard'),        # column_type
                         get_val(row[4], 'Flange'),          # fixing
                         get_int(row[5]),                    # height_m
                         get_int(row[6] if len(row) > 6 else 0),   # arm_count
                         get_int(row[7] if len(row) > 7 else 0),   # arm_street
                         get_int(row[8] if len(row) > 8 else 0),   # arm_sidewalk
                         get_val(row[9] if len(row) > 9 else 'Nao', 'Nao'),    # luminaire_included
                         get_val(row[10] if len(row) > 10 else 'Nao', 'Nao'),  # mod1_luminaire
                         get_val(row[11] if len(row) > 11 else 'Nao', 'Nao'),  # mod2_electrical
                         get_val(row[12] if len(row) > 12 else 'Nao', 'Nao'),  # mod3_fuse_box
                         get_val(row[13] if len(row) > 13 else 'Nao', 'Nao'),  # mod4_telemetry
                         get_val(row[14] if len(row) > 14 else 'Nao', 'Nao'),  # mod5_ev
                         get_val(row[15] if len(row) > 15 else 'Nao', 'Nao'),  # mod6_mupi
                         get_val(row[16] if len(row) > 16 else 'Sim', 'Sim'),  # mod7_lateral
                         get_val(row[17] if len(row) > 17 else 'Sim', 'Sim'))) # mod8_antenna
                    stats['columns'] += 1
                except Exception as e:
                    errors.append(f"Coluna {row[1]}: {str(e)}")

        # =====================================================================
        # IMPORTAR LUMINARIAS (Mod. 1)
        # Cabecalho na linha 1, dados a partir da linha 2
        # Colunas: Tipo, Descricao, Desc.Curta, Referencia, Ref.Fabricante, Altura,
        #          Tipo1, Tipo2, TipoTensao, Tensao(V), Potencia(W), Corrente(A)
        # =====================================================================
        if folhas['luminaria']:
            ws = wb[folhas['luminaria']]
            for row in ws.iter_rows(min_row=2, values_only=True):
                if not row or len(row) < 4 or not row[3]:
                    continue
                try:
                    bd.execute('''INSERT OR REPLACE INTO catalog_luminaires
                        (luminaire_type, description, short_description, reference,
                         manufacturer_ref, column_height_m, type_1, type_2,
                         connection_type, voltage, power_watts, current_amps)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                        (get_val(row[0]),                    # luminaire_type
                         get_val(row[1]),                    # description
                         get_val(row[2]),                    # short_description
                         get_val(row[3]),                    # reference
                         get_val(row[4] if len(row) > 4 else ''),  # manufacturer_ref
                         get_int(row[5] if len(row) > 5 else 0),   # column_height_m
                         is_sim(row[6] if len(row) > 6 else 0),    # type_1
                         is_sim(row[7] if len(row) > 7 else 0),    # type_2
                         get_val(row[8] if len(row) > 8 else ''),  # connection_type
                         get_int(row[9] if len(row) > 9 else None),   # voltage
                         get_int(row[10] if len(row) > 10 else None), # power_watts
                         get_float(row[11] if len(row) > 11 else None)))# current_amps
                    stats['luminaires'] += 1
                except Exception as e:
                    errors.append(f"Luminaria {row[3]}: {str(e)}")

        # =====================================================================
        # IMPORTAR QUADROS ELETRICOS (Mod. 2)
        # Colunas: Tipo, Descricao, Desc.Curta, Referencia,
        #          TipoTensao, Tensao(V), CorrenteProtecao(A), PotenciaAdmitida(W), PotenciaPorFase(W)
        # =====================================================================
        if folhas['eletrico']:
            ws = wb[folhas['eletrico']]
            for row in ws.iter_rows(min_row=2, values_only=True):
                if not row or len(row) < 4 or not row[3]:
                    continue
                try:
                    ref = get_val(row[3])
                    short_ref = ref.replace('SLP-', '').replace('QE-', '') if ref.startswith(('SLP-', 'QE-')) else ref
                    bd.execute('''INSERT OR REPLACE INTO catalog_electrical_panels
                        (panel_type, description, short_description, reference, short_reference,
                         connection_type, voltage, protection_current, max_power_total, max_power_per_phase)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                        (get_val(row[0]),   # panel_type
                         get_val(row[1]),   # description
                         get_val(row[2]),   # short_description
                         ref,               # reference
                         short_ref,         # short_reference
                         get_val(row[4] if len(row) > 4 else ''),     # connection_type
                         get_int(row[5] if len(row) > 5 else None),   # voltage
                         get_float(row[6] if len(row) > 6 else None),  # protection_current
                         get_int(row[7] if len(row) > 7 else None),   # max_power_total
                         get_int(row[8] if len(row) > 8 else None)))  # max_power_per_phase
                    stats['electrical'] += 1
                except Exception as e:
                    errors.append(f"Quadro eletrico {row[3]}: {str(e)}")

        # =====================================================================
        # IMPORTAR COFRETES FUSIVEL (Mod. 3)
        # Colunas: Tipo, Descricao, Desc.Curta, Referencia, TipoS, TipoD,
        #          TipoTensao, Tensao(V), PotenciaAdmitida(W), PotenciaPorFase(W)
        # =====================================================================
        if folhas['cofrete']:
            ws = wb[folhas['cofrete']]
            for row in ws.iter_rows(min_row=2, values_only=True):
                if not row or len(row) < 4 or not row[3]:
                    continue
                try:
                    ref = get_val(row[3])
                    short_ref = ref.replace('SLP-', '') if ref.startswith('SLP-') else ref
                    bd.execute('''INSERT OR REPLACE INTO catalog_fuse_boxes
                        (fuse_type, description, short_description, reference, short_reference, type_s, type_d,
                         connection_type, voltage, max_power_total, max_power_per_phase)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                        (get_val(row[0]),                    # fuse_type
                         get_val(row[1]),                    # description
                         get_val(row[2]),                    # short_description
                         ref,                                # reference
                         short_ref,                          # short_reference
                         is_sim(row[4] if len(row) > 4 else 0),   # type_s
                         is_sim(row[5] if len(row) > 5 else 0),   # type_d
                         get_val(row[6] if len(row) > 6 else ''),    # connection_type
                         get_int(row[7] if len(row) > 7 else None),  # voltage
                         get_int(row[8] if len(row) > 8 else None),  # max_power_total
                         get_int(row[9] if len(row) > 9 else None))) # max_power_per_phase
                    stats['fuse_boxes'] += 1
                except Exception as e:
                    errors.append(f"Cofrete {row[3]}: {str(e)}")

        # =====================================================================
        # IMPORTAR QUADROS TELEMETRIA (Mod. 4)
        # Colunas: Tipo, Descricao, Desc.Curta, Referencia,
        #          TipoTensao, Tensao(V), Potencia(W)
        # =====================================================================
        if folhas['telemetria']:
            ws = wb[folhas['telemetria']]
            for row in ws.iter_rows(min_row=2, values_only=True):
                if not row or len(row) < 4 or not row[3]:
                    continue
                try:
                    ref = get_val(row[3])
                    short_ref = ref.replace('SLP-', '') if ref.startswith('SLP-') else ref
                    bd.execute('''INSERT OR REPLACE INTO catalog_telemetry_panels
                        (panel_type, description, short_description, reference, short_reference,
                         connection_type, voltage, power_watts)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)''',
                        (get_val(row[0]),   # panel_type
                         get_val(row[1]),   # description
                         get_val(row[2]),   # short_description
                         ref,               # reference
                         short_ref,         # short_reference
                         get_val(row[4] if len(row) > 4 else ''),    # connection_type
                         get_int(row[5] if len(row) > 5 else None),  # voltage
                         get_int(row[6] if len(row) > 6 else None))) # power_watts
                    stats['telemetry'] += 1
                except Exception as e:
                    errors.append(f"Telemetria {row[3]}: {str(e)}")

        # =====================================================================
        # IMPORTAR MODULOS CVE/EV (Mod. 5)
        # Colunas: Tipo, Descricao, Desc.Curta, Referencia,
        #          TipoTensao, Tensao(V), Potencia(W), Corrente(A)
        # =====================================================================
        if folhas['cve']:
            ws = wb[folhas['cve']]
            for row in ws.iter_rows(min_row=2, values_only=True):
                if not row or len(row) < 4 or not row[3]:
                    continue
                try:
                    ref = get_val(row[3])
                    short_ref = ref.replace('SLPS-', '').replace('SLP-', '') if ref.startswith(('SLPS-', 'SLP-')) else ref
                    bd.execute('''INSERT OR REPLACE INTO catalog_module_ev
                        (module_type, description, short_description, reference, short_reference,
                         connection_type, voltage, power_watts, current_amps)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                        (get_val(row[0]),   # module_type
                         get_val(row[1]),   # description
                         get_val(row[2]),   # short_description
                         ref,               # reference
                         short_ref,         # short_reference
                         get_val(row[4] if len(row) > 4 else ''),    # connection_type
                         get_int(row[5] if len(row) > 5 else None),  # voltage
                         get_int(row[6] if len(row) > 6 else None),  # power_watts
                         get_float(row[7] if len(row) > 7 else None))) # current_amps
                    stats['ev'] += 1
                except Exception as e:
                    errors.append(f"Modulo EV {row[3]}: {str(e)}")

        # =====================================================================
        # IMPORTAR MODULOS MUPI (Mod. 6)
        # Colunas: Tipo, Descricao, Desc.Curta, Referencia,
        #          TipoTensao, Tensao(V), Potencia(W)
        # =====================================================================
        if folhas['mupi']:
            ws = wb[folhas['mupi']]
            for row in ws.iter_rows(min_row=2, values_only=True):
                if not row or len(row) < 4 or not row[3]:
                    continue
                try:
                    ref = get_val(row[3])
                    short_ref = ref.replace('SLPS-', '').replace('SLP-', '') if ref.startswith(('SLPS-', 'SLP-')) else ref
                    bd.execute('''INSERT OR REPLACE INTO catalog_module_mupi
                        (module_type, description, short_description, reference, short_reference,
                         connection_type, voltage, power_watts)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)''',
                        (get_val(row[0]),   # module_type
                         get_val(row[1]),   # description
                         get_val(row[2]),   # short_description
                         ref,               # reference
                         short_ref,         # short_reference
                         get_val(row[4] if len(row) > 4 else ''),    # connection_type
                         get_int(row[5] if len(row) > 5 else None),  # voltage
                         get_int(row[6] if len(row) > 6 else None))) # power_watts
                    stats['mupi'] += 1
                except Exception as e:
                    errors.append(f"Modulo MUPI {row[3]}: {str(e)}")

        # =====================================================================
        # IMPORTAR MODULOS LATERAIS (Mod. 7)
        # Colunas: Tipo, Descricao, Desc.Curta, Referencia
        # =====================================================================
        if folhas['lateral']:
            ws = wb[folhas['lateral']]
            for row in ws.iter_rows(min_row=2, values_only=True):
                if not row or len(row) < 4 or not row[3]:
                    continue
                try:
                    ref = get_val(row[3])
                    short_ref = ref.replace('SLP-', '') if ref.startswith('SLP-') else ref
                    bd.execute('''INSERT OR REPLACE INTO catalog_module_lateral
                        (module_type, description, short_description, reference, short_reference)
                        VALUES (?, ?, ?, ?, ?)''',
                        (get_val(row[0]),   # module_type
                         get_val(row[1]),   # description
                         get_val(row[2]),   # short_description
                         ref,               # reference
                         short_ref))        # short_reference
                    stats['lateral'] += 1
                except Exception as e:
                    errors.append(f"Modulo Lateral {row[3]}: {str(e)}")

        # =====================================================================
        # IMPORTAR MODULOS ANTENA (Mod. 8)
        # Colunas: Tipo, Descricao, Desc.Curta, Referencia, Altura
        # =====================================================================
        if folhas['antena']:
            ws = wb[folhas['antena']]
            for row in ws.iter_rows(min_row=2, values_only=True):
                if not row or len(row) < 4 or not row[3]:
                    continue
                try:
                    ref = get_val(row[3])
                    short_ref = ref.replace('SLPC-', '').replace('SLP-', '') if ref.startswith(('SLPC-', 'SLP-')) else ref
                    bd.execute('''INSERT OR REPLACE INTO catalog_module_antenna
                        (module_type, description, short_description, reference, short_reference, column_height_m)
                        VALUES (?, ?, ?, ?, ?, ?)''',
                        (get_val(row[0]),                    # module_type
                         get_val(row[1]),                    # description
                         get_val(row[2]),                    # short_description
                         ref,                                # reference
                         short_ref,                          # short_reference
                         get_int(row[4] if len(row) > 4 else 0)))  # column_height_m
                    stats['antenna'] += 1
                except Exception as e:
                    errors.append(f"Modulo Antena {row[3]}: {str(e)}")

        bd.commit()

        return jsonify({
            'success': True,
            'message': 'Catalogo importado com sucesso',
            'stats': stats,
            'sheets_found': {k: v for k, v in folhas.items() if v},
            'errors': errors if errors else None
        })

    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'error': f'Erro ao importar catalogo: {str(e)}'}), 500


@catalog_bp.route('/export', methods=['GET'])
@requer_autenticacao
def exportar_catalogo():
    """Exporta catalogo para Excel."""
    if not EXCEL_DISPONIVEL:
        return jsonify({'error': 'Funcionalidade Excel nao disponivel'}), 500

    try:
        bd = obter_bd()
        wb = Workbook()

        # Folha de Colunas
        ws = wb.active
        ws.title = "Colunas"

        headers = ['ID', 'Descricao', 'Referencia', 'Pack', 'Tipo', 'Fixacao', 'Altura']
        for col, header in enumerate(headers, 1):
            ws.cell(row=1, column=col, value=header)

        colunas = bd.execute('SELECT * FROM catalog_columns ORDER BY pack, height_m').fetchall()
        for row_num, col in enumerate(colunas, 2):
            ws.cell(row=row_num, column=1, value=col['id'])
            ws.cell(row=row_num, column=2, value=col['description'])
            ws.cell(row=row_num, column=3, value=col['reference'])
            ws.cell(row=row_num, column=4, value=col['pack'])
            ws.cell(row=row_num, column=5, value=col['column_type'])
            ws.cell(row=row_num, column=6, value=col['fixing'])
            ws.cell(row=row_num, column=7, value=col['height_m'])

        output = BytesIO()
        wb.save(output)
        output.seek(0)

        return send_file(
            output,
            mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            as_attachment=True,
            download_name='catalogo_smartlamppost.xlsx'
        )

    except Exception as e:
        return jsonify({'error': f'Erro ao exportar: {str(e)}'}), 500
