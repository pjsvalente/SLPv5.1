"""
SmartLamppost - Rotas de Autenticação
"""

from datetime import datetime, timedelta
from flask import request, jsonify, g

from app.routes import auth_bp
from app.database import obter_bd
from app.utils import requer_autenticacao, hash_password, gerar_token
from app.config import get_config

config = get_config()


@auth_bp.route('/login', methods=['POST'])
def login():
    """Autentica um utilizador e devolve um token de sessão."""
    dados = request.json
    username = dados.get('username')
    password = dados.get('password')

    if not username or not password:
        return jsonify({'error': 'Username e password obrigatórios'}), 400

    bd = obter_bd()
    utilizador = bd.execute(
        'SELECT * FROM users WHERE username = ? AND password_hash = ?',
        (username, hash_password(password))
    ).fetchone()

    if not utilizador:
        return jsonify({'error': 'Credenciais inválidas'}), 401

    # Limpar sessões antigas
    bd.execute('DELETE FROM sessions WHERE user_id = ?', (utilizador['id'],))

    # Criar nova sessão
    token = gerar_token()
    expira = datetime.now() + timedelta(hours=config.EXPIRACAO_TOKEN_HORAS)

    bd.execute('''
        INSERT INTO sessions (user_id, token, expires_at)
        VALUES (?, ?, ?)
    ''', (utilizador['id'], token, expira))

    bd.execute('UPDATE users SET last_login = ? WHERE id = ?', (datetime.now(), utilizador['id']))
    bd.commit()

    return jsonify({
        'token': token,
        'user': {'id': utilizador['id'], 'username': utilizador['username'], 'role': utilizador['role']},
        'expires_at': expira.isoformat()
    })


@auth_bp.route('/logout', methods=['POST'])
@requer_autenticacao
def logout():
    """Termina a sessão do utilizador."""
    token = request.headers.get('Authorization', '').replace('Bearer ', '')
    bd = obter_bd()
    bd.execute('DELETE FROM sessions WHERE token = ?', (token,))
    bd.commit()
    return jsonify({'message': 'Sessão terminada'})


@auth_bp.route('/me', methods=['GET'])
@requer_autenticacao
def utilizador_atual():
    """Devolve informação do utilizador autenticado."""
    return jsonify({
        'id': g.utilizador_atual['user_id'],
        'username': g.utilizador_atual['username'],
        'role': g.utilizador_atual['role']
    })
