"""
SmartLamppost - Sistema de Gestão de Infraestruturas RFID
API Backend Flask
Versão: 3.0.0 - Arquitectura Modular

Autor: SmartLamppost Team
"""

import os
from flask import Flask, send_file

from app.config import get_config
from app.extensions import cors, EXCEL_DISPONIVEL
from app.database import fechar_ligacao, inicializar_bd
from app.scheduler import iniciar_scheduler


def create_app(config_class=None):
    """Application Factory - Cria e configura a aplicação Flask."""

    app = Flask(__name__, static_folder=None)

    # Carregar configuração
    if config_class is None:
        config_class = get_config()

    app.config.from_object(config_class)

    # Criar diretórios necessários
    os.makedirs(config_class.PASTA_BACKUPS, exist_ok=True)
    os.makedirs(config_class.PASTA_INTERVENCOES, exist_ok=True)
    os.makedirs(config_class.PASTA_ASSETS, exist_ok=True)

    # Inicializar extensões
    cors.init_app(app, resources={
        r"/api/*": {
            "origins": config_class.CORS_ORIGINS,
            "methods": ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
            "allow_headers": ["Content-Type", "Authorization"]
        }
    })

    # Registar callback para fechar ligação à BD
    app.teardown_appcontext(fechar_ligacao)

    # Registar blueprints
    from app.routes import register_blueprints
    register_blueprints(app)

    # Rota raiz para servir index.html
    @app.route('/', methods=['GET'])
    def index():
        """Serve a página principal."""
        pasta_base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        return send_file(os.path.join(pasta_base, 'index.html'))

    # Inicializar base de dados
    inicializar_bd(app)

    # Iniciar scheduler de tarefas (backup automático)
    iniciar_scheduler(app)

    return app


# Exportar flag de Excel disponível para uso externo
__all__ = ['create_app', 'EXCEL_DISPONIVEL']
