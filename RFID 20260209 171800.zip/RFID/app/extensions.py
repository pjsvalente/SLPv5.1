"""
SmartLamppost - Extensões Flask
"""

from flask_cors import CORS

# Instância global do CORS (inicializada em create_app)
cors = CORS()

# Flag para verificar disponibilidade do Excel
try:
    from openpyxl import Workbook, load_workbook
    from openpyxl.styles import Font, PatternFill, Alignment
    EXCEL_DISPONIVEL = True
except ImportError:
    EXCEL_DISPONIVEL = False
    print("⚠️  Funcionalidades Excel indisponíveis")
