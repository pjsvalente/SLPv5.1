"""
SmartLamppost - Agendador de Tarefas
Usa APScheduler para backup automático semanal.
"""

import logging
from datetime import datetime
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger

# Configurar logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('scheduler')

# Instância global do scheduler
_scheduler = None
_app = None


def _executar_backup_automatico():
    """Executa o backup automático."""
    from app.routes.backup import criar_backup_interno

    logger.info(f"[{datetime.now()}] A iniciar backup automático...")

    try:
        resultado = criar_backup_interno(prefixo='auto', user_id=None, motivo='Backup automático semanal')

        if resultado.get('success'):
            logger.info(f"[{datetime.now()}] Backup automático criado com sucesso: {resultado['backup_name']}")
        else:
            logger.error(f"[{datetime.now()}] Erro no backup automático: {resultado.get('error')}")
    except Exception as e:
        logger.error(f"[{datetime.now()}] Excepção no backup automático: {str(e)}")


def _obter_config_backup():
    """Obtém as configurações de backup automático da BD."""
    import sqlite3
    from app.config import get_config

    config = get_config()

    try:
        conn = sqlite3.connect(config.BASE_DADOS)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()

        # Obter configurações
        cursor.execute('''
            SELECT config_key, config_value FROM system_config
            WHERE config_key IN ('auto_backup_enabled', 'auto_backup_day', 'auto_backup_hour', 'auto_backup_minute')
        ''')

        configs = {row['config_key']: row['config_value'] for row in cursor.fetchall()}
        conn.close()

        return {
            'enabled': configs.get('auto_backup_enabled', 'true').lower() == 'true',
            'day': int(configs.get('auto_backup_day', '0')),
            'hour': int(configs.get('auto_backup_hour', '2')),
            'minute': int(configs.get('auto_backup_minute', '0'))
        }
    except Exception as e:
        logger.error(f"Erro ao obter config de backup: {str(e)}")
        return {'enabled': True, 'day': 0, 'hour': 2, 'minute': 0}


def iniciar_scheduler(app):
    """Inicia o scheduler de tarefas."""
    global _scheduler, _app

    if _scheduler is not None:
        logger.info("Scheduler já está a correr")
        return

    _app = app
    _scheduler = BackgroundScheduler(daemon=True)

    # Configurar job de backup automático
    _atualizar_job_backup()

    _scheduler.start()
    logger.info("Scheduler iniciado com sucesso")


def _atualizar_job_backup():
    """Atualiza ou cria o job de backup automático."""
    global _scheduler

    if _scheduler is None:
        return

    # Remover job existente se houver
    try:
        _scheduler.remove_job('auto_backup')
    except Exception:
        pass

    # Obter configurações
    config = _obter_config_backup()

    if not config['enabled']:
        logger.info("Backup automático desativado")
        return

    # Mapear dia (0=Segunda a 6=Domingo) para formato cron (0=Domingo a 6=Sábado)
    # APScheduler usa: 0=Segunda, 1=Terça, ..., 6=Domingo (padrão Python)
    dia_semana = config['day']

    # Adicionar novo job
    trigger = CronTrigger(
        day_of_week=dia_semana,
        hour=config['hour'],
        minute=config['minute']
    )

    _scheduler.add_job(
        _executar_backup_automatico,
        trigger,
        id='auto_backup',
        name='Backup Automático Semanal',
        replace_existing=True
    )

    dias = ['Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado', 'Domingo']
    logger.info(f"Backup automático agendado: {dias[dia_semana]} às {config['hour']:02d}:{config['minute']:02d}")


def atualizar_configuracao_backup():
    """Atualiza a configuração do backup (chamar após alterar system_config)."""
    _atualizar_job_backup()


def parar_scheduler():
    """Para o scheduler."""
    global _scheduler

    if _scheduler is not None:
        _scheduler.shutdown(wait=False)
        _scheduler = None
        logger.info("Scheduler parado")


def obter_proximo_backup():
    """Retorna informação sobre o próximo backup agendado."""
    global _scheduler

    if _scheduler is None:
        return None

    try:
        job = _scheduler.get_job('auto_backup')
        if job:
            next_run = job.next_run_time
            if next_run:
                return {
                    'next_run': next_run.isoformat(),
                    'next_run_formatted': next_run.strftime('%d/%m/%Y %H:%M')
                }
    except Exception:
        pass

    return None
