"""
SmartLamppost - Decoradores de Autenticação
"""

from functools import wraps
from flask import request, jsonify, g

from app.database import obter_bd


def requer_autenticacao(f):
    """Decorador que exige autenticação para aceder ao endpoint."""
    @wraps(f)
    def decorado(*args, **kwargs):
        # Tentar obter token do header Authorization ou do query parameter
        token = request.headers.get('Authorization', '').replace('Bearer ', '')
        if not token:
            token = request.args.get('token', '')

        if not token:
            return jsonify({'error': 'Token de autenticação necessário'}), 401

        bd = obter_bd()
        sessao = bd.execute('''
            SELECT s.*, u.username, u.role
            FROM sessions s
            JOIN users u ON s.user_id = u.id
            WHERE s.token = ? AND s.expires_at > datetime('now')
        ''', (token,)).fetchone()

        if not sessao:
            return jsonify({'error': 'Token inválido ou expirado'}), 401

        g.utilizador_atual = dict(sessao)
        return f(*args, **kwargs)
    return decorado


def requer_admin(f):
    """Decorador que exige permissões de administrador."""
    @wraps(f)
    @requer_autenticacao
    def decorado(*args, **kwargs):
        if g.utilizador_atual['role'] != 'admin':
            return jsonify({'error': 'Acesso restrito a administradores'}), 403
        return f(*args, **kwargs)
    return decorado
