"""
SmartLamppost - Funções Auxiliares
"""

import hashlib
import secrets

from app.config import get_config

config = get_config()


def hash_password(password):
    """Gera hash SHA-256 da password."""
    # TODO: Migrar para bcrypt ou argon2 para maior segurança
    return hashlib.sha256(password.encode()).hexdigest()


def gerar_token():
    """Gera um token de sessão aleatório."""
    return secrets.token_urlsafe(32)


def allowed_file(filename):
    """Verifica se a extensão do ficheiro é permitida."""
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in config.ALLOWED_EXTENSIONS
