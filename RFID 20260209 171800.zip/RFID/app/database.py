"""
SmartLamppost - Gestão da Base de Dados
"""

import sqlite3
import hashlib
import json
from flask import g

from app.config import get_config

config = get_config()


def obter_bd():
    """Obtém a ligação à base de dados para o contexto atual."""
    bd = getattr(g, '_database', None)
    if bd is None:
        bd = g._database = sqlite3.connect(config.BASE_DADOS)
        bd.row_factory = sqlite3.Row
    return bd


def obter_config(chave, valor_padrao=None):
    """Obtém um valor de configuração do sistema."""
    bd = obter_bd()
    resultado = bd.execute(
        'SELECT config_value FROM system_config WHERE config_key = ?',
        (chave,)
    ).fetchone()
    return resultado['config_value'] if resultado else valor_padrao


def fechar_ligacao(excecao):
    """Fecha a ligação à base de dados no fim do pedido."""
    bd = getattr(g, '_database', None)
    if bd is not None:
        bd.close()


def inicializar_bd(app):
    """Inicializa a base de dados com o esquema necessário."""
    with app.app_context():
        bd = obter_bd()

        # Tabela de utilizadores
        bd.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                role TEXT DEFAULT 'operator',
                first_name TEXT,
                last_name TEXT,
                email TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_login TIMESTAMP
            )
        ''')

        # Adicionar colunas se não existirem (para bases de dados existentes)
        for coluna in ['first_name', 'last_name', 'email']:
            try:
                bd.execute(f'ALTER TABLE users ADD COLUMN {coluna} TEXT')
            except sqlite3.OperationalError:
                pass

        # Tabela de sessões
        bd.execute('''
            CREATE TABLE IF NOT EXISTS sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                token TEXT UNIQUE NOT NULL,
                expires_at TIMESTAMP NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
        ''')

        # Tabela de campos dinâmicos
        bd.execute('''
            CREATE TABLE IF NOT EXISTS schema_fields (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                field_name TEXT UNIQUE NOT NULL,
                field_type TEXT NOT NULL,
                field_label TEXT NOT NULL,
                required INTEGER DEFAULT 1,
                field_order INTEGER DEFAULT 0,
                field_category TEXT DEFAULT 'general',
                field_options TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        # Tabela principal de ativos
        bd.execute('''
            CREATE TABLE IF NOT EXISTS assets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                serial_number TEXT UNIQUE NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                created_by INTEGER,
                updated_by INTEGER,
                FOREIGN KEY (created_by) REFERENCES users(id),
                FOREIGN KEY (updated_by) REFERENCES users(id)
            )
        ''')

        # Tabela de dados dos ativos (chave-valor)
        bd.execute('''
            CREATE TABLE IF NOT EXISTS asset_data (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                asset_id INTEGER NOT NULL,
                field_name TEXT NOT NULL,
                field_value TEXT,
                FOREIGN KEY (asset_id) REFERENCES assets(id) ON DELETE CASCADE,
                UNIQUE(asset_id, field_name)
            )
        ''')

        # Tabela de números de série dos módulos/equipamentos
        bd.execute('''
            CREATE TABLE IF NOT EXISTS asset_module_serials (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                asset_id INTEGER NOT NULL,
                module_name TEXT NOT NULL,
                module_description TEXT,
                serial_number TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_by INTEGER,
                FOREIGN KEY (asset_id) REFERENCES assets(id) ON DELETE CASCADE,
                FOREIGN KEY (updated_by) REFERENCES users(id),
                UNIQUE(asset_id, module_name)
            )
        ''')

        # Tabela de histórico de manutenção
        bd.execute('''
            CREATE TABLE IF NOT EXISTS maintenance_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                asset_id INTEGER NOT NULL,
                action_type TEXT NOT NULL,
                description TEXT,
                performed_by INTEGER,
                performed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (asset_id) REFERENCES assets(id),
                FOREIGN KEY (performed_by) REFERENCES users(id)
            )
        ''')

        # Tabela de registo de auditoria
        bd.execute('''
            CREATE TABLE IF NOT EXISTS audit_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                action TEXT NOT NULL,
                table_name TEXT,
                record_id INTEGER,
                old_values TEXT,
                new_values TEXT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
        ''')

        # Tabela de histórico de alterações de estado
        bd.execute('''
            CREATE TABLE IF NOT EXISTS status_change_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                asset_id INTEGER NOT NULL,
                previous_status TEXT,
                new_status TEXT NOT NULL,
                description TEXT NOT NULL,
                changed_by INTEGER NOT NULL,
                intervention_id INTEGER,
                changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (asset_id) REFERENCES assets(id) ON DELETE CASCADE,
                FOREIGN KEY (changed_by) REFERENCES users(id),
                FOREIGN KEY (intervention_id) REFERENCES interventions(id)
            )
        ''')

        # Tabela de técnicos externos
        bd.execute('''
            CREATE TABLE IF NOT EXISTS external_technicians (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                company TEXT NOT NULL,
                phone TEXT,
                email TEXT,
                notes TEXT,
                active INTEGER DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                created_by INTEGER,
                FOREIGN KEY (created_by) REFERENCES users(id)
            )
        ''')

        # Tabela principal de intervenções
        bd.execute('''
            CREATE TABLE IF NOT EXISTS interventions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                asset_id INTEGER NOT NULL,
                intervention_type TEXT NOT NULL,
                problem_description TEXT,
                solution_description TEXT,
                parts_used TEXT,
                total_cost REAL DEFAULT 0,
                duration_hours REAL NOT NULL,
                status TEXT DEFAULT 'em_curso',
                previous_asset_status TEXT,
                final_asset_status TEXT,
                notes TEXT,
                created_by INTEGER NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                completed_at TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_by INTEGER,
                FOREIGN KEY (asset_id) REFERENCES assets(id) ON DELETE CASCADE,
                FOREIGN KEY (created_by) REFERENCES users(id),
                FOREIGN KEY (updated_by) REFERENCES users(id)
            )
        ''')

        # Tabela de técnicos participantes em cada intervenção
        bd.execute('''
            CREATE TABLE IF NOT EXISTS intervention_technicians (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                intervention_id INTEGER NOT NULL,
                user_id INTEGER,
                external_technician_id INTEGER,
                role TEXT DEFAULT 'participante',
                FOREIGN KEY (intervention_id) REFERENCES interventions(id) ON DELETE CASCADE,
                FOREIGN KEY (user_id) REFERENCES users(id),
                FOREIGN KEY (external_technician_id) REFERENCES external_technicians(id)
            )
        ''')

        # Tabela de ficheiros das intervenções
        bd.execute('''
            CREATE TABLE IF NOT EXISTS intervention_files (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                intervention_id INTEGER NOT NULL,
                file_category TEXT NOT NULL,
                file_name TEXT NOT NULL,
                original_name TEXT NOT NULL,
                file_path TEXT NOT NULL,
                file_type TEXT NOT NULL,
                file_size INTEGER,
                description TEXT,
                cost_value REAL,
                uploaded_by INTEGER NOT NULL,
                uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (intervention_id) REFERENCES interventions(id) ON DELETE CASCADE,
                FOREIGN KEY (uploaded_by) REFERENCES users(id)
            )
        ''')

        # Tabela de log de edições de intervenções
        bd.execute('''
            CREATE TABLE IF NOT EXISTS intervention_edit_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                intervention_id INTEGER NOT NULL,
                edited_by INTEGER NOT NULL,
                edited_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                field_name TEXT NOT NULL,
                old_value TEXT,
                new_value TEXT,
                FOREIGN KEY (intervention_id) REFERENCES interventions(id) ON DELETE CASCADE,
                FOREIGN KEY (edited_by) REFERENCES users(id)
            )
        ''')

        # Tabela de registos de tempo de trabalho
        bd.execute('''
            CREATE TABLE IF NOT EXISTS intervention_time_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                intervention_id INTEGER NOT NULL,
                logged_by INTEGER NOT NULL,
                time_spent REAL NOT NULL,
                work_date DATE DEFAULT CURRENT_DATE,
                description TEXT,
                logged_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (intervention_id) REFERENCES interventions(id) ON DELETE CASCADE,
                FOREIGN KEY (logged_by) REFERENCES users(id)
            )
        ''')

        # Tabelas de catálogo
        _criar_tabelas_catalogo(bd)

        # Tabela de configurações do sistema
        bd.execute('''
            CREATE TABLE IF NOT EXISTS system_config (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                config_key TEXT UNIQUE NOT NULL,
                config_value TEXT,
                description TEXT,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_by INTEGER,
                FOREIGN KEY (updated_by) REFERENCES users(id)
            )
        ''')

        # Tabela de contadores para numeração automática
        bd.execute('''
            CREATE TABLE IF NOT EXISTS sequence_counters (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                counter_type TEXT UNIQUE NOT NULL,
                current_value INTEGER DEFAULT 0,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        # Tabela de atualizações de intervenções
        bd.execute('''
            CREATE TABLE IF NOT EXISTS intervention_updates (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                intervention_id INTEGER NOT NULL,
                update_code TEXT UNIQUE NOT NULL,
                update_number INTEGER NOT NULL,
                description TEXT,
                notes TEXT,
                created_by INTEGER NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (intervention_id) REFERENCES interventions(id) ON DELETE CASCADE,
                FOREIGN KEY (created_by) REFERENCES users(id)
            )
        ''')

        # Inicializar dados padrão
        _inicializar_dados_padrao(bd)

        bd.commit()


def _criar_tabelas_catalogo(bd):
    """Cria as tabelas de catálogo."""
    # Tabela de colunas base
    bd.execute('''
        CREATE TABLE IF NOT EXISTS catalog_columns (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            description TEXT,
            reference TEXT UNIQUE NOT NULL,
            pack TEXT NOT NULL,
            column_type TEXT DEFAULT 'Standard',
            fixing TEXT DEFAULT 'Flange',
            height_m INTEGER,
            arm_count INTEGER DEFAULT 0,
            arm_street INTEGER DEFAULT 0,
            arm_sidewalk INTEGER DEFAULT 0,
            luminaire_included TEXT DEFAULT 'Não',
            mod1_luminaire TEXT DEFAULT 'Não',
            mod2_electrical TEXT DEFAULT 'Não',
            mod3_fuse_box TEXT DEFAULT 'Não',
            mod4_telemetry TEXT DEFAULT 'Não',
            mod5_ev TEXT DEFAULT 'Não',
            mod6_mupi TEXT DEFAULT 'Não',
            mod7_lateral TEXT DEFAULT 'Sim',
            mod8_antenna TEXT DEFAULT 'Sim'
        )
    ''')

    # Tabela de luminárias (Mod. 1)
    bd.execute('''
        CREATE TABLE IF NOT EXISTS catalog_luminaires (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            luminaire_type TEXT NOT NULL,
            description TEXT,
            short_description TEXT,
            reference TEXT NOT NULL,
            manufacturer_ref TEXT,
            column_height_m INTEGER,
            type_1 INTEGER DEFAULT 0,
            type_2 INTEGER DEFAULT 0,
            connection_type TEXT,
            voltage INTEGER,
            power_watts INTEGER,
            current_amps REAL,
            UNIQUE(reference, column_height_m)
        )
    ''')

    # Tabela de quadros elétricos (Mod. 2)
    bd.execute('''
        CREATE TABLE IF NOT EXISTS catalog_electrical_panels (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            panel_type TEXT NOT NULL,
            description TEXT,
            short_description TEXT,
            reference TEXT UNIQUE NOT NULL,
            short_reference TEXT NOT NULL,
            connection_type TEXT,
            voltage INTEGER,
            protection_current REAL,
            max_power_total INTEGER,
            max_power_per_phase INTEGER
        )
    ''')

    # Tabela de cofretes fusível (Mod. 3)
    bd.execute('''
        CREATE TABLE IF NOT EXISTS catalog_fuse_boxes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            fuse_type TEXT NOT NULL,
            description TEXT,
            short_description TEXT,
            reference TEXT UNIQUE NOT NULL,
            short_reference TEXT NOT NULL,
            type_s INTEGER DEFAULT 0,
            type_d INTEGER DEFAULT 0,
            connection_type TEXT,
            voltage INTEGER,
            max_power_total INTEGER,
            max_power_per_phase INTEGER
        )
    ''')

    # Tabela de quadros de telemetria (Mod. 4)
    bd.execute('''
        CREATE TABLE IF NOT EXISTS catalog_telemetry_panels (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            panel_type TEXT NOT NULL,
            description TEXT,
            short_description TEXT,
            reference TEXT UNIQUE NOT NULL,
            short_reference TEXT NOT NULL,
            connection_type TEXT,
            voltage INTEGER,
            power_watts INTEGER
        )
    ''')

    # Tabela de módulos EV Charger (Mod. 5)
    bd.execute('''
        CREATE TABLE IF NOT EXISTS catalog_module_ev (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            module_type TEXT NOT NULL,
            description TEXT,
            short_description TEXT,
            reference TEXT UNIQUE NOT NULL,
            short_reference TEXT NOT NULL,
            connection_type TEXT,
            voltage INTEGER,
            power_watts INTEGER,
            current_amps REAL
        )
    ''')

    # Tabela de módulos MUPI (Mod. 6)
    bd.execute('''
        CREATE TABLE IF NOT EXISTS catalog_module_mupi (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            module_type TEXT NOT NULL,
            description TEXT,
            short_description TEXT,
            reference TEXT UNIQUE NOT NULL,
            short_reference TEXT NOT NULL,
            connection_type TEXT,
            voltage INTEGER,
            power_watts INTEGER
        )
    ''')

    # Tabela de módulos laterais (Mod. 7)
    bd.execute('''
        CREATE TABLE IF NOT EXISTS catalog_module_lateral (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            module_type TEXT NOT NULL,
            description TEXT,
            short_description TEXT,
            reference TEXT UNIQUE NOT NULL,
            short_reference TEXT NOT NULL
        )
    ''')

    # Tabela de módulos antena (Mod. 8)
    bd.execute('''
        CREATE TABLE IF NOT EXISTS catalog_module_antenna (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            module_type TEXT NOT NULL,
            description TEXT,
            short_description TEXT,
            reference TEXT UNIQUE NOT NULL,
            short_reference TEXT NOT NULL,
            column_height_m INTEGER
        )
    ''')

    # =========================================================================
    # MIGRAÇÕES: Adicionar colunas de potência às tabelas de catálogo
    # (para bases de dados existentes - colunas com DEFAULT NULL)
    # =========================================================================

    # Mod. 1 - Luminárias: potência, tensão, corrente, tipo ligação
    for col in ['connection_type TEXT', 'voltage INTEGER', 'power_watts INTEGER', 'current_amps REAL']:
        try:
            bd.execute(f'ALTER TABLE catalog_luminaires ADD COLUMN {col}')
        except sqlite3.OperationalError:
            pass

    # Mod. 2 - Quadros Elétricos: tipo ligação, tensão, corrente proteção, potência max total/fase
    for col in ['connection_type TEXT', 'voltage INTEGER', 'protection_current REAL',
                'max_power_total INTEGER', 'max_power_per_phase INTEGER']:
        try:
            bd.execute(f'ALTER TABLE catalog_electrical_panels ADD COLUMN {col}')
        except sqlite3.OperationalError:
            pass

    # Mod. 3 - Cofretes: tipo ligação, tensão, potência max total/fase
    for col in ['connection_type TEXT', 'voltage INTEGER', 'max_power_total INTEGER', 'max_power_per_phase INTEGER']:
        try:
            bd.execute(f'ALTER TABLE catalog_fuse_boxes ADD COLUMN {col}')
        except sqlite3.OperationalError:
            pass

    # Mod. 4 - Telemetria: tipo ligação, tensão, potência
    for col in ['connection_type TEXT', 'voltage INTEGER', 'power_watts INTEGER']:
        try:
            bd.execute(f'ALTER TABLE catalog_telemetry_panels ADD COLUMN {col}')
        except sqlite3.OperationalError:
            pass

    # Mod. 5 - CVE/EV: tipo ligação, tensão, potência, corrente
    for col in ['connection_type TEXT', 'voltage INTEGER', 'power_watts INTEGER', 'current_amps REAL']:
        try:
            bd.execute(f'ALTER TABLE catalog_module_ev ADD COLUMN {col}')
        except sqlite3.OperationalError:
            pass

    # Mod. 6 - MUPI: tipo ligação, tensão, potência
    for col in ['connection_type TEXT', 'voltage INTEGER', 'power_watts INTEGER']:
        try:
            bd.execute(f'ALTER TABLE catalog_module_mupi ADD COLUMN {col}')
        except sqlite3.OperationalError:
            pass

    # Mod. 7 e 8 (Lateral e Antena) não têm campos de potência


def _inicializar_dados_padrao(bd):
    """Inicializa os dados padrão do sistema."""
    # Configurações padrão de prefixos
    config_padroes = [
        ('prefix_assets', 'SLP', 'Prefixo para números de série de ativos'),
        ('prefix_assets_digits', '9', 'Número de dígitos para numeração de ativos'),
        ('prefix_int_preventiva', 'INTP', 'Prefixo para intervenções preventivas'),
        ('prefix_int_corretiva', 'INTC', 'Prefixo para intervenções corretivas'),
        ('prefix_int_substituicao', 'INTS', 'Prefixo para intervenções de substituição'),
        ('prefix_int_inspecao', 'INSP', 'Prefixo para inspeções'),
        ('prefix_int_digits', '9', 'Número de dígitos para numeração de intervenções'),
        ('colors_list', json.dumps(['RAL 7016', 'RAL 9006', 'RAL 9010', 'RAL Q985', 'RAL 150 Sablé', 'Branco', 'Preto', 'Cinzento']), 'Lista de cores disponíveis para ativos'),
        ('manufacturers_list', json.dumps(['Metalogalva']), 'Lista de fabricantes'),
        ('models_list', json.dumps(['Standard Smartlamppost', 'Costume Smartlamppost']), 'Lista de modelos'),
        ('materials_list', json.dumps(['Aço Galvanizado', 'Alumínio', 'Fibra de Vidro']), 'Lista de materiais'),
        ('locations_list', json.dumps([]), 'Lista de localizações'),
        ('municipalities_list', json.dumps([]), 'Lista de municípios'),
        ('addresses_list', json.dumps([]), 'Lista de moradas'),
        ('favorite_manufacturer', 'Metalogalva', 'Fabricante favorito para defaults'),
        ('favorite_model', 'Standard Smartlamppost', 'Modelo favorito para defaults'),
        ('favorite_material', 'Aço Galvanizado', 'Material favorito para defaults'),
        ('auto_backup_enabled', 'true', 'Ativar backup automático'),
        ('auto_backup_day', '0', 'Dia da semana para backup automático (0=Segunda, 6=Domingo)'),
        ('auto_backup_hour', '2', 'Hora do backup automático (0-23)'),
        ('auto_backup_minute', '0', 'Minuto do backup automático (0-59)'),
    ]

    for chave, valor, descricao in config_padroes:
        try:
            bd.execute('''
                INSERT OR IGNORE INTO system_config (config_key, config_value, description)
                VALUES (?, ?, ?)
            ''', (chave, valor, descricao))
        except sqlite3.IntegrityError:
            pass

    # Inicializar contadores
    contadores_padroes = ['assets', 'int_preventiva', 'int_corretiva', 'int_substituicao', 'int_inspecao']
    for contador in contadores_padroes:
        try:
            bd.execute('''
                INSERT OR IGNORE INTO sequence_counters (counter_type, current_value)
                VALUES (?, 0)
            ''', (contador,))
        except sqlite3.IntegrityError:
            pass

    # Campos predefinidos do sistema
    campos_predefinidos = [
        ('rfid_tag', 'text', 'RFID Tag', 1, 1, 'identification', None),
        ('product_reference', 'text', 'Referência do Produto', 1, 2, 'identification', None),
        ('manufacturer', 'text', 'Fabricante', 1, 3, 'identification', None),
        ('model', 'text', 'Modelo', 1, 4, 'identification', None),
        ('height_meters', 'number', 'Altura (m)', 0, 5, 'specifications', None),
        ('material', 'select', 'Material', 0, 6, 'specifications',
         json.dumps(['Aço Galvanizado', 'Alumínio', 'Aço Inox', 'Compósito'])),
        ('column_color', 'color_select', 'Cor da Coluna', 0, 7, 'specifications', None),
        ('power_watts', 'number', 'Potência (W)', 0, 8, 'specifications', None),
        ('connection_type', 'select', 'Tipologia de Ligação', 0, 9, 'specifications',
         json.dumps(['Monofásica', 'Trifásica'])),
        ('installation_date', 'date', 'Data de Instalação', 0, 10, 'installation', None),
        ('installation_location', 'text', 'Localização', 0, 11, 'installation', None),
        ('gps_latitude', 'number', 'GPS Latitude', 0, 12, 'installation', None),
        ('gps_longitude', 'number', 'GPS Longitude', 0, 13, 'installation', None),
        ('municipality', 'text', 'Município', 0, 14, 'installation', None),
        ('street_address', 'text', 'Morada', 0, 15, 'installation', None),
        ('warranty_end_date', 'date', 'Fim da Garantia', 0, 16, 'warranty', None),
        ('warranty_certificate', 'text', 'Certificado de Garantia', 0, 17, 'warranty', None),
        ('last_inspection_date', 'date', 'Última Inspeção', 0, 18, 'maintenance', None),
        ('next_inspection_date', 'date', 'Próxima Inspeção', 0, 19, 'maintenance', None),
        ('next_maintenance_date', 'date', 'Próxima Manutenção', 0, 20, 'maintenance', None),
        ('maintenance_notes', 'textarea', 'Notas de Manutenção', 0, 21, 'maintenance', None),
        ('condition_status', 'select', 'Estado', 0, 22, 'maintenance',
         json.dumps(['Operacional', 'Manutenção Necessária', 'Em Reparação', 'Desativado'])),
        ('attached_equipment', 'textarea', 'Equipamentos Associados', 0, 23, 'equipment', None),
        ('luminaire_type', 'text', 'Tipo de Luminária', 0, 24, 'equipment', None),
        ('notes', 'textarea', 'Observações', 0, 99, 'other', None),
    ]

    for campo in campos_predefinidos:
        try:
            bd.execute('''
                INSERT OR IGNORE INTO schema_fields
                (field_name, field_type, field_label, required, field_order, field_category, field_options)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', campo)
        except sqlite3.IntegrityError:
            pass

    # Criar utilizador admin predefinido
    hash_admin = hashlib.sha256('admin123'.encode()).hexdigest()
    try:
        bd.execute('''
            INSERT OR IGNORE INTO users (username, password_hash, role)
            VALUES (?, ?, ?)
        ''', ('admin', hash_admin, 'admin'))
    except sqlite3.IntegrityError:
        pass


def registar_auditoria(bd, user_id, acao, tabela, record_id, valores_antigos, valores_novos):
    """Regista uma ação no log de auditoria."""
    bd.execute('''
        INSERT INTO audit_log (user_id, action, table_name, record_id, old_values, new_values)
        VALUES (?, ?, ?, ?, ?, ?)
    ''', (
        user_id, acao, tabela, record_id,
        json.dumps(valores_antigos) if valores_antigos else None,
        json.dumps(valores_novos) if valores_novos else None
    ))
