#!/usr/bin/env python3
"""
SmartLamppost - Ponto de Entrada da Aplicação
Execute com: python run.py
"""

import subprocess
import sys
import os

# =============================================================================
# AUTO-INSTALAÇÃO DE DEPENDÊNCIAS
# =============================================================================

def instalar_pacote(pacote):
    """Instala um pacote Python automaticamente via pip."""
    print(f"A instalar {pacote}...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", pacote, "-q"])
    print(f"{pacote} instalado com sucesso!")


def verificar_dependencias():
    """Verifica e instala todas as dependências necessárias."""
    dependencias = {
        'flask': 'Flask',
        'flask_cors': 'flask-cors',
        'openpyxl': 'openpyxl'
    }

    for modulo, pacote in dependencias.items():
        try:
            __import__(modulo)
        except ImportError:
            print(f"AVISO: {pacote} nao encontrado. A instalar automaticamente...")
            try:
                instalar_pacote(pacote)
            except Exception as e:
                print(f"ERRO ao instalar {pacote}: {e}")
                sys.exit(1)


# Verificar dependências antes de importar a app
verificar_dependencias()

from app import create_app, EXCEL_DISPONIVEL
from app.config import get_config

config = get_config()


def main():
    """Função principal que inicia o servidor."""
    print()
    print("SmartLamppost - Sistema de Gestao de Infraestruturas RFID")
    print("=" * 60)
    print(f"Base de dados: {config.BASE_DADOS}")
    print(f"Pasta de backups: {config.PASTA_BACKUPS}")
    print(f"Pasta de assets: {config.PASTA_ASSETS}")
    print(f"Exportacao Excel: {'Disponivel' if EXCEL_DISPONIVEL else 'Indisponivel'}")
    print(f"Modo debug: {'Ativo' if config.DEBUG else 'Inativo'}")
    print("=" * 60)
    print("Servidor a iniciar em http://localhost:5000")
    print("Credenciais: admin / admin123")
    print("=" * 60)
    print()

    app = create_app()
    app.run(host='0.0.0.0', port=5000, debug=config.DEBUG)


if __name__ == '__main__':
    main()
